// content.js — RHIMOB_NT_ENRIQUECIMENTO (Ver telefone + Ver email)
// Extração idêntica à versão anterior (RHIMOB_CATHO_SINC v1.2.5) — já
// comprovada em produção, não mexi aqui.
(function () {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const nowISO = () => {
    const d=new Date(), p=n=>String(n).padStart(2,'0');
    return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  };
  const unique = a => Array.from(new Set((a||[]).filter(Boolean)));
  const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim();
  const cleanBlock = (v) => String(v || '').replace(/\r/g, '\n').replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  const getAfter = (label, text) => {
    const re=new RegExp(label+'\\s*:\\s*([^\\n]+)','i');
    const m=(text||'').match(re);
    return m?m[1].trim():'';
  };
  const isProfilePage = () => /\/curriculos\/(?!busca\/)/i.test(location.pathname);


  function getBlockBetween(text, startLabel, endLabels){
    const src = String(text || '');
    const startRx = new RegExp(startLabel, 'i');
    const startMatch = src.match(startRx);
    if(!startMatch) return '';
    const startIndex = startMatch.index + startMatch[0].length;
    const rest = src.slice(startIndex);
    let endIndex = rest.length;
    (endLabels || []).forEach(lbl => {
      const rx = new RegExp('\\n\\s*' + lbl, 'i');
      const m = rest.match(rx);
      if(m && typeof m.index === 'number' && m.index < endIndex) endIndex = m.index;
    });
    return cleanBlock(rest.slice(0, endIndex)).replace(/^[:\-\s]+/, '').trim();
  }

  function extractPhones(txt){
    const rx=/\(\d{2}\)\s?\d{4,5}[- ]?\d{4}/g;
    const found=unique(((txt||'').match(rx)||[]).map(s=>s.trim()));
    return { Telefone1: found[0]||'', Telefone2: found[1]||'', TelefonesBrutos: found.join(' | ') };
  }

  function pickEmail(){
    const mailto=document.querySelector('a[href^="mailto:"]');
    if(mailto) return (mailto.getAttribute('href')||'').replace(/^mailto:/,'').trim();
    const txt=document.body.innerText||'';
    const m=txt.match(/[\w.+-]+@[\w.-]+\.[\w.-]+/);
    return m?m[0]:'';
  }

  function pickName(){
    const h=document.querySelector('h1') || document.querySelector('h2');
    return (h && h.textContent || '').trim();
  }

  function extractFromDadosPessoais(){
    let box = Array.from(document.querySelectorAll('section,div,article'))
      .find(el => /Dados\s+Pessoais/i.test(el.textContent||''));
    const text = (box ? box.innerText : document.body.innerText) || '';

    const cep = (getAfter('CEP', text)||'').replace(/[^\d-]/g,'').trim();
    const endereco = getAfter('Endere[cç]o', text) || getAfter('Endereço', text) || '';
    const cidadeLinha = getAfter('Cidade', text) || '';
    const bairro = getAfter('Bairro', text) || '';

    let Cidade='', EstadoUF='', RegiaoCidade='';
    const m=cidadeLinha.match(/^([^,-]+)[,\-]\s*([A-Z]{2})/);
    if(m){ Cidade=m[1].trim(); EstadoUF=m[2].trim(); }
    else  { Cidade=cidadeLinha.trim(); }

    if(Cidade) RegiaoCidade = EstadoUF ? `${Cidade} - ${EstadoUF}` : Cidade;
    return { CEP: cep, Endereco: endereco, Cidade, EstadoUF, Bairro: bairro, RegiaoCidade };
  }

  // ==== Clique em "Ver telefone" e "Ver email" ====
  function findClickableByText(rx){
    const btns = Array.from(document.querySelectorAll('button'));
    const b = btns.find(x => rx.test((x.innerText||'').trim()));
    if(b) return b;

    const els = Array.from(document.querySelectorAll('span,div,a'));
    const el = els.find(x => rx.test((x.innerText||'').trim()));
    if(el){
      const parentBtn = el.closest('button,a');
      return parentBtn || el;
    }
    return null;
  }

  async function clickReveal(rx){
    for(let attempt=0; attempt<4; attempt++){
      const el = findClickableByText(rx);
      if(el){
        el.click();
        await sleep(1200);
        return true;
      }
      await sleep(900);
    }
    return false;
  }

  async function waitForPhone(maxMs=7000){
    const start = Date.now();
    while(Date.now()-start < maxMs){
      const txt = document.body.innerText || '';
      if(/\(\d{2}\)\s?\d{4,5}[- ]?\d{4}/.test(txt)) return true;
      await sleep(400);
    }
    return false;
  }

  async function waitForEmail(maxMs=7000){
    const start = Date.now();
    while(Date.now()-start < maxMs){
      const mailto = document.querySelector('a[href^="mailto:"]');
      if(mailto) return true;
      const txt = document.body.innerText || '';
      if(/[\w.+-]+@[\w.-]+\.[\w.-]+/.test(txt)) return true;
      await sleep(400);
    }
    return false;
  }

  function scrapeProfile(){
    const text = document.body.innerText||'';
    const nome = pickName();
    const {Telefone1,Telefone2,TelefonesBrutos}=extractPhones(text);
    const email=pickEmail();
    const pret = getAfter('Pretens[aã]o salarial',text)||getAfter('Pretensão salarial',text);
    const atualizado = getAfter('Atualizado',text);
    const dataNasc = getAfter('Data de nascimento',text);

    let cargo = getAfter('Cargo de interesse',text);
    if(!cargo){
      const el=document.querySelector('[data-testid*="desired-role"], .role, .occupation');
      if(el) cargo=el.textContent.trim();
    }

    const loc = extractFromDadosPessoais();

    const sectionEndLabels = ['Projetos', 'Formação', 'Habilidades Verificadas', 'Habilidades Verificadas - Busca Certa', 'Idiomas', 'Dados Pessoais'];
    const resumo = getBlockBetween(text, 'Resumo do CV', ['Objetivo e qualificações', 'Experiência Profissional'].concat(sectionEndLabels));
    const qualificacoes = getBlockBetween(text, 'Qualificações', ['Experiência Profissional'].concat(sectionEndLabels));
    const experienciaProfissional = getBlockBetween(text, 'Experiência Profissional', sectionEndLabels);
    const idiomas = getBlockBetween(text, 'Idiomas', ['Dados Pessoais']);

    return {
      DataHoraISO: nowISO(),
      Plataforma: 'Catho',
      PerfilURL: location.href,
      Curriculo: location.href,
      NomeCompleto: nome,
      PrimeiroNome: (nome||'').split(/\s+/)[0]||'',
      ProfissaoOuCargo: cargo||'',
      Cargo: cargo||'',
      Telefone1, Telefone2, TelefonesBrutos,
      Email: email,
      PretensaoSalarial: pret||'',
      AtualizadoEm: atualizado||'',
      DataNascimento: dataNasc||'',
      Nascimento: dataNasc||'',
      Origem: 'Catho',
      RegiaoCidade: loc.RegiaoCidade||'',
      Cidade: loc.Cidade||'',
      EstadoUF: loc.EstadoUF||'',
      Bairro: loc.Bairro||'',
      Endereco: loc.Endereco||'',
      CEP: loc.CEP||'',
      ResumoCV: resumo || '',
      Qualificacoes: qualificacoes || '',
      ExperienciaProfissional: experienciaProfissional || '',
      Idiomas: idiomas || ''
    };
  }

  async function autoScrape(){
    if(!isProfilePage()){
      return { ok:false, error:"Não é página de currículo (curriculos/<id>)" };
    }

    const clickedPhone = await clickReveal(/ver\s+telefone/i);
    if(clickedPhone) await waitForPhone(7000);

    const clickedEmail = await clickReveal(/ver\s+email/i);
    if(clickedEmail) await waitForEmail(7000);

    const data = scrapeProfile();
    return { ok:true, data };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if(msg && msg.type === "AUTO_SCRAPE"){
      autoScrape().then(sendResponse).catch(err => sendResponse({ok:false, error:String(err)}));
      return true;
    }
  });

  function ensureButton(){
    if(document.getElementById('rhmob-fab')) return;
    const css = `
      #rhmob-fab{position:fixed;right:18px;bottom:18px;z-index:2147483647;
        background:#0d6efd;color:#fff;border:none;border-radius:999px;
        padding:12px 16px;font-weight:800;box-shadow:0 6px 18px rgba(0,0,0,.2);cursor:pointer}
      #rhmob-toast{position:fixed;right:18px;bottom:72px;z-index:2147483647;
        background:#222;color:#fff;padding:10px 12px;border-radius:10px;display:none;max-width:340px}
    `;
    const st=document.createElement('style'); st.textContent=css; document.documentElement.appendChild(st);
    const btn=document.createElement('button'); btn.id='rhmob-fab'; btn.textContent='RHIMOB • Enviar entrada';
    const toast=document.createElement('div'); toast.id='rhmob-toast';
    btn.onclick=()=>{
      toast.style.display='block'; toast.textContent='Capturando...';
      autoScrape().then(res=>{
        if(!res.ok){ toast.textContent='❌ '+(res.error||'Falha'); return; }
        toast.textContent='Enviando...';
        chrome.runtime.sendMessage({type:'SEND_ONE', row: res.data}, resp=>{
          if(resp?.ok){ toast.textContent='✅ ' + (resp.acao || 'Enviado'); setTimeout(()=>toast.style.display='none',1800); }
          else { toast.textContent='❌ '+(resp?.error||'Falha'); }
        });
      });
    };
    document.body.appendChild(btn); document.body.appendChild(toast);
  }

  if(/catho\.com\.br/i.test(location.host)){ ensureButton(); }
})();
