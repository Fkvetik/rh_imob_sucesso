function doGet(e){
  return resp_({
    ok: true,
    service: 'RHIMOB_NT_ENRIQUECIMENTO_WEBAPP_V1',
    status: 'online',
    mode: 'READ_SOURCE_DEDUP_NT_WRITE_DEST',
    sourceFallback: DEFAULT_SOURCE_SHEET_ID,
    destFallback: DEFAULT_DEST_SHEET_ID,
    geoFallback: DEFAULT_GEO_SHEET_ID,
    hint: 'Use POST com action=next, action=update ou action=append_manual. Cada currículo é checado por telefone contra a Novos Talentos antes de gravar: NOVO (não existia) / ATUALIZADO (existia, 2+ anos) / DADOS_COMPLETO (existia, fresco).',
    ts: new Date().toISOString()
  });
}

// Login/senha de verdade — checados contra nt_enriquecimento_usuarios
// (Novos Talentos, pufxvskozfdvfscqnays) via nt_rpc_enriquecimento_login.
// Gerenciável no admin-catho-coletor.html, sem precisar editar/redeploy
// esse arquivo pra trocar ou adicionar login.
const NT_SUPABASE_URL_AUTH = 'https://pufxvskozfdvfscqnays.supabase.co';
const NT_SUPABASE_ANON_KEY_AUTH = 'sb_publishable_hYJDyj6C0f2uBZF__t35Yw_E1S9SIEj';

function loginValido_(login, senha){
  const l = clean_(login), s = clean_(senha);
  if(!l || !s) return false;
  try{
    const resp = UrlFetchApp.fetch(NT_SUPABASE_URL_AUTH + '/rest/v1/rpc/nt_rpc_enriquecimento_login', {
      method:'post',
      contentType:'application/json',
      headers:{ apikey: NT_SUPABASE_ANON_KEY_AUTH, Authorization:'Bearer ' + NT_SUPABASE_ANON_KEY_AUTH },
      payload: JSON.stringify({ p_login:l, p_senha:s }),
      muteHttpExceptions:true
    });
    if(resp.getResponseCode() < 200 || resp.getResponseCode() >= 300) return false;
    const data = JSON.parse(resp.getContentText());
    return Array.isArray(data) && data.length > 0 && data[0].ok === true;
  }catch(err){ return false; }
}

function doPost(e){
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const body = (e && e.postData && e.postData.contents) || '';
    if(!body) return resp_({ok:false, error:'empty body'});
    let p;
    try { p = JSON.parse(body); } catch(err){ return resp_({ok:false, error:'invalid json', detail:String(err)}); }
    const action = clean_(p.action);
    if(action === 'ping') return resp_({ok:true, ts:new Date().toISOString(), service:'RHIMOB_NT_ENRIQUECIMENTO_WEBAPP_V1'});
    if(!loginValido_(p.login, p.senha)) return resp_({ok:false, error:'Login ou senha incorretos (ou ausentes)'});
    if(action === 'next') return next_(p);
    if(action === 'update') return update_(p);
    if(action === 'append_manual') return appendManual_(p);
    if(action === 'reset_cursor') return resetCursor_(p);
    if(action === 'report_erro') return reportarErroExtracao_(p);
    return resp_({ok:false, error:'unknown action'});
  } catch(err){
    return resp_({ok:false, error:String(err)});
  } finally {
    try { lock.releaseLock(); } catch(_) {}
  }
}

// Currículo que a extensão coletou mas não conseguiu extrair (timeout,
// página bloqueada, "Ver telefone" não apareceu etc.) — antes isso
// desaparecia sem deixar rastro nenhum; agora fica registrado, pra dar pra
// ver quantos e por quê, e decidir se vale reprocessar manualmente.
function reportarErroExtracao_(p){
  const destSheetId = clean_(p.destSheetId || DEFAULT_DEST_SHEET_ID);
  if(!destSheetId) return resp_({ok:false, error:'destSheetId vazio'});
  const destSs = SpreadsheetApp.openById(destSheetId);
  const sh = getOrCreateSheet_(destSs, 'ERROS_EXTRACAO');
  const headers = ['Curriculo','Login','Erro','DataHoraISO'];
  ensureHeaderRow_(sh, 1, headers);
  sh.appendRow([
    clean_(p.url),
    clean_(p.login),
    clean_(p.error),
    Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss')
  ]);
  return resp_({ok:true});
}

// Cabeçalho base (dados extraídos) + colunas de resultado do roteamento pra
// Novos Talentos. Usado em TODAS as abas de destino (NOVOS, ATUALIZADOS,
// DADOS_COMPLETO, MAE) — mesma estrutura em todo lugar, fácil de comparar.
const RH_HEADERS_DEST = [
  'Curriculo','SourceSheetId','SourceTab','SourceRow','NomeCompleto','PrimeiroNome','Email','Telefone1','Telefone2','Tel2','Whatsapp','TelefonesBrutos','Telefone1Digitos','Telefone2Digitos',
  'Cargo','UltimoSalario','PretensaoSalarial','Sexo','EstadoCivil','IdadeTexto','IdadeAnos','Nascimento','DataNascimento','Cidade','EstadoUF','Bairro','Endereco','CEP','Pais',
  'RegiaoMacro','MicroRegiao','BairroMacro','Latitude','Longitude','GeoStatus','GeoFonte','ResumoCV','Qualificacoes','ExperienciaProfissional','Idiomas','AtualizadoEm','DataHoraISO','Origem','StatusProcessamento','ErroProcessamento','ColetadoEm',
  'ForcaMatchCurriculo','FILTRO_CASCATA_HTML','empreendimento','profile_url','Status','UltimaAtualizacao','ProfissaoOuCargo','RegiaoCidade'
];
const NT_DEST_HEADERS = RH_HEADERS_DEST.concat(['Login','AcaoRealizada','TalentoKeyNT','DiasDesdeAtualizacaoNT','ErroNT']);

const CTRL_SHEET = '_CONTROLE_COLETOR';
// Origem: continua a mesma esteira Sinc de sempre — não muda o jeito que os
// currículos entram na fila, só o que acontece com eles depois de extraídos.
const DEFAULT_SOURCE_SHEET_ID = '1wjVv_VQSs55q1i91LhpHsmelm3GuI5ipqsmrTqIvlKs';
const DEFAULT_SOURCE_TAB = 'Sinc';
// Destino: planilha mãe nova, dedicada a essa ferramenta.
const DEFAULT_DEST_SHEET_ID = '1tdn1yZ1z3283381oi-sIp-U91xgfivT1xekYqnlOkxM';
// Planilha auxiliar que contém a aba cep usada para RegiaoMacro/MicroRegiao/BairroMacro.
const DEFAULT_GEO_SHEET_ID = '1rs6xO89y-2kU4z979YybpUfKd6XpJh9ijiQCbY17mUA';
const DEFAULT_CEP_TAB = 'cep';
const READ_CHUNK = 300;

// ===== Novos Talentos (Supabase pufxvskozfdvfscqnays) =====
// Chave pública — nt_rpc_buscar_por_telefone e nt_rpc_ingest_talento são
// SECURITY DEFINER e não exigem login de operador, só essa chave.
const NT_SUPABASE_URL = 'https://pufxvskozfdvfscqnays.supabase.co';
const NT_SUPABASE_ANON_KEY = 'sb_publishable_hYJDyj6C0f2uBZF__t35Yw_E1S9SIEj';
// Currículo considerado "fresco" se atualizado há menos que isso — não mexe.
const NT_FRESH_DAYS = 730;

function next_(p){
  const sourceSheetId = clean_(p.sourceSheetId || p.sheetId || DEFAULT_SOURCE_SHEET_ID);
  const destSheetId = clean_(p.destSheetId || DEFAULT_DEST_SHEET_ID);
  const sourceTab = clean_(p.sourceTab) || DEFAULT_SOURCE_TAB;
  if(!sourceSheetId) return resp_({ok:false, error:'sourceSheetId vazio'});
  if(!destSheetId) return resp_({ok:false, error:'destSheetId vazio'});

  const sourceSs = SpreadsheetApp.openById(sourceSheetId);
  const destSs = SpreadsheetApp.openById(destSheetId);
  const sourceSh = sourceSs.getSheetByName(sourceTab);
  if(!sourceSh) return resp_({ok:false, error:'Aba de origem não encontrada: ' + sourceTab});

  const meta = readSourceHeader_(sourceSh);
  if(!meta.headerRow) return resp_({ok:false, error:'Cabeçalho da origem não localizado. A aba precisa ter Curriculo, profile_url ou PerfilURL.'});
  ensureSourceQueueColumns_(sourceSh, meta.headerRow);
  const meta2 = readSourceHeader_(sourceSh);

  const lastRow = sourceSh.getLastRow();
  if(lastRow <= meta2.headerRow) return resp_({ok:true, found:false, msg:'sem linhas'});

  const map = meta2.map;
  const colStatus = getCol_(map, ['Status','status']) || 0;
  const colUp = getCol_(map, ['UltimaAtualizacao','ÚltimaAtualização','ultimaatualizacao']) || 0;

  // Lock global do doPost já serializa isso: mesmo com 4 PCs chamando "next"
  // ao mesmo tempo, cada requisição processa e marca PROCESSANDO antes da
  // próxima começar — nunca duas máquinas pegam a mesma linha.
  const cursorKey = buildCursorKey_(sourceSheetId, sourceTab);
  let cursor = Math.max(meta2.headerRow + 1, Number(getControlValue_(destSs, cursorKey, String(meta2.headerRow + 1))) || (meta2.headerRow + 1));

  const found = findNextPendingRow_(sourceSh, meta2, cursor, lastRow) || findNextPendingRow_(sourceSh, meta2, meta2.headerRow + 1, Math.min(lastRow, cursor - 1));
  if(!found) return resp_({ok:true, found:false, msg:'nada pendente'});

  if(colStatus) sourceSh.getRange(found.rowIndex, colStatus).setValue('PROCESSANDO');
  if(colUp) sourceSh.getRange(found.rowIndex, colUp).setValue(new Date());

  setControlValue_(destSs, cursorKey, String(found.rowIndex + 1));
  setControlValue_(destSs, 'LAST_SOURCE_ROW', String(found.rowIndex));
  setControlValue_(destSs, 'LAST_SOURCE_URL', found.curriculo);

  return resp_({
    ok:true,
    found:true,
    rowIndex: found.rowIndex,
    profile_url: found.curriculo,
    rowData: found.row,
    sourceSheetId: sourceSheetId,
    sourceTab: sourceTab,
    destSheetId: destSheetId
  });
}

function update_(p){
  const sourceSheetId = clean_(p.sourceSheetId || p.sheetId || DEFAULT_SOURCE_SHEET_ID);
  const destSheetId = clean_(p.destSheetId || DEFAULT_DEST_SHEET_ID);
  const sourceTab = clean_(p.sourceTab) || DEFAULT_SOURCE_TAB;
  const cepTab = clean_(p.cepTab) || DEFAULT_CEP_TAB;
  const geoSheetId = clean_(p.geoSheetId || p.cepSheetId || p.regionSheetId || DEFAULT_GEO_SHEET_ID);
  const rowIndex = Number(p.rowIndex || 0);
  const login = clean_(p.login || p.operador);
  if(!sourceSheetId || !destSheetId || !rowIndex) return resp_({ok:false, error:'sourceSheetId/destSheetId/rowIndex inválidos'});

  const sourceSs = SpreadsheetApp.openById(sourceSheetId);
  const destSs = SpreadsheetApp.openById(destSheetId);
  const sourceSh = sourceSs.getSheetByName(sourceTab);
  if(!sourceSh) return resp_({ok:false, error:'Aba de origem não encontrada: ' + sourceTab});

  const meta = readSourceHeader_(sourceSh);
  if(!meta.headerRow) return resp_({ok:false, error:'Cabeçalho da origem não localizado'});
  ensureSourceQueueColumns_(sourceSh, meta.headerRow);
  const meta2 = readSourceHeader_(sourceSh);

  const existing = p.existing || getRowByIndex_(sourceSh, meta2, rowIndex);
  const data = p.data || {};
  const merged = mergeCandidateData_(existing, data);
  const geoSs = openGeoSpreadsheet_(geoSheetId, sourceSs, destSs);
  const geo = enrichGeo_(geoSs, cepTab, merged);
  const finalData = Object.assign({}, merged, geo, {
    SourceSheetId: sourceSheetId,
    SourceTab: sourceTab,
    SourceRow: rowIndex,
    StatusProcessamento: p.ok ? 'OK' : buildRetryStatus_(p.error),
    ErroProcessamento: p.ok ? '' : clean_(p.error),
    ColetadoEm: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss')
  });
  finalizeDestComputedFields_(finalData, p.ok, p.error);

  const roteamento = p.ok ? rotearParaNT_(finalData, login) : { AcaoRealizada:'ERRO_EXTRACAO', TalentoKeyNT:'', DiasDesdeAtualizacaoNT:'', ErroNT: clean_(p.error), Login: login };
  Object.assign(finalData, roteamento);

  upsertDestRow_(destSs, destTabParaAcao_(roteamento.AcaoRealizada), finalData);
  upsertDestRow_(destSs, 'MAE', finalData);
  updateSourceQueueRow_(sourceSh, meta2, rowIndex, finalData, p.ok, p.error);
  setControlValue_(destSs, 'LAST_UPDATE_STATUS', finalData.StatusProcessamento);
  setControlValue_(destSs, 'LAST_UPDATE_URL', finalData.Curriculo);
  return resp_({
    ok:true,
    curriculo: finalData.Curriculo,
    destSheetId: destSheetId,
    acao: roteamento.AcaoRealizada,
    talentoKey: roteamento.TalentoKeyNT
  });
}


function appendManual_(p){
  const sourceSheetId = clean_(p.sourceSheetId || DEFAULT_SOURCE_SHEET_ID);
  const destSheetId = clean_(p.destSheetId || p.sheetId || DEFAULT_DEST_SHEET_ID);
  const sourceTab = clean_(p.sourceTab) || 'MANUAL_CATHO_EXTENSION';
  const cepTab = clean_(p.cepTab) || DEFAULT_CEP_TAB;
  const geoSheetId = clean_(p.geoSheetId || p.cepSheetId || p.regionSheetId || DEFAULT_GEO_SHEET_ID);
  const login = clean_(p.login || p.operador);
  if(!destSheetId) return resp_({ok:false, error:'destSheetId vazio'});

  const destSs = SpreadsheetApp.openById(destSheetId);
  let sourceSs = null;
  try { sourceSs = SpreadsheetApp.openById(sourceSheetId); } catch(err) { sourceSs = destSs; }

  const data = p.data || {};
  const merged = mergeCandidateData_({}, data);
  const geoSs = openGeoSpreadsheet_(geoSheetId, sourceSs, destSs);
  const geo = enrichGeo_(geoSs, cepTab, merged);
  const finalData = Object.assign({}, merged, geo, {
    SourceSheetId: sourceSheetId,
    SourceTab: sourceTab,
    SourceRow: '',
    StatusProcessamento: 'OK_MANUAL',
    ErroProcessamento: '',
    ColetadoEm: Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss')
  });
  finalizeDestComputedFields_(finalData, true, '');

  const roteamento = rotearParaNT_(finalData, login);
  Object.assign(finalData, roteamento);

  upsertDestRow_(destSs, destTabParaAcao_(roteamento.AcaoRealizada), finalData);
  upsertDestRow_(destSs, 'MAE', finalData);
  setControlValue_(destSs, 'LAST_MANUAL_URL', finalData.Curriculo);
  setControlValue_(destSs, 'LAST_MANUAL_STATUS', 'OK_MANUAL');
  return resp_({ok:true, curriculo: finalData.Curriculo, destSheetId: destSheetId, acao: roteamento.AcaoRealizada});
}

function resetCursor_(p){
  const sourceSheetId = clean_(p.sourceSheetId || p.sheetId || DEFAULT_SOURCE_SHEET_ID);
  const destSheetId = clean_(p.destSheetId || p.sheetId || DEFAULT_DEST_SHEET_ID);
  const sourceTab = clean_(p.sourceTab) || DEFAULT_SOURCE_TAB;
  if(!sourceSheetId || !destSheetId) return resp_({ok:false, error:'sourceSheetId/destSheetId obrigatórios'});
  const sourceSs = SpreadsheetApp.openById(sourceSheetId);
  const sourceSh = sourceSs.getSheetByName(sourceTab);
  if(!sourceSh) return resp_({ok:false, error:'Aba de origem não encontrada: ' + sourceTab});
  const meta = readSourceHeader_(sourceSh);
  if(!meta.headerRow) return resp_({ok:false, error:'Cabeçalho da origem não localizado'});
  const destSs = SpreadsheetApp.openById(destSheetId);
  const value = String(meta.headerRow + 1);
  setControlValue_(destSs, buildCursorKey_(sourceSheetId, sourceTab), value);
  return resp_({ok:true, cursor:value});
}

// ===== Roteamento pra Novos Talentos (dedup por telefone + freshness) =====

function destTabParaAcao_(acao){
  if(acao === 'NOVO') return 'NOVOS';
  if(acao === 'ATUALIZADO') return 'ATUALIZADOS';
  if(acao === 'DADOS_COMPLETO') return 'DADOS_COMPLETO';
  return 'ERROS_NT';
}

// Decide o destino de um currículo já extraído/geocodificado:
// - Telefone não existe na Novos Talentos -> NOVO, cria talento.
// - Existe e foi atualizado há menos de NT_FRESH_DAYS -> DADOS_COMPLETO, não mexe.
// - Existe mas está velho (ou sem data) -> ATUALIZADO, sobrescreve o MESMO
//   talento_key (passa a URL antiga pra nt_rpc_ingest_talento, que faz upsert
//   por URL — assim não cria duplicata mesmo com currículo novo/link novo).
function rotearParaNT_(finalData, login){
  const out = { AcaoRealizada:'', TalentoKeyNT:'', DiasDesdeAtualizacaoNT:'', ErroNT:'', Login: login || '' };
  try{
    const telefone = finalData.Whatsapp || finalData.Telefone1Digitos || finalData.Telefone1;
    const achado = buscarPorTelefoneNT_(telefone);

    if(!achado){
      const lead = buildLeadParaNT_(finalData, finalData.Curriculo);
      const ing = ingerirNoNT_(lead);
      out.AcaoRealizada = 'NOVO';
      out.TalentoKeyNT = ing.talento_key || '';
    } else if(achado.dias_desde_atualizacao != null && Number(achado.dias_desde_atualizacao) < NT_FRESH_DAYS){
      out.AcaoRealizada = 'DADOS_COMPLETO';
      out.TalentoKeyNT = achado.talento_key || '';
      out.DiasDesdeAtualizacaoNT = achado.dias_desde_atualizacao;
    } else {
      const lead = buildLeadParaNT_(finalData, achado.curriculo_url);
      const ing = ingerirNoNT_(lead);
      out.AcaoRealizada = 'ATUALIZADO';
      out.TalentoKeyNT = ing.talento_key || achado.talento_key || '';
      out.DiasDesdeAtualizacaoNT = achado.dias_desde_atualizacao;
    }
  }catch(err){
    out.AcaoRealizada = 'ERRO_NT';
    out.ErroNT = String(err);
  }
  return out;
}

function buildLeadParaNT_(data, perfilUrlOverride){
  return {
    PerfilURL: clean_(perfilUrlOverride) || data.Curriculo || data.profile_url,
    NomeCompleto: data.NomeCompleto,
    PrimeiroNome: data.PrimeiroNome,
    Telefone: data.Whatsapp || data.Telefone1Digitos || data.Telefone1,
    Telefone2: data.Telefone2,
    Email: data.Email,
    ProfissaoOuCargo: data.ProfissaoOuCargo || data.Cargo,
    PretensaoSalarial: data.PretensaoSalarial,
    DataNascimento: data.DataNascimento,
    IdadeTexto: data.IdadeTexto,
    Cidade: data.Cidade,
    EstadoUF: data.EstadoUF,
    Bairro: data.Bairro,
    Endereco: data.Endereco,
    CEP: data.CEP,
    RegiaoMacro: data.RegiaoMacro,
    MicroRegiao: data.MicroRegiao,
    BairroMacro: data.BairroMacro,
    Latitude: data.Latitude,
    Longitude: data.Longitude,
    GeoStatus: data.GeoStatus,
    ResumoCV: data.ResumoCV,
    Qualificacoes: data.Qualificacoes,
    ExperienciaProfissional: data.ExperienciaProfissional,
    Idiomas: data.Idiomas,
    FiltroOrigem: 'CATHO_SINC_ENRIQUECIMENTO'
  };
}

// Só leitura — nunca lança erro que pare o fluxo, devolve null se não achar
// ou se a chamada falhar (fica "sem info" e o roteamento trata como incerto).
function buscarPorTelefoneNT_(telefone){
  const digits = normalizeDigits_(telefone);
  if(!digits || digits.length < 8) return null;
  const resp = UrlFetchApp.fetch(NT_SUPABASE_URL + '/rest/v1/rpc/nt_rpc_buscar_por_telefone', {
    method: 'post',
    contentType: 'application/json',
    headers: { apikey: NT_SUPABASE_ANON_KEY, Authorization: 'Bearer ' + NT_SUPABASE_ANON_KEY },
    payload: JSON.stringify({ p_telefone: digits }),
    muteHttpExceptions: true
  });
  const code = resp.getResponseCode();
  if(code < 200 || code >= 300) return null;
  let data;
  try { data = JSON.parse(resp.getContentText()); } catch(err) { return null; }
  if(!Array.isArray(data) || !data.length) return null;
  return data[0];
}

// Grava/atualiza no pool — joga erro se a chamada falhar, pra quem chamou
// decidir o que fazer (rotearParaNT_ captura e marca ERRO_NT).
function ingerirNoNT_(leadPayload){
  const resp = UrlFetchApp.fetch(NT_SUPABASE_URL + '/rest/v1/rpc/nt_rpc_ingest_talento', {
    method: 'post',
    contentType: 'application/json',
    headers: { apikey: NT_SUPABASE_ANON_KEY, Authorization: 'Bearer ' + NT_SUPABASE_ANON_KEY },
    payload: JSON.stringify({ p_lead: leadPayload }),
    muteHttpExceptions: true
  });
  const code = resp.getResponseCode();
  const text = resp.getContentText();
  let data;
  try { data = JSON.parse(text); } catch(err) { data = null; }
  if(code < 200 || code >= 300 || !data || data.ok === false){
    throw new Error('nt_rpc_ingest_talento falhou (' + code + '): ' + text.slice(0,300));
  }
  return data;
}

function mergeCandidateData_(existing, scraped){
  const ex = existing || {};
  const sc = scraped || {};
  const keepOrReplace = function(key){ return clean_(sc[key]) || clean_(ex[key]); };

  const out = {};
  out.Curriculo = keepOrReplace('Curriculo') || keepOrReplace('PerfilURL') || keepOrReplace('profile_url');
  out.Email = keepOrReplace('Email');
  out.Telefone1 = keepOrReplace('Telefone1');
  out.Telefone2 = keepOrReplace('Telefone2');
  out.Tel2 = clean_(sc.Tel2) || clean_(sc.Telefone2) || clean_(ex.Tel2) || clean_(ex.Telefone2);
  out.Whatsapp = keepOrReplace('Whatsapp');
  out.TelefonesBrutos = keepOrReplace('TelefonesBrutos');
  out.Telefone1Digitos = normalizeDigits_(keepOrReplace('Telefone1Digitos') || out.Telefone1);
  out.Telefone2Digitos = normalizeDigits_(keepOrReplace('Telefone2Digitos') || out.Telefone2 || out.Tel2);
  out.Cargo = clean_(sc.Cargo) || clean_(sc.ProfissaoOuCargo) || clean_(ex.Cargo);
  out.ProfissaoOuCargo = clean_(sc.ProfissaoOuCargo) || clean_(sc.Cargo) || clean_(ex.ProfissaoOuCargo) || clean_(ex.Cargo);
  out.UltimoSalario = clean_(sc.UltimoSalario) || clean_(sc['Ultimo salario']) || clean_(ex['Ultimo salario']) || clean_(ex.UltimoSalario);
  out.PretensaoSalarial = keepOrReplace('PretensaoSalarial') || clean_(ex['Pretensão']);
  out.PrimeiroNome = keepOrReplace('PrimeiroNome') || keepOrReplace('1 nome');
  out.NomeCompleto = keepOrReplace('NomeCompleto') || keepOrReplace('nome completo');
  out.Sexo = keepOrReplace('Sexo') || keepOrReplace('sexo');
  out.EstadoCivil = keepOrReplace('EstadoCivil') || keepOrReplace('Estado civil');
  out.IdadeTexto = keepOrReplace('IdadeTexto') || keepOrReplace('idade');
  out.IdadeAnos = clean_(sc.IdadeAnos) || parseAge_(out.IdadeTexto);
  out.Nascimento = keepOrReplace('Nascimento') || keepOrReplace('DataNascimento');
  out.DataNascimento = keepOrReplace('DataNascimento') || keepOrReplace('Nascimento');
  out.Cidade = normalizeCity_(keepOrReplace('Cidade'));
  out.EstadoUF = keepOrReplace('EstadoUF') || inferUF_(clean_(keepOrReplace('Cidade')));
  out.Bairro = keepOrReplace('Bairro');
  out.Endereco = keepOrReplace('Endereco');
  out.CEP = normalizeCep_(keepOrReplace('CEP') || keepOrReplace('Cep'));
  out.Pais = keepOrReplace('Pais') || 'Brasil';
  out.RegiaoMacro = keepOrReplace('RegiaoMacro');
  out.MicroRegiao = keepOrReplace('MicroRegiao');
  out.BairroMacro = keepOrReplace('BairroMacro');
  out.Latitude = keepOrReplace('Latitude');
  out.Longitude = keepOrReplace('Longitude');
  out.GeoStatus = keepOrReplace('GeoStatus');
  out.GeoFonte = keepOrReplace('GeoFonte');
  out.ResumoCV = keepOrReplace('ResumoCV');
  out.Qualificacoes = keepOrReplace('Qualificacoes');
  out.ExperienciaProfissional = keepOrReplace('ExperienciaProfissional');
  out.Idiomas = keepOrReplace('Idiomas');
  out.AtualizadoEm = keepOrReplace('AtualizadoEm');
  out.DataHoraISO = keepOrReplace('DataHoraISO') || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
  out.empreendimento = keepOrReplace('empreendimento') || keepOrReplace('Empreendimento');
  out.profile_url = keepOrReplace('profile_url') || keepOrReplace('PerfilURL') || keepOrReplace('Curriculo') || out.Curriculo;
  out.Status = keepOrReplace('Status');
  out.UltimaAtualizacao = keepOrReplace('UltimaAtualizacao') || keepOrReplace('ÚltimaAtualização');
  out.ForcaMatchCurriculo = keepOrReplace('ForcaMatchCurriculo');
  out.FILTRO_CASCATA_HTML = keepOrReplace('FILTRO_CASCATA_HTML');
  out.RegiaoCidade = keepOrReplace('RegiaoCidade');
  out.Origem = 'Catho';
  return sanitizeCandidateData_(out);
}


function finalizeDestComputedFields_(data, ok, errorMsg){
  const nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss');
  const status = ok ? 'OK' : buildRetryStatus_(errorMsg);

  data.Curriculo = clean_(data.Curriculo || data.profile_url || data.PerfilURL);
  data.profile_url = clean_(data.profile_url || data.Curriculo);
  data.Status = clean_(data.Status) || status;
  data.UltimaAtualizacao = clean_(data.UltimaAtualizacao) || nowStr;
  data.ProfissaoOuCargo = clean_(data.ProfissaoOuCargo || data.Cargo);
  data.RegiaoCidade = clean_(data.RegiaoCidade) || buildRegiaoCidade_(data);
  data.ForcaMatchCurriculo = clean_(data.ForcaMatchCurriculo) || buildForcaMatchCurriculo_(data);
  data.FILTRO_CASCATA_HTML = clean_(data.FILTRO_CASCATA_HTML) || buildFiltroCascataHtml_(data);
}

function buildForcaMatchCurriculo_(data){
  const curriculo = normalizeComparable_(data.Curriculo || data.profile_url);
  const profile = normalizeComparable_(data.profile_url || data.Curriculo);
  if(curriculo && profile && curriculo === profile) return '100';
  if(curriculo || profile) return '90';
  return '';
}

function buildRegiaoCidade_(data){
  const regiao = clean_(data.RegiaoMacro);
  const cidade = clean_(data.Cidade);
  const uf = clean_(data.EstadoUF);
  if(regiao && cidade) return uf ? regiao + ' | ' + cidade + ' - ' + uf : regiao + ' | ' + cidade;
  if(cidade) return uf ? cidade + ' - ' + uf : cidade;
  return regiao;
}

function buildFiltroCascataHtml_(data){
  const parts = [
    data.NomeCompleto,
    data.PrimeiroNome,
    data.Cargo,
    data.ProfissaoOuCargo,
    data.Cidade,
    data.EstadoUF,
    data.Bairro,
    data.RegiaoMacro,
    data.MicroRegiao,
    data.BairroMacro,
    data.RegiaoCidade,
    data.IdadeTexto,
    data.IdadeAnos,
    data.PretensaoSalarial,
    data.Whatsapp,
    data.Telefone1Digitos,
    data.Telefone2Digitos,
    data.empreendimento,
    data.Curriculo,
    data.profile_url
  ];
  const raw = parts.map(clean_).filter(Boolean).join(' | ');
  return normalizeFiltroText_(raw);
}

function normalizeFiltroText_(txt){
  return String(txt || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/\s*\|\s*/g, ' | ')
    .trim();
}


function openGeoSpreadsheet_(geoSheetId, sourceSs, destSs){
  const id = clean_(geoSheetId);
  if(id){
    try { return SpreadsheetApp.openById(id); } catch(err) {}
  }
  return sourceSs || destSs;
}

function enrichGeo_(sourceSs, cepTab, data){
  const cepDigits = normalizeDigits_(data.CEP);
  const out = {
    RegiaoMacro: clean_(data.RegiaoMacro),
    BairroMacro: clean_(data.BairroMacro),
    MicroRegiao: clean_(data.MicroRegiao),
    Latitude: clean_(data.Latitude),
    Longitude: clean_(data.Longitude),
    GeoStatus: clean_(data.GeoStatus),
    GeoFonte: clean_(data.GeoFonte)
  };

  if(out.Latitude && out.Longitude && !out.GeoStatus){
    out.GeoStatus = 'LATLNG_EXISTENTE';
    out.GeoFonte = out.GeoFonte || 'DADO_ORIGEM';
  }

  const cepMatch = lookupCepRegion_(sourceSs, cepTab, cepDigits);
  if(cepMatch){
    out.RegiaoMacro = cepMatch.regiao;
    out.BairroMacro = cepMatch.bairroMacro;
    out.MicroRegiao = cepMatch.microRegiao;
    out.GeoStatus = out.GeoStatus || 'CEP_MAPEADO';
    out.GeoFonte = out.GeoFonte || 'ABA_CEP';
  }

  if((!out.Latitude || !out.Longitude) && (cepDigits || data.Endereco || data.Bairro || data.Cidade)){
    const geo = geocodeCandidate_(data);
    if(geo.ok){
      out.Latitude = geo.latitude;
      out.Longitude = geo.longitude;
      out.GeoStatus = out.GeoStatus || 'GEOCODIFICADO';
      out.GeoFonte = out.GeoFonte || geo.fonte;
    } else if(!out.GeoStatus) {
      out.GeoStatus = geo.status;
      out.GeoFonte = geo.fonte;
    }
  }

  if(!out.GeoStatus) out.GeoStatus = out.RegiaoMacro ? 'MAPEADO_SEM_LATLNG' : 'SEM_GEO';
  return out;
}

function geocodeCandidate_(data){
  const candidates = [];
  const cep = clean_(data.CEP);
  const city = clean_(data.Cidade);
  const uf = clean_(data.EstadoUF) || 'SP';
  const bairro = clean_(data.Bairro);
  const endereco = clean_(data.Endereco);
  if(cep) candidates.push(cep + ', Brasil');
  if(endereco && city) candidates.push([endereco, bairro, city, uf, 'Brasil'].filter(Boolean).join(', '));
  if(bairro && city) candidates.push([bairro, city, uf, 'Brasil'].filter(Boolean).join(', '));
  if(city) candidates.push([city, uf, 'Brasil'].filter(Boolean).join(', '));

  for(let i = 0; i < candidates.length; i++){
    try {
      const resp = Maps.newGeocoder().setLanguage('pt-BR').geocode(candidates[i]);
      const result = ((resp || {}).results || [])[0];
      const loc = result && result.geometry && result.geometry.location;
      if(loc && loc.lat != null && loc.lng != null){
        return { ok:true, latitude:String(loc.lat), longitude:String(loc.lng), fonte:'MAPS_GEOCODER' };
      }
    } catch(err) {}
  }
  return { ok:false, status:'GEO_NAO_LOCALIZADO', fonte:'MAPS_GEOCODER' };
}

function lookupCepRegion_(sourceSs, cepTab, cepDigits){
  if(!cepDigits || cepDigits.length < 5) return null;
  const sh = sourceSs.getSheetByName(cepTab);
  if(!sh) return null;
  const values = sh.getDataRange().getDisplayValues();
  const prefix = Number(cepDigits.slice(0, 5));
  for(let i = 0; i < values.length; i++){
    const row = values[i] || [];
    const regiao = clean_(row[0]);
    const bairroMacro = clean_(row[1]);
    const start = normalizeDigits_(row[2]);
    const end = normalizeDigits_(row[3]);
    if(!regiao || !bairroMacro || !start || !end) continue;
    const startNum = Number(start);
    const endNum = Number(end);
    if(prefix >= startNum && prefix <= endNum){
      return {
        regiao: regiao,
        bairroMacro: bairroMacro,
        microRegiao: clean_(bairroMacro.split('–')[0].split('-')[0])
      };
    }
  }
  return null;
}

function sanitizeCandidateData_(data){
  const out = Object.assign({}, data || {});
  out.Email = sanitizeEmail_(out.Email);
  out.Telefone1 = clean_(out.Telefone1);
  out.Telefone2 = clean_(out.Telefone2);
  out.Tel2 = clean_(out.Tel2 || out.Telefone2);
  out.TelefonesBrutos = cleanMultiline_(out.TelefonesBrutos).replace(/\n+/g, ' | ');
  out.Telefone1Digitos = normalizeDigits_(out.Telefone1Digitos || out.Telefone1);
  out.Telefone2Digitos = normalizeDigits_(out.Telefone2Digitos || out.Telefone2 || out.Tel2);
  out.Whatsapp = toBrazilWhatsapp_(out.Whatsapp || out.Telefone1 || out.Telefone2 || out.Tel2);

  out.NomeCompleto = sanitizePersonName_(out.NomeCompleto);
  out.PrimeiroNome = sanitizeFirstName_(out.PrimeiroNome || out.NomeCompleto);
  out.Cargo = sanitizeTitleField_(out.Cargo || out.ProfissaoOuCargo);
  out.ProfissaoOuCargo = sanitizeTitleField_(out.ProfissaoOuCargo || out.Cargo);
  out.UltimoSalario = sanitizeMoneyText_(out.UltimoSalario);
  out.PretensaoSalarial = sanitizeMoneyText_(out.PretensaoSalarial);
  out.Sexo = sanitizeSexo_(out.Sexo);
  out.EstadoCivil = sanitizeEstadoCivil_(out.EstadoCivil);

  const birthInfo = sanitizeBirthAndAge_(out.DataNascimento || out.Nascimento, out.IdadeAnos, out.IdadeTexto);
  out.DataNascimento = birthInfo.date || '';
  out.Nascimento = out.DataNascimento;
  out.IdadeAnos = birthInfo.age || '';
  out.IdadeTexto = birthInfo.age ? String(birthInfo.age) + ' anos' : sanitizeAgeText_(out.IdadeTexto);

  out.Cidade = sanitizeCity_(out.Cidade);
  out.EstadoUF = sanitizeUF_(out.EstadoUF || inferUF_(out.Cidade));

  const bairroFix = sanitizeNeighborhoodContext_(out.Bairro, out.Endereco, out.Cidade, out.RegiaoMacro, out.BairroMacro);
  out.Bairro = bairroFix.bairro;
  out.Endereco = bairroFix.endereco;
  out.CEP = normalizeCep_(out.CEP);
  out.Pais = sanitizeCountry_(out.Pais);
  out.RegiaoMacro = sanitizeRegionLabel_(out.RegiaoMacro);
  out.MicroRegiao = sanitizeNeighborhoodComposite_(out.MicroRegiao);
  out.BairroMacro = sanitizeNeighborhoodComposite_(out.BairroMacro);

  out.ResumoCV = cleanMultiline_(out.ResumoCV);
  out.Qualificacoes = cleanMultiline_(out.Qualificacoes);
  out.ExperienciaProfissional = sanitizeExperienceBlock_(out.ExperienciaProfissional);
  out.Idiomas = cleanMultiline_(out.Idiomas);
  out.AtualizadoEm = sanitizeUpdatedText_(out.AtualizadoEm);
  out.empreendimento = clean_(out.empreendimento);
  out.profile_url = clean_(out.profile_url || out.Curriculo);
  out.Status = clean_(out.Status);
  out.UltimaAtualizacao = clean_(out.UltimaAtualizacao);
  out.ProfissaoOuCargo = sanitizeTitleField_(out.ProfissaoOuCargo || out.Cargo);
  out.RegiaoCidade = clean_(out.RegiaoCidade);
  out.ForcaMatchCurriculo = clean_(out.ForcaMatchCurriculo);
  out.FILTRO_CASCATA_HTML = clean_(out.FILTRO_CASCATA_HTML);
  out.Origem = 'Catho';
  return out;
}

function sanitizeUpdatedText_(txt){
  const t = clean_(txt).toLowerCase();
  if(!t) return '';
  if(/^há\s+/.test(t)) return 'há ' + t.replace(/^há\s+/i, '');
  return t;
}

function sanitizeExperienceBlock_(txt){
  return cleanMultiline_(txt)
    .replace(/\s*Cargo\s*:/gi, '\nCargo: ')
    .replace(/\s*Último salário\s*:/gi, '\nÚltimo salário: ')
    .replace(/\s*Principais atividades\s*:/gi, '\nPrincipais atividades: ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function sanitizeEmail_(email){ return clean_(email).toLowerCase(); }

function sanitizeMoneyText_(txt){
  const t = clean_(txt);
  if(!t) return '';
  return t.replace(/\s+/g, ' ').replace(/r\$\s*/i, 'R$ ');
}

function sanitizeCountry_(txt){
  const t = clean_(txt).toLowerCase();
  if(!t) return 'Brasil';
  if(t === 'brasil') return 'Brasil';
  return smartTitleCase_(t);
}

function sanitizeUF_(uf){ return clean_(uf).replace(/[^A-Za-z]/g, '').slice(0,2).toUpperCase(); }

function sanitizeSexo_(txt){
  const t = clean_(txt).toLowerCase();
  if(!t) return '';
  if(t.indexOf('fem') === 0) return 'Feminino';
  if(t.indexOf('masc') === 0) return 'Masculino';
  if(t.indexOf('nao') === 0 || t.indexOf('não') === 0) return 'Não informado';
  return smartTitleCase_(t);
}

function sanitizeEstadoCivil_(txt){
  const t = clean_(txt).toLowerCase();
  if(!t) return '';
  if(t.indexOf('não') === 0 || t.indexOf('nao') === 0) return 'Não informado';
  const map = {
    'solteiro': 'Solteiro', 'solteira': 'Solteira', 'casado': 'Casado', 'casada': 'Casada',
    'divorciado': 'Divorciado', 'divorciada': 'Divorciada', 'separado': 'Separado', 'separada': 'Separada',
    'viuvo': 'Viúvo', 'viúva': 'Viúva', 'viuva': 'Viúva'
  };
  return map[t] || smartTitleCase_(t);
}

function sanitizePersonName_(txt){ return smartTitleCase_(clean_(txt)); }
function sanitizeFirstName_(txt){ return smartTitleCase_(clean_(String(txt || '').split(/\s+/)[0] || '')); }
function sanitizeTitleField_(txt){ return smartTitleCase_(clean_(txt)); }
function sanitizeLocationLabel_(txt){ return smartTitleCaseComposite_(clean_(txt)); }
function sanitizeAddress_(txt){ return smartTitleCaseComposite_(clean_(txt)); }
function sanitizeCity_(txt){ return smartTitleCase_(normalizeCity_(txt)); }

function sanitizeNeighborhoodContext_(bairro, endereco, cidade, regiaoMacro, bairroMacro){
  let bairroRaw = clean_(bairro);
  let enderecoRaw = clean_(endereco);

  if(isAddressLikeLocation_(bairroRaw)){
    if(!enderecoRaw) enderecoRaw = bairroRaw;
    bairroRaw = '';
  }

  let bairroSan = sanitizeNeighborhoodLabel_(bairroRaw, cidade, regiaoMacro, bairroMacro);
  let enderecoSan = sanitizeAddress_(enderecoRaw);

  if(!bairroSan && enderecoSan){
    const inferred = inferNeighborhoodFromAddress_(enderecoSan);
    if(inferred) bairroSan = sanitizeNeighborhoodLabel_(inferred, cidade, regiaoMacro, bairroMacro);
  }

  return { bairro: bairroSan, endereco: enderecoSan };
}

function sanitizeNeighborhoodComposite_(txt){
  return String(txt || '')
    .split(/\n/)
    .map(function(line){ return sanitizeNeighborhoodLabel_(line); })
    .filter(Boolean)
    .join('\n')
    .trim();
}

function sanitizeNeighborhoodLabel_(txt, cidade, regiaoMacro, bairroMacro){
  let t = clean_(txt);
  if(!t) return '';
  t = normalizeNeighborhoodAbbreviations_(t);
  t = t.replace(/\b(n[aã]o informado|sem informa[cç][aã]o|nao consta|não consta|ignorado)\b/ig, '').trim();
  t = t.replace(/\bcep\b.*$/i, '').trim();
  t = t.replace(/[;,]+$/g, '').trim();
  t = t.replace(/\s{2,}/g, ' ').trim();
  if(!t) return '';
  if(/^zona\s+(norte|sul|leste|oeste)$/i.test(t)) return '';
  if(cidade && normalizeComparable_(t) === normalizeComparable_(cidade)) return '';
  if(regiaoMacro && normalizeComparable_(t) === normalizeComparable_(regiaoMacro)) return '';
  if(bairroMacro && normalizeComparable_(t) === normalizeComparable_(bairroMacro)) return '';
  if(isAddressLikeLocation_(t)) return '';
  if(/\d{5}-?\d{3}/.test(t)) return '';
  t = smartTitleCaseComposite_(t);
  t = normalizeRomanNumeralsInText_(t);
  t = t.replace(/\bIi\b/g, 'II').replace(/\bIii\b/g, 'III').replace(/\bIv\b/g, 'IV').replace(/\bVi\b/g, 'VI').replace(/\bVii\b/g, 'VII').replace(/\bViii\b/g, 'VIII').replace(/\bIx\b/g, 'IX').replace(/\bXi\b/g, 'XI').replace(/\bXii\b/g, 'XII').replace(/\bXiii\b/g, 'XIII').replace(/\bXiv\b/g, 'XIV').replace(/\bXv\b/g, 'XV');
  return t;
}

function normalizeNeighborhoodAbbreviations_(txt){
  return clean_(txt)
    .replace(/\bjd\.?\b/ig, 'Jardim')
    .replace(/\bjdmo?\.?\b/ig, 'Jardim')
    .replace(/\bvl\.?\b/ig, 'Vila')
    .replace(/\bpq\.?\b/ig, 'Parque')
    .replace(/\bcj\.?\b/ig, 'Conjunto')
    .replace(/\bcond\.?\b/ig, 'Condominio')
    .replace(/\bres\.?\b/ig, 'Residencial')
    .replace(/\bnuc\.?\b/ig, 'Nucleo')
    .replace(/\bsta\.?\b/ig, 'Santa')
    .replace(/\bsto\.?\b/ig, 'Santo')
    .replace(/\bjdm\b/ig, 'Jardim')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function isAddressLikeLocation_(txt){
  const t = clean_(txt).toLowerCase();
  if(!t) return false;
  if(/\b(rua|r\.?|avenida|av\.?|travessa|trav\.?|alameda|estrada|rodovia|pra[çc]a|largo|viela|beco|quadra|qd\.?|lote|lt\.?|condom[ií]nio|cond\.?|km)\b/.test(t)) return true;
  if(/\bcep\b/.test(t)) return true;
  if(/\d{1,5}/.test(t) && /\b(rua|avenida|av\.?|travessa|alameda|estrada|rodovia|pra[çc]a|largo|viela|beco)\b/.test(t)) return true;
  return false;
}

function inferNeighborhoodFromAddress_(txt){
  const t = clean_(txt);
  if(!t) return '';
  const parts = t.split(/\s+-\s+|\s*,\s*/).map(clean_).filter(Boolean);
  for(let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if(!p || isAddressLikeLocation_(p)) continue;
    if(/\d/.test(p) && p.split(/\s+/).length <= 2) continue;
    if(/^(apto|apartamento|casa|bloco|andar|fundos|frente)$/i.test(p)) continue;
    return p;
  }
  return '';
}

function normalizeComparable_(txt){
  return String(txt || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function normalizeRomanNumeralsInText_(txt){
  return String(txt || '').replace(/\b([ivxlcdm]{2,6})\b/gi, function(m){ return m.toUpperCase(); });
}

function sanitizeRegionLabel_(txt){
  const t = clean_(txt).toLowerCase();
  const map = {
    'centro': 'Centro',
    'zona norte': 'Zona Norte',
    'zona sul': 'Zona Sul',
    'zona leste': 'Zona Leste',
    'zona oeste': 'Zona Oeste'
  };
  return map[t] || smartTitleCaseComposite_(txt);
}

function sanitizeAgeText_(txt){
  const age = sanitizeAgeNumber_(txt);
  return age ? String(age) + ' anos' : clean_(txt);
}

function sanitizeAgeNumber_(value){
  const raw = String(value == null ? '' : value);
  const direct = Number(raw);
  if(direct >= 14 && direct <= 80) return direct;
  let digits = normalizeDigits_(raw);
  if(!digits) return '';
  if(digits.length >= 3) {
    const last2 = Number(digits.slice(-2));
    if(last2 >= 14 && last2 <= 80) return last2;
  }
  const parsed = Number(digits);
  if(parsed >= 14 && parsed <= 80) return parsed;
  return '';
}

function sanitizeBirthAndAge_(dateText, ageRaw, ageText){
  const base = parseBrDateLoose_(dateText);
  let age = sanitizeAgeNumber_(ageRaw);
  if(!age) age = sanitizeAgeNumber_(ageText);
  let date = '';

  if(base && base.day && base.month){
    let year = base.year;
    if(!year || year < 1930 || year > (new Date().getFullYear())){
      if(age) year = inferBirthYearFromAge_(age, base.day, base.month);
    }
    if(year && isValidBrDate_(base.day, base.month, year)){
      date = formatBrDate_(base.day, base.month, year);
      const computedAge = computeAgeFromBrDate_(base.day, base.month, year);
      if(computedAge >= 14 && computedAge <= 80){
        if(!age || Math.abs(Number(age) - computedAge) > 1) age = computedAge;
      }
    }
  }

  if(!date && age && base && base.day && base.month){
    const year = inferBirthYearFromAge_(age, base.day, base.month);
    if(isValidBrDate_(base.day, base.month, year)) date = formatBrDate_(base.day, base.month, year);
  }

  return { date: date, age: age };
}

function parseBrDateLoose_(txt){
  const m = clean_(txt).match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
  if(!m) return null;
  let year = Number(m[3]);
  if(year < 100) year += 1900;
  return { day: Number(m[1]), month: Number(m[2]), year: year };
}

function inferBirthYearFromAge_(age, day, month){
  const now = new Date();
  let year = now.getFullYear() - Number(age);
  const hadBirthday = (now.getMonth() + 1 > month) || ((now.getMonth() + 1 === month) && now.getDate() >= day);
  if(!hadBirthday) year -= 1;
  return year;
}

function computeAgeFromBrDate_(day, month, year){
  const now = new Date();
  let age = now.getFullYear() - Number(year);
  const hadBirthday = (now.getMonth() + 1 > month) || ((now.getMonth() + 1 === month) && now.getDate() >= day);
  if(!hadBirthday) age -= 1;
  return age;
}

function isValidBrDate_(day, month, year){
  const d = new Date(year, month - 1, day);
  return d.getFullYear() === Number(year) && d.getMonth() === Number(month) - 1 && d.getDate() === Number(day);
}

function formatBrDate_(day, month, year){
  return String(day).padStart(2, '0') + '/' + String(month).padStart(2, '0') + '/' + String(year);
}

function smartTitleCaseComposite_(txt){
  return String(txt || '')
    .split(/\n/)
    .map(function(line){
      return line.split(/\s*([\/–-])\s*/).map(function(part){
        if(part === '/' || part === '–' || part === '-') return ' ' + part + ' ';
        return smartTitleCase_(part);
      }).join('').replace(/\s{2,}/g, ' ').trim();
    })
    .join('\n')
    .trim();
}

function smartTitleCase_(txt, opts){
  const options = opts || {};
  const particles = { de:1, da:1, do:1, das:1, dos:1, e:1, d:1, del:1, della:1, di:1, du:1, van:1, von:1, la:1, le:1 };
  const words = clean_(txt).split(/\s+/).filter(Boolean);
  return words.map(function(word, idx){
    return smartWordCase_(word, idx === 0, particles, options);
  }).join(' ');
}

function smartWordCase_(word, isFirst, particles, options){
  if(word.indexOf('/') >= 0) return word.split('/').map(function(p, idx){ return smartWordCase_(p, isFirst && idx === 0, particles, options); }).join('/');
  if(word.indexOf('-') >= 0) return word.split('-').map(function(p, idx){ return smartWordCase_(p, isFirst && idx === 0, particles, options); }).join('-');
  if(word.indexOf('–') >= 0) return word.split('–').map(function(p, idx){ return smartWordCase_(p, isFirst && idx === 0, particles, options); }).join('–');
  if(/[0-9]/.test(word)) return word.toUpperCase();
  if(/^[A-ZÀ-Ý]{2,5}$/.test(word)) return word.toUpperCase();
  if(/^(sp|rj|mg|pr|sc|rs|ba|go|df|pe|ce|pa|am|mt|ms|es|rn|pb|al|se|to|ma|pi|ro|rr|ap|ac)$/i.test(word)) return word.toUpperCase();
  const lower = String(word || '').toLowerCase();
  if(!isFirst && particles[lower]) return lower;
  if(options.forceLowercaseRemainder) return lower;
  return lower ? lower.charAt(0).toUpperCase() + lower.slice(1) : '';
}

function toBrazilWhatsapp_(phone){
  const digits = normalizeDigits_(phone);
  if(!digits) return '';
  if(digits.length === 13 && digits.indexOf('55') === 0) return digits;
  if(digits.length === 11 || digits.length === 10) return '55' + digits;
  return digits;
}

function cleanMultiline_(value){
  return String(value == null ? '' : value)
    .replace(/\r/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function upsertDestRow_(destSs, destTab, data){
  const sh = getOrCreateSheet_(destSs, destTab);
  ensureHeaderRow_(sh, 1, NT_DEST_HEADERS);
  const map = headerMapFromRow_(sh, 1);
  const key = clean_(data.Curriculo);
  let targetRow = sh.getLastRow() + 1;
  if(key && sh.getLastRow() >= 2){
    const range = sh.getRange(2, map.Curriculo, sh.getLastRow() - 1, 1);
    const found = range.createTextFinder(key).matchEntireCell(true).findNext();
    if(found) targetRow = found.getRow();
  }
  const row = buildDestRow_(data, NT_DEST_HEADERS);
  sh.getRange(targetRow, 1, 1, row.length).setValues([row]);
}

function buildDestRow_(data, headers){
  return headers.map(function(h){
    switch(h){
      case 'Curriculo': return data.Curriculo;
      case 'SourceSheetId': return data.SourceSheetId;
      case 'SourceTab': return data.SourceTab;
      case 'SourceRow': return data.SourceRow;
      case 'NomeCompleto': return data.NomeCompleto;
      case 'PrimeiroNome': return data.PrimeiroNome;
      case 'Email': return data.Email;
      case 'Telefone1': return data.Telefone1;
      case 'Telefone2': return data.Telefone2;
      case 'Tel2': return data.Tel2;
      case 'Whatsapp': return data.Whatsapp;
      case 'TelefonesBrutos': return data.TelefonesBrutos;
      case 'Telefone1Digitos': return data.Telefone1Digitos;
      case 'Telefone2Digitos': return data.Telefone2Digitos;
      case 'Cargo': return data.Cargo || data.ProfissaoOuCargo;
      case 'UltimoSalario': return data.UltimoSalario;
      case 'PretensaoSalarial': return data.PretensaoSalarial;
      case 'Sexo': return data.Sexo;
      case 'EstadoCivil': return data.EstadoCivil;
      case 'IdadeTexto': return data.IdadeTexto;
      case 'IdadeAnos': return data.IdadeAnos;
      case 'Nascimento': return data.Nascimento || data.DataNascimento;
      case 'DataNascimento': return data.DataNascimento;
      case 'Cidade': return data.Cidade;
      case 'EstadoUF': return data.EstadoUF;
      case 'Bairro': return data.Bairro;
      case 'Endereco': return data.Endereco;
      case 'CEP': return data.CEP;
      case 'Pais': return data.Pais;
      case 'RegiaoMacro': return data.RegiaoMacro;
      case 'MicroRegiao': return data.MicroRegiao;
      case 'BairroMacro': return data.BairroMacro;
      case 'Latitude': return data.Latitude;
      case 'Longitude': return data.Longitude;
      case 'GeoStatus': return data.GeoStatus;
      case 'GeoFonte': return data.GeoFonte;
      case 'ResumoCV': return data.ResumoCV;
      case 'Qualificacoes': return data.Qualificacoes;
      case 'ExperienciaProfissional': return data.ExperienciaProfissional;
      case 'Idiomas': return data.Idiomas;
      case 'AtualizadoEm': return data.AtualizadoEm;
      case 'DataHoraISO': return data.DataHoraISO;
      case 'Origem': return 'Catho';
      case 'StatusProcessamento': return data.StatusProcessamento;
      case 'ErroProcessamento': return data.ErroProcessamento;
      case 'ColetadoEm': return data.ColetadoEm;
      case 'ForcaMatchCurriculo': return data.ForcaMatchCurriculo;
      case 'FILTRO_CASCATA_HTML': return data.FILTRO_CASCATA_HTML;
      case 'empreendimento': return data.empreendimento;
      case 'profile_url': return data.profile_url || data.Curriculo;
      case 'Status': return data.Status;
      case 'UltimaAtualizacao': return data.UltimaAtualizacao;
      case 'ProfissaoOuCargo': return data.ProfissaoOuCargo || data.Cargo;
      case 'RegiaoCidade': return data.RegiaoCidade;
      default: return data[h] || '';
    }
  });
}


function ensureSourceQueueColumns_(sh, headerRow){
  ensureHeaderRow_(sh, headerRow, ['Status','UltimaAtualizacao']);
}

function findNextPendingRow_(sh, meta, startRow, endRow){
  if(!startRow || !endRow || startRow > endRow) return null;
  const map = meta.map || {};
  const colStatus = getCol_(map, ['Status','status']) || 0;
  const takeLimit = READ_CHUNK;
  let cursor = startRow;
  while(cursor <= endRow){
    const take = Math.min(takeLimit, endRow - cursor + 1);
    const block = sh.getRange(cursor, 1, take, sh.getLastColumn()).getDisplayValues();
    for(let i = 0; i < block.length; i++){
      const rowIndex = cursor + i;
      const row = rowObject_(block[i], map);
      const curriculo = clean_(pickFirst_(row, ['Curriculo','curriculo','profile_url','PerfilURL','Perfil Url','PerfilURL','Currículo','URL','Link']));
      if(!curriculo) continue;
      const status = colStatus ? clean_(block[i][colStatus - 1]).toUpperCase() : '';
      if(status && status !== 'PENDENTE' && status.indexOf('PENDENTE |') !== 0) continue;
      return { rowIndex: rowIndex, curriculo: curriculo, row: row };
    }
    cursor += take;
  }
  return null;
}

function updateSourceQueueRow_(sh, meta, rowIndex, data, ok, errorMsg){
  const map = meta.map || {};
  const colStatus = getCol_(map, ['Status','status']);
  const colUp = getCol_(map, ['UltimaAtualizacao','ÚltimaAtualização','ultimaatualizacao']);
  if(colStatus) sh.getRange(rowIndex, colStatus).setValue(ok ? 'OK' : buildRetryStatus_(errorMsg));
  if(colUp) sh.getRange(rowIndex, colUp).setValue(new Date());

  const patch = {
    NomeCompleto: data.NomeCompleto,
    PrimeiroNome: data.PrimeiroNome,
    ProfissaoOuCargo: data.ProfissaoOuCargo || data.Cargo,
    Cargo: data.Cargo || data.ProfissaoOuCargo,
    Telefone1: data.Telefone1,
    Telefone2: data.Telefone2,
    TelefonesBrutos: data.TelefonesBrutos,
    Email: data.Email,
    PretensaoSalarial: data.PretensaoSalarial,
    AtualizadoEm: data.AtualizadoEm,
    DataNascimento: data.DataNascimento,
    Cidade: data.Cidade,
    EstadoUF: data.EstadoUF,
    Bairro: data.Bairro,
    Endereco: data.Endereco,
    CEP: data.CEP,
    RegiaoMacro: data.RegiaoMacro,
    MicroRegiao: data.MicroRegiao,
    BairroMacro: data.BairroMacro,
    Latitude: data.Latitude,
    Longitude: data.Longitude,
    GeoStatus: data.GeoStatus,
    GeoFonte: data.GeoFonte,
    DataHoraISO: data.DataHoraISO,
    ForcaMatchCurriculo: data.ForcaMatchCurriculo,
    FILTRO_CASCATA_HTML: data.FILTRO_CASCATA_HTML,
    empreendimento: data.empreendimento,
    profile_url: data.profile_url || data.Curriculo,
    Status: data.Status,
    UltimaAtualizacao: data.UltimaAtualizacao,
    RegiaoCidade: data.RegiaoCidade
  };
  Object.keys(patch).forEach(function(k){
    const col = getCol_(map, [k]);
    if(col) sh.getRange(rowIndex, col).setValue(patch[k] || '');
  });
}

function getCol_(map, names){
  for(let i = 0; i < (names || []).length; i++){
    const name = names[i];
    if(map[name]) return map[name];
    const lower = String(name || '').toLowerCase();
    if(map[lower]) return map[lower];
  }
  return 0;
}

function readSourceHeader_(sh){
  let headerRow = findHeaderRow_(sh, ['Curriculo','profile_url','PerfilURL','Currículo','URL','Link']);
  if(!headerRow && sh.getLastRow() >= 1){
    const row1 = sh.getRange(1, 1, 1, Math.max(2, sh.getLastColumn())).getDisplayValues()[0] || [];
    const joined = row1.map(clean_).join(' | ').toLowerCase();
    if(joined.indexOf('profile') >= 0 || joined.indexOf('curriculo') >= 0 || joined.indexOf('currículo') >= 0 || joined.indexOf('url') >= 0) headerRow = 1;
  }
  return { headerRow: headerRow, map: headerRow ? headerMapFromRow_(sh, headerRow) : {} };
}

function findHeaderRow_(sh, tokens){
  const maxRows = Math.min(15, Math.max(1, sh.getLastRow()));
  if(maxRows < 1) return 0;
  const values = sh.getRange(1, 1, maxRows, Math.max(1, sh.getLastColumn())).getDisplayValues();
  for(let r = 0; r < values.length; r++){
    const joined = values[r].map(clean_).join(' | ').toLowerCase();
    let hits = 0;
    (tokens || []).forEach(function(t){ if(joined.indexOf(String(t).toLowerCase()) >= 0) hits++; });
    if(hits >= 2) return r + 1;
  }
  return 0;
}

function ensureHeaderRow_(sh, headerRow, headers){
  const current = sh.getRange(headerRow, 1, 1, Math.max(1, sh.getLastColumn())).getDisplayValues()[0] || [];
  if(!current.some(clean_)){
    sh.getRange(headerRow, 1, 1, headers.length).setValues([headers]);
    return;
  }
  const normMap = {};
  current.forEach(function(h, i){ const k = clean_(h); if(k) normMap[k] = i + 1; });
  const toAdd = [];
  headers.forEach(function(h){ if(!normMap[h]) toAdd.push(h); });
  if(toAdd.length){
    sh.insertColumnsAfter(Math.max(1, sh.getLastColumn()), toAdd.length);
    sh.getRange(headerRow, current.length + 1, 1, toAdd.length).setValues([toAdd]);
  }
}

function headerMapFromRow_(sh, headerRow){
  const headers = sh.getRange(headerRow, 1, 1, sh.getLastColumn()).getDisplayValues()[0] || [];
  const map = {};
  headers.forEach(function(h, i){ if(clean_(h)) map[clean_(h)] = i + 1; });
  return map;
}

function rowObject_(rowArray, map){
  const out = {};
  Object.keys(map || {}).forEach(function(k){ out[k] = rowArray[(map[k] || 1) - 1] || ''; });
  return out;
}

function getRowByIndex_(sh, meta, rowIndex){
  const vals = sh.getRange(rowIndex, 1, 1, sh.getLastColumn()).getDisplayValues()[0] || [];
  return rowObject_(vals, meta.map);
}

function buildCursorKey_(sourceSheetId, sourceTab){
  return 'CURSOR__' + clean_(sourceSheetId) + '__' + clean_(sourceTab);
}

function getControlSheet_(ss){
  let sh = ss.getSheetByName(CTRL_SHEET);
  if(!sh){
    sh = ss.insertSheet(CTRL_SHEET);
    sh.getRange(1,1,1,2).setValues([['CHAVE','VALOR']]);
    sh.hideSheet();
  } else if(sh.getLastRow() < 1) {
    sh.getRange(1,1,1,2).setValues([['CHAVE','VALOR']]);
  }
  return sh;
}

function getControlValue_(ss, key, fallback){
  const sh = getControlSheet_(ss);
  const lastRow = sh.getLastRow();
  if(lastRow < 2) return fallback;
  const range = sh.getRange(2, 1, lastRow - 1, 1);
  const found = range.createTextFinder(clean_(key)).matchEntireCell(true).findNext();
  if(!found) return fallback;
  return clean_(sh.getRange(found.getRow(), 2).getDisplayValue()) || fallback;
}

function setControlValue_(ss, key, value){
  const sh = getControlSheet_(ss);
  const cleanKey = clean_(key);
  const lastRow = sh.getLastRow();
  let targetRow = lastRow + 1;
  if(lastRow >= 2){
    const found = sh.getRange(2,1,lastRow - 1,1).createTextFinder(cleanKey).matchEntireCell(true).findNext();
    if(found) targetRow = found.getRow();
  }
  sh.getRange(targetRow, 1, 1, 2).setValues([[cleanKey, value == null ? '' : String(value)]]);
}

function getOrCreateSheet_(ss, name){ return ss.getSheetByName(name) || ss.insertSheet(name); }
function resp_(obj){ return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function clean_(v){ return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
function normalizeDigits_(v){ return clean_(v).replace(/\D+/g, ''); }
function normalizeCep_(v){
  const digits = normalizeDigits_(v);
  if(digits.length === 8) return digits.slice(0,5) + '-' + digits.slice(5);
  return clean_(v);
}
function pickFirst_(obj, keys){
  for(let i = 0; i < keys.length; i++){
    const v = clean_(obj && obj[keys[i]]);
    if(v) return v;
  }
  return '';
}
function parseAge_(txt){
  const m = clean_(txt).match(/\d{1,2}/);
  return m ? Number(m[0]) : '';
}
function inferUF_(city){
  const m = clean_(city).match(/[-,]\s*([A-Z]{2})$/i);
  return m ? String(m[1]).toUpperCase() : '';
}
function normalizeCity_(city){ return clean_(city).replace(/\s+-\s+[A-Z]{2}$/i, '').trim(); }
function buildRetryStatus_(error){
  const msg = clean_(error);
  return msg ? 'PENDENTE | ERRO: ' + msg : 'PENDENTE';
}
