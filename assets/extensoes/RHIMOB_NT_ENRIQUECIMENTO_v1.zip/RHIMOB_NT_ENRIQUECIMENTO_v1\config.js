(function (global) {
  // WebApp do Apps Script publicado como /exec. Cole a URL depois de implantar
  // o GAS_WEBAPP_NT_ENRIQUECIMENTO_V1.gs.
  global.API_URL_DEFAULT = 'https://script.google.com/macros/s/SEU_DEPLOY_ID/exec';

  // Destino: Planilha Mãe — Novos Talentos (Enriquecimento Catho).
  // As abas (NOVOS, ATUALIZADOS, DADOS_COMPLETO, MAE) são criadas sozinhas
  // pelo WebApp na primeira gravação — não precisa criar na mão.
  global.DEFAULT_DEST_SHEET_ID = '1tdn1yZ1z3283381oi-sIp-U91xgfivT1xekYqnlOkxM';

  // Geolocalização: planilha auxiliar com a aba "cep" para região/micro/bairro macro.
  global.DEFAULT_GEO_SHEET_ID = '1rs6xO89y-2kU4z979YybpUfKd6XpJh9ijiQCbY17mUA';
  global.DEFAULT_CEP_TAB = 'cep';

  // Identifica qual dos 4 logins da Catho/PC coletou cada currículo — vai na
  // coluna "Login" de toda linha gravada. Preencha no popup em cada máquina.
  global.DEFAULT_OPERADOR = '';

  // A extensão coleta sozinha: não depende mais de nenhuma planilha de
  // origem/fila (Sinc) — os filtros de busca (link + nº de páginas) ficam
  // salvos localmente neste navegador e são gerenciados pelo popup.
  global.DEFAULT_INTERVAL_MIN = 45;
  global.EXT_NAME = 'RHIMOB_NT_ENRIQUECIMENTO_v1';
})(typeof self !== 'undefined' ? self : this);
