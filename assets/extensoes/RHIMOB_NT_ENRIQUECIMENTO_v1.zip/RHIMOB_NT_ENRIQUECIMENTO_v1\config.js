(function (global) {
  // Tudo aqui é interno — não aparece em nenhum campo do popup. O usuário só
  // vê login/senha (tela inicial) e, depois de entrar, filtro/páginas/delay.

  // WebApp do Apps Script publicado como /exec.
  global.API_URL_DEFAULT = 'https://script.google.com/macros/s/AKfycbw74yp-oeyMrjp81ygHWdLZ7bLhs0U7zZ542yIAThWjxWLfUWwta2nCtdL50U6EqYDU/exec';

  // Destino: Planilha Mãe — Novos Talentos (Enriquecimento Catho).
  // As abas (NOVOS, ATUALIZADOS, DADOS_COMPLETO, MAE, ERROS_EXTRACAO) são
  // criadas sozinhas pelo WebApp na primeira gravação.
  global.DEFAULT_DEST_SHEET_ID = '1tdn1yZ1z3283381oi-sIp-U91xgfivT1xekYqnlOkxM';

  // Geolocalização: planilha auxiliar com a aba "cep" para região/micro/bairro macro.
  global.DEFAULT_GEO_SHEET_ID = '1rs6xO89y-2kU4z979YybpUfKd6XpJh9ijiQCbY17mUA';
  global.DEFAULT_CEP_TAB = 'cep';

  // Espera entre cada currículo extraído — evita travar/sobrecarregar e
  // reduz risco de bloqueio da Catho por excesso de requisições seguidas.
  global.DEFAULT_DELAY_SEGUNDOS = 4;

  global.DEFAULT_INTERVAL_MIN = 45;
  global.EXT_NAME = 'RHIMOB_NT_ENRIQUECIMENTO_v1';
})(typeof self !== 'undefined' ? self : this);
