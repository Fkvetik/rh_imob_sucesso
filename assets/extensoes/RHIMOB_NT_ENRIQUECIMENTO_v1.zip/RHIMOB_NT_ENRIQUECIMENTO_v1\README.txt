RHIMOB_NT_ENRIQUECIMENTO v1.1.0

OBJETIVO
Extensão Chrome + WebApp Apps Script que coleta currículos da Catho SOZINHA
(via filtros de busca, sem depender de nenhuma planilha de origem/fila) e
alimenta a Novos Talentos (Supabase pufxvskozfdvfscqnays) direto — sem
duplicar quem já está na base. Reescrita a partir da antiga
RHIMOB_CATHO_SINC_ENTRADA_GEO, que dependia de uma aba "Sinc" alimentada
na mão e gravava tudo numa planilha "PLATAFORMA CATHO" sem checar
duplicidade nenhuma.

FLUXO
1) Você cola no popup um ou mais links de busca da Catho já filtrados
   (cargo, cidade etc. — o mesmo link que aparece na barra de endereço
   depois de aplicar os filtros no site da Catho) + quantas páginas varrer.
2) A extensão abre cada link, rola a página, coleta os links de currículo
   de todas as páginas configuradas (mesma técnica do Catho Coletor).
3) Abre cada currículo, revela telefone/e-mail, extrai dados pessoais,
   cargo, CEP, CV completo.
4) O WebApp geocodifica (faixas de CEP embutidas) e checa o TELEFONE
   contra a Novos Talentos:
   - Não existe -> grava como NOVO talento no pool.
   - Existe, atualizado há menos de 2 anos -> não mexe, marca DADOS_COMPLETO.
   - Existe, com 2+ anos (ou sem data) -> ATUALIZA o MESMO registro com os
     dados novos (não cria duplicata, mesmo se o link do currículo mudou).
5) Toda linha processada também é espelhada na aba MAE, pra auditoria.
   Tudo fica só na planilha mãe — não existe mais planilha de origem.

MULTI-PC / MULTI-LOGIN (rodar em 3-4 computadores ao mesmo tempo)
Seguro por desenho: o WebApp usa um lock global (LockService) — cada
gravação processa uma de cada vez, então duas máquinas nunca colidem.
Preencha um nome diferente no campo "Operador / login" do popup em cada
PC (ex.: fernando, mariana, pc3, pc4) — isso fica gravado na coluna Login
de cada linha, pra você saber quem coletou o quê. Cada PC pode ter seus
próprios filtros de busca (ficam salvos localmente no navegador, via
chrome.storage.sync) — dá pra usar os 4 logins da Catho em paralelo,
cada um com um filtro/segmento diferente, ou todos com o mesmo.

PLANILHA MÃE (criada, vazia — as abas nascem sozinhas no primeiro envio)
https://docs.google.com/spreadsheets/d/1tdn1yZ1z3283381oi-sIp-U91xgfivT1xekYqnlOkxM/edit
Abas: NOVOS, ATUALIZADOS, DADOS_COMPLETO, MAE (espelho de tudo), ERROS_NT
(se a chamada pra Novos Talentos falhar, cai aqui pra reprocessar depois).

PRÉ-REQUISITO NO SUPABASE (rodar uma vez, projeto Novos Talentos)
Arquivo: NT_SUPABASE_BUSCAR_POR_TELEFONE.sql (está na pasta do Catho
Coletor, C:\Users\Fernando\Downloads\catho_coletor_v2\) — cria a função
de consulta por telefone. Sem isso, todo currículo vira "erro" no
roteamento (cai na aba ERROS_NT).

COMO INSTALAR A EXTENSÃO
1. Abra chrome://extensions em cada um dos PCs.
2. Ative "Modo do desenvolvedor".
3. "Carregar sem compactação" -> selecione esta pasta
   (RHIMOB_NT_ENRIQUECIMENTO_v1).
4. Abra o popup, preencha o campo "Operador / login" (diferente em cada
   PC), cole a URL do WebApp (veja abaixo) e adicione pelo menos um
   filtro de busca da Catho. Salvar configuração.

COMO PUBLICAR O WEBAPP (uma vez só — todos os PCs usam a mesma URL)
1. Abra script.google.com e crie um projeto novo (ou reaproveite o da
   RHIMOB_CATHO_SINC antiga, se preferir substituir).
2. Cole o conteúdo de GAS_WEBAPP_NT_ENRIQUECIMENTO_V1.gs.
3. Deploy -> New deployment -> Web app -> executar como você, acesso
   "Anyone".
4. Copie a URL /exec e cole no popup da extensão, em todos os PCs.

CAMPOS GRAVADOS (abas NOVOS / ATUALIZADOS / DADOS_COMPLETO / MAE)
Mesmos campos de sempre (dados pessoais, CEP/geo, CV completo) + novos:
Login (qual PC/operador coletou), AcaoRealizada (NOVO/ATUALIZADO/
DADOS_COMPLETO/ERRO_NT), TalentoKeyNT (chave na Novos Talentos),
DiasDesdeAtualizacaoNT, ErroNT.
