try { importScripts('config.js'); } catch(e) {}
const ALARM_NAME = "RHIMOB_NT_ENRIQUECIMENTO_ALARM";
let runningCycle = false;

chrome.runtime.onInstalled.addListener(async () => {
  const st = await chrome.storage.sync.get({running:false});
  if(st.running) await ensureAlarm();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if(alarm && alarm.name === ALARM_NAME) await runCycle();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg || !msg.type) return;
  (async () => {
    if(msg.type === "START"){ await ensureAlarm(); sendResponse({ok:true}); return; }
    if(msg.type === "STOP"){ await chrome.alarms.clear(ALARM_NAME); sendResponse({ok:true}); return; }
    if(msg.type === "RUN_ONCE"){ sendResponse(await runCycle()); return; }
    if(msg.type === "SEND_ONE"){
      const st = await getConfig();
      if(!st.operador || !st.senha) { sendResponse({ok:false, error:"Faça login no popup"}); return; }
      const resp = await enviarParaWebApp(st, msg.row || {});
      sendResponse(resp);
      return;
    }
    sendResponse({ok:false, error:"Tipo desconhecido"});
  })().catch(err => sendResponse({ok:false, error:String(err)}));
  return true;
});

// api/destSheetId/geoSheetId/cepTab são internos (config.js) — nunca vêm de
// campo de popup. Só operador/senha/delay/intervalo/filtros são escolha do
// usuário, guardados no storage.
async function getConfig(){
  const st = await chrome.storage.sync.get({
    operador: '',
    senha: '',
    delaySegundos: (typeof DEFAULT_DELAY_SEGUNDOS !== 'undefined' ? DEFAULT_DELAY_SEGUNDOS : 4),
    intervalMin: (typeof DEFAULT_INTERVAL_MIN !== 'undefined' ? DEFAULT_INTERVAL_MIN : 45),
    filtros: []
  });

  st.api = (typeof API_URL_DEFAULT !== 'undefined' ? API_URL_DEFAULT : '').trim();
  st.destSheetId = (typeof DEFAULT_DEST_SHEET_ID !== 'undefined' ? DEFAULT_DEST_SHEET_ID : '').trim();
  st.geoSheetId = (typeof DEFAULT_GEO_SHEET_ID !== 'undefined' ? DEFAULT_GEO_SHEET_ID : '').trim();
  st.cepTab = (typeof DEFAULT_CEP_TAB !== 'undefined' ? DEFAULT_CEP_TAB : 'cep').trim() || 'cep';
  st.operador = (st.operador || '').trim();
  st.senha = (st.senha || '').trim();
  st.delaySegundos = Math.max(1, parseInt(st.delaySegundos || 4, 10));
  st.intervalMin = Math.max(5, parseInt(st.intervalMin || 45, 10));
  st.filtros = Array.isArray(st.filtros) ? st.filtros : [];
  return st;
}

async function ensureAlarm(){
  const st = await getConfig();
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: st.intervalMin });
}

async function safeJson(resp){
  const text = await resp.text();
  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error(`WebApp não devolveu JSON. Resposta: ${text.slice(0,200)}...`); }
  if(!resp.ok) throw new Error(`HTTP ${resp.status}: ${text.slice(0,200)}`);
  return data;
}

function wait(ms){ return new Promise(r => setTimeout(r, ms)); }

async function waitForComplete(tabId, timeout=60000){
  const start = Date.now();
  while(Date.now()-start < timeout){
    const t = await chrome.tabs.get(tabId);
    if(t.status === 'complete') return;
    await wait(300);
  }
}

function normalizeUrl(u){
  try{
    const url = new URL(u);
    url.search = ""; url.hash = "";
    let p = url.pathname;
    if(!p.endsWith("/")) p += "/";
    return url.origin + p;
  }catch(e){
    return (u||"").split(/[?#]/)[0].replace(/\/?$/, "/");
  }
}

async function gotoPage(tabId, baseUrl, p){
  const u = new URL(baseUrl);
  u.searchParams.set('page', String(p));
  await chrome.tabs.update(tabId, { url: u.href });
  const start = Date.now();
  while(Date.now()-start < 15000){
    const t = await chrome.tabs.get(tabId);
    try{
      const cur = new URL(t.url||"");
      if((cur.searchParams.get('page')||'1') === String(p)) break;
    }catch(e){}
    await wait(200);
  }
  await waitForComplete(tabId).catch(()=>wait(800));
  await wait(600);
}

// Mesma técnica do Catho Coletor: injeta a coleta de links direto na página
// via chrome.scripting (não depende do content.js pra isso), varre todos os
// iframes, rola a página pra carregar resultados lazy-load.
async function scrapeAllFrames(tabId, scrollCfg){
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    args: [scrollCfg],
    func: async (sc) => {
      function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }
      const reProfile = /^https?:\/\/[^/]*catho\.com\.br\/curriculos\/(?!busca\/)[^?#]+/i;
      const out = new Set();
      const toAbs = (href) => { try{ return new URL(href, location.href).href; } catch { return ''; } };
      const isVisible = (el)=>{
        if(!el) return false;
        const cs = getComputedStyle(el);
        if(cs.visibility==='hidden' || cs.display==='none' || parseFloat(cs.opacity||'1')===0) return false;
        const r = el.getClientRects();
        return r && r.length>0;
      };
      const maxScroll = (sc && sc.maxScroll) || 6000;
      const pause = (sc && sc.scrollPause) || 600;
      let y = 0, step = Math.max(300, Math.floor(window.innerHeight*0.8));
      while(y < maxScroll){ y += step; window.scrollTo({top:y,behavior:'instant'}); await sleep(pause); }
      window.scrollTo({top:0,behavior:'instant'});

      document.querySelectorAll('a[href]').forEach(a=>{
        if(!isVisible(a)) return;
        const h = toAbs(a.getAttribute('href')||'');
        if(reProfile.test(h)) out.add(h.split(/[?#]/)[0].replace(/(?<!\/)$/,'/'));
      });
      document.querySelectorAll('[data-href]').forEach(el=>{
        if(!isVisible(el)) return;
        const h = toAbs(el.getAttribute('data-href')||'');
        if(reProfile.test(h)) out.add(h.split(/[?#]/)[0].replace(/(?<!\/)$/,'/'));
      });
      document.querySelectorAll('[onclick]').forEach(el=>{
        if(!isVisible(el)) return;
        const oc = String(el.getAttribute('onclick')||'');
        const m = oc.match(/https?:\/\/[^'"]*catho[^'"]*\/curriculos\/[^'"]+/i);
        if(m){
          const h = toAbs(m[0]);
          if(reProfile.test(h)) out.add(h.split(/[?#]/)[0].replace(/(?<!\/)$/,'/'));
        }
      });
      return Array.from(out);
    }
  });
  const all = new Set();
  (results||[]).forEach(r => (r && r.result || []).forEach(u => all.add(u)));
  return Array.from(all);
}

function sendMessageWhenReady(tabId, message, timeoutMs){
  return new Promise((resolve) => {
    const start = Date.now();
    const tick = async () => {
      if(Date.now()-start > timeoutMs){ resolve({ok:false, error:"Timeout carregando currículo"}); return; }
      try{
        const tab = await chrome.tabs.get(tabId);
        if(tab && tab.status === "complete"){
          chrome.tabs.sendMessage(tabId, message, (resp) => {
            const err = chrome.runtime.lastError;
            if(err) resolve({ok:false, error:"sendMessage: " + err.message});
            else resolve(resp);
          });
          return;
        }
      }catch(_){}
      setTimeout(tick, 350);
    };
    tick();
  });
}

async function openAndEnrich(url){
  const tabId = await new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active:false }, (tab) => {
      const err = chrome.runtime.lastError;
      if(err) reject(err); else resolve(tab.id);
    });
  });
  try{
    await waitForComplete(tabId).catch(()=>wait(1200));
    const resp = await sendMessageWhenReady(tabId, {type:"AUTO_SCRAPE"}, 30000);
    if(!resp || !resp.ok) throw new Error((resp && resp.error) || "Falha ao extrair dados");
    return resp.data;
  } finally {
    try{ await chrome.tabs.remove(tabId); }catch(_){}
  }
}

async function enviarParaWebApp(st, data){
  const body = {
    action:"append_manual",
    senha: st.senha,
    destSheetId: st.destSheetId,
    geoSheetId: st.geoSheetId,
    cepTab: st.cepTab,
    login: st.operador,
    data
  };
  const resp = await fetch(st.api, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body) });
  return await safeJson(resp);
}

// Registra na aba ERROS_EXTRACAO da planilha mãe — best-effort, nunca deixa
// o ciclo travar por causa disso (se até isso falhar, só perde o log, não
// para a coleta).
async function reportarErroExtracao(st, url, erro){
  try{
    const body = {
      action:"report_erro",
      senha: st.senha,
      login: st.operador,
      destSheetId: st.destSheetId,
      url,
      error: String((erro && erro.message) || erro || "")
    };
    await fetch(st.api, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body) });
  }catch(_){}
}

async function runCycle(){
  if(runningCycle) return {ok:true, msg:"Ciclo já em execução (skip)"};
  runningCycle = true;
  try{
    const st = await getConfig();
    if(!st.operador || !st.senha){
      return {ok:false, error:"Faça login no popup antes de rodar"};
    }
    const filtros = (st.filtros || []).filter(f => f.link && !f.pausado);
    if(!filtros.length){
      return {ok:false, error:"Nenhum filtro de busca cadastrado (ou todos pausados). Adicione um link de busca da Catho no popup."};
    }

    const scrollCfg = { maxScroll: 6000, scrollPause: 600 };
    const contagem = { NOVO:0, ATUALIZADO:0, DADOS_COMPLETO:0, ERRO_NT:0 };
    let totalPerfis = 0;

    for(const f of filtros){
      let all = [];
      const tabId = await new Promise((resolve, reject) => {
        chrome.tabs.create({ url: f.link, active:false }, (tab) => {
          const err = chrome.runtime.lastError;
          if(err) reject(err); else resolve(tab.id);
        });
      });
      try{
        await waitForComplete(tabId).catch(()=>wait(1500));
        all.push(...await scrapeAllFrames(tabId, scrollCfg));
        await wait(2000);

        const maxP = Math.max(1, f.paginas || 2);
        for(let p=2; p<=maxP; p++){
          await gotoPage(tabId, f.link, p);
          all.push(...await scrapeAllFrames(tabId, scrollCfg));
          await wait(2000);
        }
      } finally {
        try{ await chrome.tabs.remove(tabId); }catch(_){}
      }

      const unique = Array.from(new Set(all.map(normalizeUrl)));
      totalPerfis += unique.length;

      for(const url of unique){
        try{
          const data = await openAndEnrich(url);
          const resp = await enviarParaWebApp(st, data);
          if(resp && resp.acao && contagem.hasOwnProperty(resp.acao)) contagem[resp.acao]++;
        }catch(e){
          contagem.ERRO_NT++;
          await reportarErroExtracao(st, url, e);
        }
        await wait(st.delaySegundos * 1000);
      }
    }

    return {ok:true, msg:`Finalizado. Perfis encontrados: ${totalPerfis} — ${JSON.stringify(contagem)}`};
  } catch(e){
    return {ok:false, error:String(e)};
  } finally {
    runningCycle = false;
  }
}
