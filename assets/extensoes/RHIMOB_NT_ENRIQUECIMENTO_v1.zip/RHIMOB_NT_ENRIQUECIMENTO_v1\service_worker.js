try { importScripts('config.js'); } catch(e) {}
const ALARM_NAME = "RHIMOB_NT_ENRIQUECIMENTO_ALARM";
let runningCycle = false;

chrome.runtime.onInstalled.addListener(async () => {
  const st = await chrome.storage.sync.get({running:false});
  if(st.running) await ensureAlarm();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if(alarm && alarm.name === ALARM_NAME) await runCycle();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if(!msg || !msg.type) return;
  (async () => {
    if(msg.type === "START"){ await ensureAlarm(); sendResponse({ok:true}); return; }
    if(msg.type === "STOP"){ await chrome.alarms.clear(ALARM_NAME); sendResponse({ok:true}); return; }
    if(msg.type === "RUN_ONCE"){ sendResponse(await runCycle()); return; }
    if(msg.type === "SEND_ONE"){
      const st = await getConfig();
      if(!st.api || !st.destSheetId) { sendResponse({ok:false, error:"Configure WebApp URL e base de destino no popup"}); return; }
      const body = {
        action:"append_manual",
        sourceSheetId: st.sourceSheetId,
        sourceTab: st.sourceTab,
        destSheetId: st.destSheetId,
        geoSheetId: st.geoSheetId,
        cepTab: st.cepTab,
        login: st.operador,
        data: msg.row || {}
      };
      const resp = await fetch(st.api, {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)});
      sendResponse(await safeJson(resp));
      return;
    }
    sendResponse({ok:false, error:"Tipo desconhecido"});
  })().catch(err => sendResponse({ok:false, error:String(err)}));
  return true;
});

async function getConfig(){
  const st = await chrome.storage.sync.get({
    api: (typeof API_URL_DEFAULT !== 'undefined' ? API_URL_DEFAULT : ''),
    sourceSheetId: (typeof DEFAULT_SOURCE_SHEET_ID !== 'undefined' ? DEFAULT_SOURCE_SHEET_ID : ''),
    sourceTab: (typeof DEFAULT_SOURCE_TAB !== 'undefined' ? DEFAULT_SOURCE_TAB : 'Sinc'),
    destSheetId: (typeof DEFAULT_DEST_SHEET_ID !== 'undefined' ? DEFAULT_DEST_SHEET_ID : ''),
    geoSheetId: (typeof DEFAULT_GEO_SHEET_ID !== 'undefined' ? DEFAULT_GEO_SHEET_ID : ''),
    cepTab: (typeof DEFAULT_CEP_TAB !== 'undefined' ? DEFAULT_CEP_TAB : 'cep'),
    operador: (typeof DEFAULT_OPERADOR !== 'undefined' ? DEFAULT_OPERADOR : ''),
    intervalMin: (typeof DEFAULT_INTERVAL_MIN !== 'undefined' ? DEFAULT_INTERVAL_MIN : 17),
    perCycle: (typeof DEFAULT_PER_CYCLE !== 'undefined' ? DEFAULT_PER_CYCLE : 1)
  });

  st.api = (st.api || '').trim();
  st.sourceSheetId = (st.sourceSheetId || '').trim();
  st.sourceTab = (st.sourceTab || 'Sinc').trim() || 'Sinc';
  st.destSheetId = (st.destSheetId || '').trim();
  st.geoSheetId = (st.geoSheetId || '').trim();
  st.cepTab = (st.cepTab || 'cep').trim() || 'cep';
  st.operador = (st.operador || '').trim();
  st.intervalMin = Math.max(1, parseInt(st.intervalMin || 17, 10));
  st.perCycle = Math.max(1, parseInt(st.perCycle || 1, 10));
  return st;
}

async function ensureAlarm(){
  const st = await getConfig();
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: st.intervalMin });
}

async function safeJson(resp){
  const text = await resp.text();
  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error(`WebApp não devolveu JSON. Resposta: ${text.slice(0,200)}...`); }
  if(!resp.ok) throw new Error(`HTTP ${resp.status}: ${text.slice(0,200)}`);
  return data;
}

async function runCycle(){
  if(runningCycle) return {ok:true, msg:"Ciclo já em execução (skip)"};
  runningCycle = true;
  try{
    const st = await getConfig();
    if(!st.api || !st.sourceSheetId || !st.destSheetId){
      return {ok:false, error:"Configure WebApp URL, origem e base de destino no popup"};
    }
    if(!st.operador){
      return {ok:false, error:"Preencha o campo Operador/Login no popup antes de rodar (identifica qual PC/login coletou cada linha)"};
    }

    let processed = 0;
    const contagem = { NOVO:0, ATUALIZADO:0, DADOS_COMPLETO:0, ERRO_NT:0 };
    for(let i=0; i<st.perCycle; i++){
      const nextPayload = {
        action:"next",
        sourceSheetId: st.sourceSheetId,
        sourceTab: st.sourceTab,
        destSheetId: st.destSheetId,
        geoSheetId: st.geoSheetId,
        cepTab: st.cepTab
      };

      const next = await fetch(st.api, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify(nextPayload)
      });

      const ndata = await safeJson(next);
      if(!ndata.ok) return ndata;
      if(!ndata.found) return {ok:true, msg: processed ? `Finalizado. Processados: ${processed} (${JSON.stringify(contagem)})` : "Nada pendente"};

      const rowIndex = ndata.rowIndex;
      const url = ndata.profile_url;
      const existing = ndata.rowData || {};

      const tabId = await openInactiveTab(url);
      const scrape = await sendMessageWhenReady(tabId, {type:"AUTO_SCRAPE"}, 30000);
      try{ await chrome.tabs.remove(tabId); }catch(_){}

      if(!scrape || !scrape.ok){
        const errMsg = (scrape && scrape.error) ? scrape.error : "Falha ao extrair";
        await updateRow(st, rowIndex, existing, null, errMsg);
        processed++;
        continue;
      }

      const upd = await updateRow(st, rowIndex, existing, scrape.data, null);
      if(upd && upd.acao && contagem.hasOwnProperty(upd.acao)) contagem[upd.acao]++;
      processed++;
    }

    return {ok:true, msg:`Finalizado. Processados: ${processed} (${JSON.stringify(contagem)})`};
  } catch(e){
    return {ok:false, error:String(e)};
  } finally {
    runningCycle = false;
  }
}

function openInactiveTab(url){
  return new Promise((resolve, reject) => {
    chrome.tabs.create({url, active:false}, (tab) => {
      const err = chrome.runtime.lastError;
      if(err) reject(err);
      else resolve(tab.id);
    });
  });
}

function sendMessageWhenReady(tabId, message, timeoutMs){
  return new Promise((resolve) => {
    const start = Date.now();
    const tick = async () => {
      if(Date.now()-start > timeoutMs){ resolve({ok:false, error:"Timeout carregando currículo"}); return; }
      try{
        const tab = await chrome.tabs.get(tabId);
        if(tab && tab.status === "complete"){
          chrome.tabs.sendMessage(tabId, message, (resp) => {
            const err = chrome.runtime.lastError;
            if(err) resolve({ok:false, error:"sendMessage: " + err.message});
            else resolve(resp);
          });
          return;
        }
      }catch(_){}
      setTimeout(tick, 350);
    };
    tick();
  });
}

async function updateRow(st, rowIndex, existing, data, errorMsg){
  const payload = {
    action:"update",
    sourceSheetId: st.sourceSheetId,
    sourceTab: st.sourceTab,
    destSheetId: st.destSheetId,
    geoSheetId: st.geoSheetId,
    cepTab: st.cepTab,
    login: st.operador,
    rowIndex,
    existing: existing || {},
    ok: !!data && !errorMsg,
    error: errorMsg || "",
    data: data || {}
  };
  const resp = await fetch(st.api, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload) });
  return await safeJson(resp);
}
