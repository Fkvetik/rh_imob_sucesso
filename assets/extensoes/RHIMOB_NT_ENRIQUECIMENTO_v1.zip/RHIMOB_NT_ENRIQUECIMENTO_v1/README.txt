RHIMOB_NT_ENRIQUECIMENTO v1.4.0

OBJETIVO
Extensão Chrome + WebApp Apps Script que coleta currículos da Catho SOZINHA
(via filtros de busca, sem depender de nenhuma planilha de origem/fila) e
alimenta a Novos Talentos (Supabase pufxvskozfdvfscqnays) direto — sem
duplicar quem já está na base.

TELA (só o essencial, nada técnico à vista)
1. Login/Senha (cadastrados no admin) — é a primeira tela do popup.
2. Depois de entrar: link do filtro de busca da Catho + nº de páginas +
   delay entre currículos (segundos) + intervalo pra rodar sozinho (min).
Nada de URL de script, ID de planilha ou aba de CEP aparece em lugar
nenhum do popup — tudo isso fica interno, dentro do config.js.

FLUXO
1) Você cola no popup um ou mais links de busca da Catho já filtrados
   (cargo, cidade etc. — o mesmo link que aparece na barra de endereço
   depois de aplicar os filtros no site da Catho) + quantas páginas varrer.
2) A extensão abre cada link, rola a página, coleta os links de currículo
   de todas as páginas configuradas (mesma técnica do Catho Coletor).
3) Abre cada currículo, revela telefone/e-mail, extrai dados pessoais,
   cargo, CEP, CV completo — com um delay configurável entre cada um
   (padrão 4s), pra não travar nem levar bloqueio da Catho.
4) O WebApp geocodifica (faixas de CEP embutidas) e checa o TELEFONE
   contra a Novos Talentos:
   - Não existe -> grava como NOVO talento no pool.
   - Existe, atualizado há menos de 2 anos -> não mexe, marca DADOS_COMPLETO.
   - Existe, com 2+ anos (ou sem data) -> ATUALIZA o MESMO registro com os
     dados novos (não cria duplicata, mesmo se o link do currículo mudou).
5) Toda linha processada também é espelhada na aba MAE, pra auditoria.
   Tudo fica só na planilha mãe — não existe planilha de origem.

LOGIN/SENHA (um por PC, cadastrado no admin)
Cada PC precisa de um login+senha cadastrado em admin-catho-coletor.html
(card dessa extensão) — sem isso o WebApp recusa qualquer gravação. O
popup confere o login direto com o WebApp (ação "login", não mexe em
planilha nenhuma) e, se as credenciais já estiverem salvas, entra sozinho
da próxima vez que abrir o popup — sem digitar de novo. Botão "Sair" apaga
as credenciais salvas nesse PC.

MULTI-PC (rodar em 3-4 computadores ao mesmo tempo)
Seguro por desenho: o WebApp usa um lock global (LockService) — cada
gravação processa uma de cada vez, então duas máquinas nunca colidem.
Cada PC pode ter seus próprios filtros de busca (ficam salvos localmente
no navegador, via chrome.storage.sync) — dá pra usar os 4 logins da Catho
em paralelo, cada um com um filtro/segmento diferente, ou todos com o mesmo.

PLANILHA MÃE (criada, vazia — as abas nascem sozinhas no primeiro envio)
https://docs.google.com/spreadsheets/d/1tdn1yZ1z3283381oi-sIp-U91xgfivT1xekYqnlOkxM/edit
Abas: NOVOS, ATUALIZADOS, DADOS_COMPLETO, MAE (espelho de tudo), ERROS_NT
(se a chamada pra Novos Talentos falhar, cai aqui pra reprocessar depois),
ERROS_EXTRACAO (currículo que a extensão não conseguiu abrir/extrair —
timeout, página bloqueada etc. — antes desaparecia sem deixar rastro).

PRÉ-REQUISITOS NO SUPABASE (rodar uma vez, projeto Novos Talentos)
- NT_SUPABASE_BUSCAR_POR_TELEFONE.sql — cria a função de consulta por
  telefone. Sem isso, todo currículo vira "erro" no roteamento.
- NT_SUPABASE_ENRIQUECIMENTO_LOGIN.sql — cria a tabela de login/senha e a
  função de autenticação. Sem isso, o WebApp recusa tudo.
Os dois estão em C:\Users\Fernando\Downloads\catho_coletor_v2\

COMO INSTALAR A EXTENSÃO (info técnica — não fica visível pra quem usa)
1. Abra chrome://extensions em cada um dos PCs.
2. Ative "Modo do desenvolvedor".
3. "Carregar sem compactação" -> selecione esta pasta
   (RHIMOB_NT_ENRIQUECIMENTO_v1).
4. No admin-catho-coletor.html, cadastre um login/senha pra essa máquina
   (card "Enriquecimento Novos Talentos").
5. A URL do WebApp e os IDs de planilha já vêm prontos dentro do
   config.js — só quem instala mexe nisso, se precisar trocar depois.
6. Abra o popup da extensão e faça login com o que foi cadastrado no
   passo 4. Adicione pelo menos um filtro de busca da Catho.

COMO PUBLICAR O WEBAPP (uma vez só — todos os PCs usam a mesma URL)
1. Abra script.google.com e crie um projeto novo (ou reaproveite o da
   RHIMOB_CATHO_SINC antiga, se preferir substituir).
2. Cole o conteúdo de GAS_WEBAPP_NT_ENRIQUECIMENTO_V1.gs.
3. Deploy -> New deployment -> Web app -> executar como você, acesso
   "Anyone".
4. Copie a URL /exec e cole em config.js (API_URL_DEFAULT), rezipe e
   redistribua — ou peça pra eu já atualizar aqui.

CAMPOS GRAVADOS (abas NOVOS / ATUALIZADOS / DADOS_COMPLETO / MAE)
Mesmos campos de sempre (dados pessoais, CEP/geo, CV completo) + novos:
Login (qual PC/operador coletou), AcaoRealizada (NOVO/ATUALIZADO/
DADOS_COMPLETO/ERRO_NT), TalentoKeyNT (chave na Novos Talentos),
DiasDesdeAtualizacaoNT, ErroNT.
