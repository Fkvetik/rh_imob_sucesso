const $ = (s) => document.querySelector(s);

const loginScreen = $("#loginScreen");
const appScreen = $("#appScreen");
const loginInput = $("#loginInput");
const senhaInput = $("#senhaInput");
const btnEntrar = $("#btnEntrar");
const loginMsg = $("#loginMsg");
const quemSouTexto = $("#quemSouTexto");
const btnSair = $("#btnSair");

const delayEl = $("#delaySegundos");
const intervalEl = $("#interval");
const novoLinkEl = $("#novoLink");
const novoPaginasEl = $("#novoPaginas");
const listaFiltrosEl = $("#listaFiltros");

const btnSave = $("#btnSave");
const btnRun = $("#btnRun");
const btnToggle = $("#btnToggle");
const btnAddFiltro = $("#btnAddFiltro");
const statusEl = $("#status");

let filtros = [];

function defaults(){
  return {
    operador: '',
    senha: '',
    delaySegundos: (typeof DEFAULT_DELAY_SEGUNDOS !== 'undefined' ? DEFAULT_DELAY_SEGUNDOS : 4),
    intervalMin: (typeof DEFAULT_INTERVAL_MIN !== 'undefined' ? DEFAULT_INTERVAL_MIN : 45),
    filtros: [],
    running: false
  };
}

function escHtml(s){
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ===== Login =====
async function tentarLogin(login, senha, silencioso){
  const api = (typeof API_URL_DEFAULT !== 'undefined' ? API_URL_DEFAULT : '');
  if(!api) return { ok:false, error:'Extensão sem configuração interna — fale com quem instalou.' };
  try{
    const resp = await fetch(api, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({ action:"login", login, senha })
    });
    const data = await resp.json().catch(() => ({}));
    return data;
  }catch(e){
    return { ok:false, error: silencioso ? '' : ('Falha de conexão: ' + e.message) };
  }
}

function mostrarApp(nome){
  loginScreen.classList.add('hide');
  appScreen.classList.remove('hide');
  quemSouTexto.textContent = '✅ ' + (nome || 'logado');
}

function mostrarLogin(msg, isErr){
  appScreen.classList.add('hide');
  loginScreen.classList.remove('hide');
  loginMsg.textContent = msg || '';
  loginMsg.className = 'small' + (isErr ? ' err' : '');
}

btnEntrar.addEventListener('click', async () => {
  const login = loginInput.value.trim();
  const senha = senhaInput.value.trim();
  if(!login || !senha){ loginMsg.textContent = '❌ Preencha login e senha'; loginMsg.className = 'small err'; return; }
  loginMsg.textContent = 'Entrando...'; loginMsg.className = 'small';
  const r = await tentarLogin(login, senha, false);
  if(r && r.ok){
    await chrome.storage.sync.set({ operador: login, senha });
    mostrarApp(r.nome);
    await loadAppState();
  }else{
    loginMsg.textContent = '❌ ' + (r?.error || 'Login ou senha incorretos');
    loginMsg.className = 'small err';
  }
});

btnSair.addEventListener('click', async () => {
  await chrome.storage.sync.set({ operador: '', senha: '' });
  senhaInput.value = '';
  mostrarLogin('Saiu. Entre de novo pra continuar.', false);
});

// ===== Filtros =====
function renderFiltros(){
  listaFiltrosEl.innerHTML = '';
  if(!filtros.length){
    listaFiltrosEl.innerHTML = '<div class="small">Nenhum filtro cadastrado ainda.</div>';
    return;
  }
  filtros.forEach((f, idx) => {
    const row = document.createElement('div');
    row.className = 'filtro' + (f.pausado ? ' pausado' : '');
    row.innerHTML = `
      <span class="link" title="${escHtml(f.link)}">${escHtml(f.link)}</span>
      <span class="paginas">${f.paginas || 2}p</span>
      <button class="mini secondary" data-act="pause" data-idx="${idx}">${f.pausado ? '▶' : '⏸'}</button>
      <button class="mini warn" data-act="del" data-idx="${idx}">✕</button>
    `;
    listaFiltrosEl.appendChild(row);
  });
  listaFiltrosEl.querySelectorAll('button[data-act]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = Number(btn.dataset.idx);
      if(btn.dataset.act === 'del') filtros.splice(idx, 1);
      if(btn.dataset.act === 'pause') filtros[idx].pausado = !filtros[idx].pausado;
      await chrome.storage.sync.set({ filtros });
      renderFiltros();
    });
  });
}

function tentarAdicionarFiltroPendente(){
  const link = novoLinkEl.value.trim();
  if(!link) return { ok:true };
  const paginas = Math.max(1, parseInt(novoPaginasEl.value || '2', 10));
  if(!/catho\.com\.br\/curriculos\/busca/i.test(link)){
    return { ok:false, error: 'O link em "Filtros de busca" não parece um link de busca da Catho — corrija ou apague antes de salvar.' };
  }
  filtros.push({ link, paginas, pausado:false });
  novoLinkEl.value = '';
  novoPaginasEl.value = '';
  return { ok:true, adicionou:true };
}

async function addFiltro(){
  const r = tentarAdicionarFiltroPendente();
  if(!r.ok){ statusEl.textContent = '❌ ' + r.error; statusEl.className = 'small err'; return; }
  if(!r.adicionou){ statusEl.textContent = '❌ Cole o link de busca da Catho primeiro'; statusEl.className = 'small err'; return; }
  await chrome.storage.sync.set({ filtros });
  renderFiltros();
  statusEl.textContent = '✅ Filtro adicionado.';
  statusEl.className = 'small ok';
}

// ===== App (pós-login) =====
async function loadAppState(){
  const st = await chrome.storage.sync.get(defaults());
  delayEl.value = String(st.delaySegundos || 4);
  intervalEl.value = String(st.intervalMin || 45);
  filtros = Array.isArray(st.filtros) ? st.filtros : [];
  renderFiltros();
  renderStatus(st);
}

function renderStatus(st){
  const nFiltros = filtros.filter(f => !f.pausado).length;
  if(st.running){
    btnToggle.textContent = "Parar automático";
    btnToggle.classList.remove("warn");
    btnToggle.classList.add("secondary");
    statusEl.textContent = `🟢 Rodando a cada ${st.intervalMin} min | ${nFiltros} filtro(s) ativo(s) | delay ${st.delaySegundos}s`;
    statusEl.className = "small ok";
  }else{
    btnToggle.textContent = "Iniciar automático";
    btnToggle.classList.remove("secondary");
    btnToggle.classList.add("warn");
    statusEl.textContent = `🔴 Parado | ${nFiltros} filtro(s) ativo(s) | delay ${st.delaySegundos}s`;
    statusEl.className = "small";
  }
}

async function save(){
  const pendente = tentarAdicionarFiltroPendente();
  if(!pendente.ok){
    statusEl.textContent = '❌ ' + pendente.error;
    statusEl.className = 'small err';
    return;
  }
  if(pendente.adicionou) renderFiltros();

  const delaySegundos = Math.max(1, parseInt(delayEl.value || '4', 10));
  const intervalMin = Math.max(5, parseInt(intervalEl.value || '45', 10));

  await chrome.storage.sync.set({ delaySegundos, intervalMin, filtros });

  const st = await chrome.storage.sync.get(Object.assign(defaults(), {running:false, delaySegundos, intervalMin, filtros}));
  const msgFiltro = pendente.adicionou ? ' (filtro pendente também foi adicionado)' : '';
  statusEl.textContent = "✅ Salvo." + msgFiltro;
  statusEl.className = "small ok";
  renderStatus(st);
}

async function runOnce(){
  await save();
  statusEl.textContent = "Executando... (pode levar alguns minutos, varre todas as páginas dos filtros ativos)";
  statusEl.className = "small";
  const res = await chrome.runtime.sendMessage({ type: "RUN_ONCE" });
  if(res?.ok){
    statusEl.textContent = "✅ " + (res.msg || "Ciclo finalizado");
    statusEl.className = "small ok";
  }else{
    statusEl.textContent = "❌ " + (res?.error || "Falha");
    statusEl.className = "small err";
  }
}

async function toggle(){
  const st = await chrome.storage.sync.get({running:false});
  if(st.running){
    const res = await chrome.runtime.sendMessage({ type: "STOP" });
    if(res?.ok){
      await chrome.storage.sync.set({running:false});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao parar");
      statusEl.className = "small err";
    }
  }else{
    if(!filtros.filter(f => !f.pausado).length){
      statusEl.textContent = "❌ Adicione pelo menos um filtro de busca ativo antes de iniciar";
      statusEl.className = "small err";
      return;
    }
    await save();
    const res = await chrome.runtime.sendMessage({ type: "START" });
    if(res?.ok){
      await chrome.storage.sync.set({running:true});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao iniciar");
      statusEl.className = "small err";
    }
  }
}

btnSave.addEventListener("click", save);
btnRun.addEventListener("click", runOnce);
btnToggle.addEventListener("click", toggle);
btnAddFiltro.addEventListener("click", addFiltro);

document.addEventListener("DOMContentLoaded", async () => {
  const st = await chrome.storage.sync.get(defaults());
  if(st.operador && st.senha){
    // já tem credenciais salvas — confere rápido com o WebApp antes de
    // mostrar a tela cheia (evita digitar de novo toda vez que abre o popup).
    loginMsg.textContent = 'Entrando...';
    const r = await tentarLogin(st.operador, st.senha, true);
    if(r && r.ok){
      mostrarApp(r.nome);
      await loadAppState();
      return;
    }
  }
  loginInput.value = st.operador || '';
  mostrarLogin('', false);
});
