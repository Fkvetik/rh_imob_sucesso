const $ = (s) => document.querySelector(s);

const operadorEl = $("#operador");
const apiEl = $("#api");
const destSheetEl = $("#destSheetId");
const geoSheetEl = $("#geoSheetId");
const cepTabEl = $("#cepTab");
const intervalEl = $("#interval");
const novoLinkEl = $("#novoLink");
const novoPaginasEl = $("#novoPaginas");
const listaFiltrosEl = $("#listaFiltros");

const btnSave = $("#btnSave");
const btnRun = $("#btnRun");
const btnToggle = $("#btnToggle");
const btnAddFiltro = $("#btnAddFiltro");
const statusEl = $("#status");

let filtros = [];

function defaults(){
  return {
    operador: (typeof DEFAULT_OPERADOR !== 'undefined' ? DEFAULT_OPERADOR : ''),
    api: (typeof API_URL_DEFAULT !== 'undefined' ? API_URL_DEFAULT : ''),
    destSheetId: (typeof DEFAULT_DEST_SHEET_ID !== 'undefined' ? DEFAULT_DEST_SHEET_ID : ''),
    geoSheetId: (typeof DEFAULT_GEO_SHEET_ID !== 'undefined' ? DEFAULT_GEO_SHEET_ID : ''),
    cepTab: (typeof DEFAULT_CEP_TAB !== 'undefined' ? DEFAULT_CEP_TAB : 'cep'),
    intervalMin: (typeof DEFAULT_INTERVAL_MIN !== 'undefined' ? DEFAULT_INTERVAL_MIN : 45),
    filtros: [],
    running: false
  };
}

function renderFiltros(){
  listaFiltrosEl.innerHTML = '';
  if(!filtros.length){
    listaFiltrosEl.innerHTML = '<div class="small">Nenhum filtro cadastrado ainda.</div>';
    return;
  }
  filtros.forEach((f, idx) => {
    const row = document.createElement('div');
    row.className = 'filtro' + (f.pausado ? ' pausado' : '');
    row.innerHTML = `
      <span class="link" title="${escHtml(f.link)}">${escHtml(f.link)}</span>
      <span class="paginas">${f.paginas || 2}p</span>
      <button class="mini secondary" data-act="pause" data-idx="${idx}">${f.pausado ? '▶' : '⏸'}</button>
      <button class="mini warn" data-act="del" data-idx="${idx}">✕</button>
    `;
    listaFiltrosEl.appendChild(row);
  });
  listaFiltrosEl.querySelectorAll('button[data-act]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = Number(btn.dataset.idx);
      if(btn.dataset.act === 'del') filtros.splice(idx, 1);
      if(btn.dataset.act === 'pause') filtros[idx].pausado = !filtros[idx].pausado;
      await chrome.storage.sync.set({ filtros });
      renderFiltros();
    });
  });
}

function escHtml(s){
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Devolve {ok, error} — usada tanto pelo botão "+ Add" quanto pelo "Salvar
// configuração", pra quem digitou o link e clicou direto em Salvar (sem
// clicar em "+ Add" antes) não perder o que preencheu.
function tentarAdicionarFiltroPendente(){
  const link = novoLinkEl.value.trim();
  if(!link) return { ok:true }; // campo vazio, nada a adicionar
  const paginas = Math.max(1, parseInt(novoPaginasEl.value || '2', 10));
  if(!/catho\.com\.br\/curriculos\/busca/i.test(link)){
    return { ok:false, error: 'O link em "Filtros de busca" não parece um link de busca da Catho — corrija ou apague antes de salvar.' };
  }
  filtros.push({ link, paginas, pausado:false });
  novoLinkEl.value = '';
  novoPaginasEl.value = '';
  return { ok:true, adicionou:true };
}

async function addFiltro(){
  const r = tentarAdicionarFiltroPendente();
  if(!r.ok){ statusEl.textContent = '❌ ' + r.error; statusEl.className = 'small err'; return; }
  if(!r.adicionou){ statusEl.textContent = '❌ Cole o link de busca da Catho primeiro'; statusEl.className = 'small err'; return; }
  await chrome.storage.sync.set({ filtros });
  renderFiltros();
  statusEl.textContent = '✅ Filtro adicionado.';
  statusEl.className = 'small ok';
}

async function loadState(){
  const st = await chrome.storage.sync.get(defaults());

  operadorEl.value = st.operador || '';
  apiEl.value = st.api || '';
  destSheetEl.value = st.destSheetId || '';
  geoSheetEl.value = st.geoSheetId || '';
  cepTabEl.value = st.cepTab || 'cep';
  intervalEl.value = String(st.intervalMin || 45);
  filtros = Array.isArray(st.filtros) ? st.filtros : [];
  renderFiltros();
  renderStatus(st);
}

function renderStatus(st){
  const dest = st.destSheetId || '(base não definida)';
  const geo = st.geoSheetId ? ' | GEO ativo' : ' | GEO sem base auxiliar';
  const op = st.operador ? `Operador: ${st.operador}` : '⚠️ Operador não definido';
  const nFiltros = filtros.filter(f => !f.pausado).length;

  if(st.running){
    btnToggle.textContent = "Parar automático";
    btnToggle.classList.remove("warn");
    btnToggle.classList.add("secondary");
    statusEl.textContent = `🟢 Rodando a cada ${st.intervalMin} min | ${op} | ${nFiltros} filtro(s) ativo(s) | Destino: ${dest}${geo}`;
    statusEl.className = "small ok";
  }else{
    btnToggle.textContent = "Iniciar automático";
    btnToggle.classList.remove("secondary");
    btnToggle.classList.add("warn");
    statusEl.textContent = `🔴 Parado | ${op} | ${nFiltros} filtro(s) ativo(s) | Destino: ${dest}${geo}`;
    statusEl.className = "small";
  }
}

async function save(){
  const pendente = tentarAdicionarFiltroPendente();
  if(!pendente.ok){
    statusEl.textContent = '❌ ' + pendente.error;
    statusEl.className = 'small err';
    return;
  }
  if(pendente.adicionou) renderFiltros();

  const operador = operadorEl.value.trim();
  const api = apiEl.value.trim();
  const destSheetId = destSheetEl.value.trim();
  const geoSheetId = geoSheetEl.value.trim();
  const cepTab = cepTabEl.value.trim() || 'cep';
  const intervalMin = Math.max(5, parseInt(intervalEl.value || '45', 10));

  await chrome.storage.sync.set({
    operador, api, destSheetId, geoSheetId, cepTab, intervalMin, filtros
  });

  const st = await chrome.storage.sync.get(Object.assign(defaults(), {running:false, operador, api, destSheetId, geoSheetId, cepTab, intervalMin, filtros}));
  const msgFiltro = pendente.adicionou ? ' (filtro pendente também foi adicionado)' : '';
  statusEl.textContent = operador ? ("✅ Configuração salva." + msgFiltro) : "⚠️ Salvo, mas falta preencher o Operador/Login.";
  statusEl.className = operador ? "small ok" : "small err";
  renderStatus(st);
}

async function runOnce(){
  await save();
  statusEl.textContent = "Executando... (pode levar alguns minutos, varre todas as páginas dos filtros ativos)";
  statusEl.className = "small";
  const res = await chrome.runtime.sendMessage({ type: "RUN_ONCE" });
  if(res?.ok){
    statusEl.textContent = "✅ " + (res.msg || "Ciclo finalizado");
    statusEl.className = "small ok";
  }else{
    statusEl.textContent = "❌ " + (res?.error || "Falha");
    statusEl.className = "small err";
  }
}

async function toggle(){
  const st = await chrome.storage.sync.get({running:false});
  if(st.running){
    const res = await chrome.runtime.sendMessage({ type: "STOP" });
    if(res?.ok){
      await chrome.storage.sync.set({running:false});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao parar");
      statusEl.className = "small err";
    }
  }else{
    if(!operadorEl.value.trim()){
      statusEl.textContent = "❌ Preencha o Operador/Login antes de iniciar";
      statusEl.className = "small err";
      return;
    }
    if(!filtros.filter(f => !f.pausado).length){
      statusEl.textContent = "❌ Adicione pelo menos um filtro de busca ativo antes de iniciar";
      statusEl.className = "small err";
      return;
    }
    await save();
    const res = await chrome.runtime.sendMessage({ type: "START" });
    if(res?.ok){
      await chrome.storage.sync.set({running:true});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao iniciar");
      statusEl.className = "small err";
    }
  }
}

btnSave.addEventListener("click", save);
btnRun.addEventListener("click", runOnce);
btnToggle.addEventListener("click", toggle);
btnAddFiltro.addEventListener("click", addFiltro);
document.addEventListener("DOMContentLoaded", loadState);
