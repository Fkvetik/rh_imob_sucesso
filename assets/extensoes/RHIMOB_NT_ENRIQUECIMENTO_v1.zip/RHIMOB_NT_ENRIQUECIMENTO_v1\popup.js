const $ = (s) => document.querySelector(s);

const operadorEl = $("#operador");
const apiEl = $("#api");
const sourceSheetEl = $("#sourceSheetId");
const sourceTabEl = $("#sourceTab");
const destSheetEl = $("#destSheetId");
const geoSheetEl = $("#geoSheetId");
const cepTabEl = $("#cepTab");
const intervalEl = $("#interval");
const perCycleEl = $("#perCycle");

const btnSave = $("#btnSave");
const btnRun = $("#btnRun");
const btnToggle = $("#btnToggle");
const statusEl = $("#status");

function defaults(){
  return {
    operador: (typeof DEFAULT_OPERADOR !== 'undefined' ? DEFAULT_OPERADOR : ''),
    api: (typeof API_URL_DEFAULT !== 'undefined' ? API_URL_DEFAULT : ''),
    sourceSheetId: (typeof DEFAULT_SOURCE_SHEET_ID !== 'undefined' ? DEFAULT_SOURCE_SHEET_ID : ''),
    sourceTab: (typeof DEFAULT_SOURCE_TAB !== 'undefined' ? DEFAULT_SOURCE_TAB : 'Sinc'),
    destSheetId: (typeof DEFAULT_DEST_SHEET_ID !== 'undefined' ? DEFAULT_DEST_SHEET_ID : ''),
    geoSheetId: (typeof DEFAULT_GEO_SHEET_ID !== 'undefined' ? DEFAULT_GEO_SHEET_ID : ''),
    cepTab: (typeof DEFAULT_CEP_TAB !== 'undefined' ? DEFAULT_CEP_TAB : 'cep'),
    intervalMin: (typeof DEFAULT_INTERVAL_MIN !== 'undefined' ? DEFAULT_INTERVAL_MIN : 17),
    perCycle: (typeof DEFAULT_PER_CYCLE !== 'undefined' ? DEFAULT_PER_CYCLE : 1),
    running: false
  };
}

async function loadState(){
  const st = await chrome.storage.sync.get(defaults());

  operadorEl.value = st.operador || '';
  apiEl.value = st.api || '';
  sourceSheetEl.value = st.sourceSheetId || '';
  sourceTabEl.value = st.sourceTab || 'Sinc';
  destSheetEl.value = st.destSheetId || '';
  geoSheetEl.value = st.geoSheetId || '';
  cepTabEl.value = st.cepTab || 'cep';
  intervalEl.value = String(st.intervalMin || 17);
  perCycleEl.value = String(st.perCycle || 1);
  renderStatus(st);
}

function renderStatus(st){
  const dest = st.destSheetId || '(base não definida)';
  const geo = st.geoSheetId ? ' | GEO ativo' : ' | GEO sem base auxiliar';
  const op = st.operador ? `Operador: ${st.operador}` : '⚠️ Operador não definido';

  if(st.running){
    btnToggle.textContent = "Parar automático";
    btnToggle.classList.remove("warn");
    btnToggle.classList.add("secondary");
    statusEl.textContent = `🟢 Rodando a cada ${st.intervalMin} min | ${op} | Destino: ${dest}${geo}`;
    statusEl.className = "small ok";
  }else{
    btnToggle.textContent = "Iniciar automático";
    btnToggle.classList.remove("secondary");
    btnToggle.classList.add("warn");
    statusEl.textContent = `🔴 Parado | ${op} | Destino: ${dest}${geo}`;
    statusEl.className = "small";
  }
}

async function save(){
  const operador = operadorEl.value.trim();
  const api = apiEl.value.trim();
  const sourceSheetId = sourceSheetEl.value.trim();
  const sourceTab = sourceTabEl.value.trim() || 'Sinc';
  const destSheetId = destSheetEl.value.trim();
  const geoSheetId = geoSheetEl.value.trim();
  const cepTab = cepTabEl.value.trim() || 'cep';
  const intervalMin = Math.max(1, parseInt(intervalEl.value || '17', 10));
  const perCycle = Math.max(1, parseInt(perCycleEl.value || '1', 10));

  await chrome.storage.sync.set({
    operador, api, sourceSheetId, sourceTab, destSheetId, geoSheetId, cepTab, intervalMin, perCycle
  });

  const st = await chrome.storage.sync.get(Object.assign(defaults(), {running:false, operador, api, sourceSheetId, sourceTab, destSheetId, geoSheetId, cepTab, intervalMin, perCycle}));
  statusEl.textContent = operador ? "✅ Configuração salva." : "⚠️ Salvo, mas falta preencher o Operador/Login.";
  statusEl.className = operador ? "small ok" : "small err";
  renderStatus(st);
}

async function runOnce(){
  await save();
  statusEl.textContent = "Executando 1 ciclo...";
  statusEl.className = "small";
  const res = await chrome.runtime.sendMessage({ type: "RUN_ONCE" });
  if(res?.ok){
    statusEl.textContent = "✅ " + (res.msg || "Ciclo finalizado");
    statusEl.className = "small ok";
  }else{
    statusEl.textContent = "❌ " + (res?.error || "Falha");
    statusEl.className = "small err";
  }
}

async function toggle(){
  const st = await chrome.storage.sync.get({running:false});
  if(st.running){
    const res = await chrome.runtime.sendMessage({ type: "STOP" });
    if(res?.ok){
      await chrome.storage.sync.set({running:false});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao parar");
      statusEl.className = "small err";
    }
  }else{
    if(!operadorEl.value.trim()){
      statusEl.textContent = "❌ Preencha o Operador/Login antes de iniciar";
      statusEl.className = "small err";
      return;
    }
    await save();
    const res = await chrome.runtime.sendMessage({ type: "START" });
    if(res?.ok){
      await chrome.storage.sync.set({running:true});
      renderStatus(await chrome.storage.sync.get(defaults()));
    }else{
      statusEl.textContent = "❌ " + (res?.error || "Falha ao iniciar");
      statusEl.className = "small err";
    }
  }
}

btnSave.addEventListener("click", save);
btnRun.addEventListener("click", runOnce);
btnToggle.addEventListener("click", toggle);
document.addEventListener("DOMContentLoaded", loadState);
