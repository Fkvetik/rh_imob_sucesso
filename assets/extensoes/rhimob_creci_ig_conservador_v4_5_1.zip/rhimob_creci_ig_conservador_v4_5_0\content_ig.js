const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const BASE_GOOGLE = "https://www.google.com/search?hl=pt-BR&q=CRECI";

function overlay(msg) {
  let el = document.getElementById("__creci_ig_overlay");
  if (!el) {
    el = document.createElement("div");
    el.id = "__creci_ig_overlay";
    Object.assign(el.style, {
      position: "fixed",
      bottom: "10px",
      right: "10px",
      zIndex: 999999,
      background: "rgba(15,23,42,.92)",
      color: "#eaf0ff",
      padding: "10px 12px",
      borderRadius: "10px",
      font: "12px/1.45 system-ui,Segoe UI,Roboto,Arial",
      maxWidth: "560px",
      whiteSpace: "pre-wrap"
    });
    document.body.appendChild(el);
  }
  el.textContent = msg;
}

async function getState() {
  return await chrome.storage.local.get({ running:false, endpoint:"", spreadsheetId:"", tab:"", rowStart:2, rowEnd:0, creciColumn:"", delaySearchMs:1500, delayOpenProfileMs:1500, delayNextRowMs:2000, pending:null, debug:false, pauseUntil:0 });
}
async function setState(patch) { await chrome.storage.local.set(patch); }

function clampDelay(v, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(60000, Math.round(n)));
}
function getDelaySettings(st) {
  return {
    delaySearchMs: clampDelay(st?.delaySearchMs, 1500),
    delayOpenProfileMs: clampDelay(st?.delayOpenProfileMs, 1500),
    delayNextRowMs: clampDelay(st?.delayNextRowMs, 2000)
  };
}

async function debugLog(event, detail="", extra={}) {
  try {
    const st = await chrome.storage.local.get({ debug:false, pending:null });
    if (!st.debug && !extra.force) return;
    chrome.runtime.sendMessage({
      type: "DEBUG_LOG",
      source: extra.source || "instagram",
      event,
      detail: typeof detail === "string" ? detail : JSON.stringify(detail),
      row: extra.row ?? st.pending?.row ?? null,
      creci: extra.creci || st.pending?.creciRaw || "",
      pending: st.pending || null,
      url: location.href,
      level: extra.level || "info"
    }, ()=>void chrome.runtime.lastError);
  } catch {}
}
function shortDbg(v, n=240) {
  const s = String(v ?? "");
  return s.length > n ? s.slice(0, n) + "…" : s;
}


async function workerCall(type, extra={}) {
  return await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...extra }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) return resolve({ ok:false, error: err.message || String(err) });
      resolve(resp || { ok:false, error:"no_response" });
    });
  });
}
async function claimWorker(role="instagram") { return await workerCall("WORKER_CLAIM", { role }); }
async function touchWorker(role="instagram") { return await workerCall("WORKER_TOUCH", { role }); }
async function gasPost(endpoint, body) {
  await debugLog("gas_post_call", `${body?.action||"payload"} | ${shortDbg(JSON.stringify(body||{}))}`, { source:"instagram" });
  return await new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "GAS_POST", endpoint, body, source:"instagram" }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) return reject(new Error("runtime_lastError: " + err.message));
      if (!resp) return reject(new Error("no_response"));
      if (resp.ok === false) return reject(new Error(resp.error || "gas_post_failed"));
      if (!resp.http_ok) return reject(new Error(`GAS_HTTP_${resp.status}: ${(resp.text||"").slice(0,220)}`));
      if (resp.json) {
        debugLog("gas_post_ok", `HTTP ${resp.status} em ${resp.elapsedMs||0}ms`, { source:"instagram" }).catch(()=>{});
        return resolve(resp.json);
      }
      return reject(new Error("GAS_INVALID_JSON: " + (resp.text||"").slice(0,220)));
    });
  });
}

async function gasCallRetry(fn, tries=8) {
  let lastErr = null;
  for (let i=0;i<tries;i++){
    try { return await fn(); }
    catch (e) {
      lastErr = e;
      const msg = String(e && e.message ? e.message : e);
      const transient = /GAS_INVALID_JSON|GAS_HTTP_5|GAS_HTTP_429|Failed to fetch|network|timeout|temporar|runtime_lastError|message channel closed|no_response/i.test(msg);
      if (!transient || i === tries-1) break;

      const delay = Math.min(60000, (1500 * Math.pow(2,i)) + Math.floor(Math.random()*400));
      overlay(`GAS instável, retry ${i+1}/${tries} em ${Math.ceil(delay/1000)}s…\n${msg.slice(0,160)}`);
      await debugLog("gas_retry", `${i+1}/${tries} em ${delay}ms | ${shortDbg(msg)}`, { source:"instagram", level:"warn" });
      await sleep(delay);
    }
  }
  throw lastErr;
}

function normalizeCreci6(creciRaw) {
  const m = String(creciRaw || "").match(/\d+/g);
  const s = m ? m.join("") : "";
  return s.slice(0, 6);
}

function instagramProfileUrlFromCurrent() {
  try {
    const u = new URL(location.href);
    const parts = u.pathname.split("/").filter(Boolean);
    if (!parts.length) return "";
    const first = parts[0].toLowerCase();
    const excluded = new Set(["p","reel","reels","tv","explore","accounts","about","stories","direct","s"]);
    if (excluded.has(first)) return "";
    return `https://www.instagram.com/${parts[0]}/`;
  } catch { return ""; }
}

function getMeta(nameOrProp) {
  const m = document.querySelector(`meta[property="${nameOrProp}"], meta[name="${nameOrProp}"]`);
  return (m?.getAttribute("content") || "").trim();
}

function htmlSource() {
  return document.documentElement?.innerHTML || "";
}

function decodeJsonEscapedString(s) {
  let out = String(s || "");
  if (!out) return "";
  out = out.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => {
    try { return String.fromCharCode(parseInt(hex, 16)); } catch { return _; }
  });
  out = out.replace(/\\n/g, "\n");
  out = out.replace(/\\r/g, "\r");
  out = out.replace(/\\t/g, "\t");
  out = out.replace(/\\\//g, "/");
  out = out.replace(/\\"/g, '"');
  out = out.replace(/\\\\/g, "\\");
  return out.trim();
}

function escapeRegExp(s) {
  return String(s || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function currentProfileUsername() {
  try {
    const prof = instagramProfileUrlFromCurrent();
    if (prof) {
      const u = new URL(prof);
      const user = u.pathname.split("/").filter(Boolean)[0] || "";
      if (user) return user;
    }
  } catch {}

  const ogTitle = getMeta("og:title");
  const m = ogTitle.match(/\(@([A-Za-z0-9_.]+)\)/);
  if (m) return m[1].trim();

  const t = (document.title || "").trim();
  const m2 = t.match(/\(@([A-Za-z0-9_.]+)\)/);
  if (m2) return m2[1].trim();
  return "";
}

function scopedRawSources() {
  const out = [];
  for (const s of Array.from(document.querySelectorAll('script')).map(el => el.textContent || '')) {
    if (s) out.push(s);
  }
  out.push(htmlSource());
  return out;
}

function sourceMatchesUsername(src, scopeHint='') {
  const hint = String(scopeHint || currentProfileUsername() || '').replace(/^@+/, '').trim();
  if (!hint) return false;
  const esc = escapeRegExp(hint);
  return [
    new RegExp(`"username"\\s*:\\s*"${esc}"`, 'i'),
    new RegExp(`"alternateName"\\s*:\\s*"@${esc}"`, 'i'),
    new RegExp(`instagram\\.com(?:\\/|\\\\/)${esc}(?:\\/|\\\\/)`, 'i'),
    new RegExp(`/${esc}(?:/|\\\\/)`, 'i')
  ].some(rx => rx.test(String(src || '')));
}

function captureJsonStringNearHint(key, scopeHint='', radius=2600) {
  const hint = String(scopeHint || currentProfileUsername() || '').replace(/^@+/, '').trim();
  if (!hint) return '';
  const esc = escapeRegExp(hint);
  const markers = [
    new RegExp(`"username"\\s*:\\s*"${esc}"`, 'ig'),
    new RegExp(`"alternateName"\\s*:\\s*"@${esc}"`, 'ig'),
    new RegExp(`instagram\\.com(?:\\/|\\\\/)${esc}(?:\\/|\\\\/)`, 'ig')
  ];
  const field = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, 'i');
  for (const src of scopedRawSources()) {
    for (const marker of markers) {
      marker.lastIndex = 0;
      let mm;
      while ((mm = marker.exec(src)) !== null) {
        const start = Math.max(0, mm.index - 600);
        const end = Math.min(src.length, mm.index + radius);
        const chunk = src.slice(start, end);
        const m = chunk.match(field);
        if (m) return decodeJsonEscapedString(m[1]);
      }
    }
  }
  return '';
}

function captureJsonNumberNearHint(key, scopeHint='', radius=2600) {
  const hint = String(scopeHint || currentProfileUsername() || '').replace(/^@+/, '').trim();
  if (!hint) return '';
  const esc = escapeRegExp(hint);
  const markers = [
    new RegExp(`"username"\\s*:\\s*"${esc}"`, 'ig'),
    new RegExp(`"alternateName"\\s*:\\s*"@${esc}"`, 'ig'),
    new RegExp(`instagram\\.com(?:\\/|\\\\/)${esc}(?:\\/|\\\\/)`, 'ig')
  ];
  const field = new RegExp(`"${key}"\\s*:\\s*(\\d+)`, 'i');
  for (const src of scopedRawSources()) {
    for (const marker of markers) {
      marker.lastIndex = 0;
      let mm;
      while ((mm = marker.exec(src)) !== null) {
        const start = Math.max(0, mm.index - 600);
        const end = Math.min(src.length, mm.index + radius);
        const chunk = src.slice(start, end);
        const m = chunk.match(field);
        if (m) return String(m[1]);
      }
    }
  }
  return '';
}

function scopedSources(scopeHint="") {
  const html = htmlSource();
  const hint = String(scopeHint || currentProfileUsername() || "").replace(/^@+/, "").trim();
  if (!hint) return [html];

  const esc = escapeRegExp(hint);
  const patterns = [
    new RegExp(`"username"\\s*:\\s*"${esc}"`, "i"),
    new RegExp(`"alternateName"\\s*:\\s*"@${esc}"`, "i"),
    new RegExp(`instagram\\.com(?:\\\\/|/)${esc}(?:\\\\/|/)`, "i"),
    new RegExp(`/${esc}(?:/|\\\\/)`, "i")
  ];

  const rawSources = [];
  for (const s of Array.from(document.querySelectorAll('script')).map(el => el.textContent || "")) {
    if (s) rawSources.push(s);
  }
  rawSources.push(html);

  const out = [];
  const seen = new Set();
  for (const src of rawSources) {
    let idx = -1;
    for (const rx of patterns) {
      const mm = rx.exec(src);
      if (mm) {
        idx = mm.index;
        break;
      }
    }
    if (idx < 0) continue;
    const chunk = src.length > 28000 ? src.slice(Math.max(0, idx - 14000), Math.min(src.length, idx + 14000)) : src;
    if (!seen.has(chunk)) {
      seen.add(chunk);
      out.push(chunk);
    }
  }

  return out.length ? out : [html];
}


function extractBalancedObject(src, anchorIndex, maxRadius=24000) {
  const s = String(src || "");
  const startMin = Math.max(0, anchorIndex - maxRadius);
  const endMax = Math.min(s.length, anchorIndex + maxRadius);

  let start = -1;
  let inStr = false;
  let esc = false;
  for (let i = anchorIndex; i >= startMin; i--) {
    const ch = s[i];
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (ch === '\\') { esc = true; continue; }
      if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') { inStr = true; continue; }
    if (ch === '{') { start = i; break; }
  }
  if (start < 0) return "";

  let depth = 0;
  inStr = false;
  esc = false;
  for (let i = start; i < endMax; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (ch === '\\') { esc = true; continue; }
      if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') { inStr = true; continue; }
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) return s.slice(start, i + 1);
    }
  }
  return "";
}

function scopedObjectSources(scopeHint="") {
  const hint = String(scopeHint || currentProfileUsername() || "").replace(/^@+/, "").trim();
  if (!hint) return [];

  const esc = escapeRegExp(hint);
  const patterns = [
    new RegExp(`"username"\\s*:\\s*"${esc}"`, "i"),
    new RegExp(`"alternateName"\\s*:\\s*"@${esc}"`, "i"),
    new RegExp(`instagram\\.com(?:\\/|\\\\/)${esc}(?:\\/|\\\\/)`, "i"),
    new RegExp(`/${esc}(?:/|\\\\/)`, "i")
  ];

  const out = [];
  const seen = new Set();
  for (const src of scopedRawSources()) {
    for (const rx of patterns) {
      const mm = rx.exec(src);
      if (!mm) continue;
      const obj = extractBalancedObject(src, mm.index);
      if (!obj || !sourceMatchesUsername(obj, hint)) continue;
      if (!seen.has(obj)) {
        seen.add(obj);
        out.push(obj);
      }
    }
  }
  return out;
}

function captureJsonStringStrict(key, scopeHint="") {
  const near = captureJsonStringNearHint(key, scopeHint);
  if (near) return near;
  const rx = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, "i");
  for (const src of scopedObjectSources(scopeHint)) {
    const mm = src.match(rx);
    if (mm) return decodeJsonEscapedString(mm[1]);
  }
  return "";
}

function captureJsonNumberStrict(key, scopeHint="") {
  const near = captureJsonNumberNearHint(key, scopeHint);
  if (near) return near;
  const rx = new RegExp(`"${key}"\\s*:\\s*(\\d+)`, "i");
  for (const src of scopedObjectSources(scopeHint)) {
    const mm = src.match(rx);
    if (mm) return String(mm[1]);
  }
  return "";
}

function extractBioFromHeaderDetailed() {
  const targetUser = currentProfileUsername();
  const { displayName, username } = parseNameAndUser();
  const banned = uniqueNonEmpty([targetUser, username, displayName])
    .map(s => String(s || "").trim().toLowerCase())
    .filter(Boolean);

  const header = document.querySelector("header");
  if (!header) return { text:"", source:"header_none" };

  const junkLine = (line) => {
    const t = String(line || '').trim().toLowerCase();
    if (!t) return true;
    if (banned.includes(t)) return true;
    if (/^(opções|options|seguir|seguindo|follow|following|message|mensagem|enviar mensagem|editar perfil|edit profile|highlights?|mais|more|ver mais|see more)$/i.test(t)) return true;
    if (/^(publicações|posts?|seguidores?|followers?|seguindo|following)$/i.test(t)) return true;
    if (/^@[a-z0-9._]{3,30}$/i.test(t)) return true;
    return false;
  };

  const candidates = [];
  for (const el of Array.from(header.querySelectorAll("h1, section span[dir='auto'], section div[dir='auto'], section span, section div"))) {
    const raw = (el.innerText || el.textContent || '').trim();
    if (!raw) continue;
    const rows = raw.split(/\n+/).map(s => s.replace(/\u00A0/g, ' ').replace(/\s{2,}/g, ' ').trim()).filter(Boolean);
    const cleaned = rows.filter(line => !junkLine(line)).join("\n").trim();
    if (!cleaned) continue;
    if (cleaned.length < 3 || cleaned.length > 900) continue;
    if (!/[a-zà-ÿ0-9]/i.test(cleaned)) continue;
    candidates.push(cleaned);
  }

  const uniq = uniqueNonEmpty(candidates).filter(t => !/^@?[A-Za-z0-9._]{3,30}$/.test(t));
  if (!uniq.length) return { text:"", source:"header_empty" };

  const best = uniq.sort((a, b) => scoreBioText(b) - scoreBioText(a))[0];
  return { text: best || "", source: "header" };
}

function isProbablyTruncatedBio(text) {
  const s = String(text || '').trim();
  if (!s) return false;
  return /(?:\.\.\.|…)(?:\s*(?:mais|more|ver mais|see more))?$/i.test(s) || /(?:\.\.\.|…)/.test(s);
}

function scoreBioText(text) {
  const x = String(text || '').trim();
  if (!x) return -999;
  let s = 0;
  if (/\n/.test(x)) s += 4;
  if (/[•|]/.test(x)) s += 2;
  if (/creci|im[oó]veis|corret|consult|broker|realtor|venda|loca[cç][aã]o|whats|whatsapp/i.test(x)) s += 6;
  if (/\b\d{5,7}\b/.test(x)) s += 3;
  s += Math.min(10, Math.floor(x.length / 30));
  if (isProbablyTruncatedBio(x)) s -= 6;
  return s;
}

function mergeBioTexts(list) {
  const chunks = [];
  const seen = new Set();
  for (const item of list || []) {
    const txt = String(item || '').trim();
    if (!txt) continue;
    for (const line of txt.split(/\n+/).map(s => s.trim()).filter(Boolean)) {
      const key = line.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      chunks.push(line);
    }
  }
  return chunks.join("\n").trim();
}

async function expandProfileBioIfNeeded() {
  const header = document.querySelector('header');
  if (!header) return false;
  const clickable = Array.from(header.querySelectorAll('button, span, div'));
  for (const el of clickable) {
    const txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!/^(mais|more|ver mais|see more)$/i.test(txt)) continue;
    try {
      el.click();
      await sleep(350);
      return true;
    } catch {}
  }
  return false;
}

function captureJsonString(key, scopeHint="") {
  const rx = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, "i");
  for (const src of scopedSources(scopeHint)) {
    const m = src.match(rx);
    if (m) return decodeJsonEscapedString(m[1]);
  }
  return "";
}

function captureJsonNumber(key, scopeHint="") {
  const rx = new RegExp(`"${key}"\\s*:\\s*(\\d+)`, "i");
  for (const src of scopedSources(scopeHint)) {
    const m = src.match(rx);
    if (m) return String(m[1]);
  }
  return "";
}

function uniqueNonEmpty(list) {
  const out = [];
  const seen = new Set();
  for (const v of list || []) {
    const s = String(v || "").trim();
    if (!s || seen.has(s)) continue;
    seen.add(s);
    out.push(s);
  }
  return out;
}

function parseNumberLike(x) {
  if (!x) return "";
  let t = String(x).trim();
  t = t.replace(/\s|\u00A0/g, "");
  const km = t.match(/^(\d+(?:[.,]\d+)?)([km])$/i);
  if (km) {
    const base = parseFloat(km[1].replace(",", "."));
    const mult = km[2].toLowerCase() === "m" ? 1000000 : 1000;
    return String(Math.round(base * mult));
  }
  const digits = t.replace(/[^\d]/g, "");
  return digits || "";
}

function parseCountsFromText(text) {
  const s = String(text || "");
  const mp = s.match(/([\d\.,]+\s*[km]?)\s*(posts?|publica(?:ç|c)ões)/i);
  const ms = s.match(/([\d\.,]+\s*[km]?)\s*(seguidores?|followers?)/i);
  const mg = s.match(/([\d\.,]+\s*[km]?)\s*(seguindo|following)/i);
  return {
    posts: parseNumberLike(mp && mp[1]),
    followers: parseNumberLike(ms && ms[1]),
    following: parseNumberLike(mg && mg[1])
  };
}

function getCountsFromDom() {
  const header = document.querySelector("header");
  if (!header) return { posts:"", followers:"", following:"" };

  const pickByHref = (endsWith) => {
    const a = header.querySelector(`a[href$="${endsWith}"]`);
    if (!a) return "";
    const titled = a.querySelector("span[title]");
    if (titled && titled.getAttribute("title")) return parseNumberLike(titled.getAttribute("title"));
    return parseNumberLike(a.textContent || a.innerText || "");
  };

  let followers = pickByHref("/followers/");
  let following = pickByHref("/following/");
  let posts = "";

  const ul = header.querySelector("section ul");
  if (ul) {
    const lis = Array.from(ul.querySelectorAll("li"));
    if (lis.length) posts = parseNumberLike(lis[0].textContent || lis[0].innerText || "");
  }

  const text = header.innerText || header.textContent || "";
  const byText = parseCountsFromText(text);
  if (!posts) posts = byText.posts;
  if (!followers) followers = byText.followers;
  if (!following) following = byText.following;

  return { posts, followers, following };
}

function getCountsRobust() {
  let c = getCountsFromDom();
  if (c.posts || c.followers || c.following) return { ...c, source:"dom" };

  const ogDesc = getMeta("og:description");
  c = parseCountsFromText(ogDesc);
  if (c.posts || c.followers || c.following) return { ...c, source:"og:description" };

  const targetUser = currentProfileUsername();
  const countJson = {
    posts: captureJsonNumberStrict("edge_owner_to_timeline_media_count", targetUser) || captureJsonNumberStrict("media_count", targetUser) || captureJsonNumberStrict("edge_owner_to_timeline_media", targetUser) || "",
    followers: captureJsonNumberStrict("edge_followed_by_count", targetUser) || captureJsonNumberStrict("follower_count", targetUser) || captureJsonNumberStrict("edge_followed_by", targetUser) || "",
    following: captureJsonNumberStrict("edge_follow_count", targetUser) || captureJsonNumberStrict("following_count", targetUser) || captureJsonNumberStrict("edge_follow", targetUser) || ""
  };
  if (countJson.posts || countJson.followers || countJson.following) return { ...countJson, source:"html_json" };

  const header = document.querySelector("header");
  if (header) {
    c = parseCountsFromText(header.innerText || header.textContent || "");
    if (c.posts || c.followers || c.following) return { ...c, source:"header_text" };
  }

  const txt = (document.body?.innerText || "");
  c = parseCountsFromText(txt);
  return { ...c, source:"body_text" };
}
function parseNameAndUser() {
  const urlUser = currentProfileUsername();

  const ogTitle = getMeta("og:title");
  const m = ogTitle.match(/^(.+?)\s+\(@([A-Za-z0-9_.]+)\)/);
  if (m) {
    const foundUser = m[2].trim();
    if (!urlUser || foundUser.toLowerCase() === urlUser.toLowerCase()) {
      return { displayName: m[1].trim(), username: foundUser };
    }
  }

  const t = (document.title || "").trim();
  const m2 = t.match(/^(.+?)\s+\(@([A-Za-z0-9_.]+)\)/);
  if (m2) {
    const foundUser = m2[2].trim();
    if (!urlUser || foundUser.toLowerCase() === urlUser.toLowerCase()) {
      return { displayName: m2[1].trim(), username: foundUser };
    }
  }

  const targetUser = urlUser;
  const fullName = captureJsonStringStrict("full_name", targetUser);
  const username = captureJsonStringStrict("username", targetUser) || targetUser;
  if (username) return { displayName: fullName, username: targetUser || username };

  const prof = instagramProfileUrlFromCurrent();
  if (prof) {
    const u = new URL(prof);
    const user = u.pathname.split("/").filter(Boolean)[0];
    return { displayName: "", username: user };
  }
  return { displayName:"", username:"" };
}
function getVisibleProfileText() {
  const header = document.querySelector("header");
  const text = [
    getMeta("og:title"),
    getMeta("og:description"),
    header?.innerText || "",
    document.body?.innerText || ""
  ].join("\n");
  return text;
}

function extractBioDetailed() {
  const fromHeader = extractBioFromHeaderDetailed();
  const targetUser = currentProfileUsername();
  const scopedBio = captureJsonStringStrict("biography", targetUser);

  if (fromHeader.text && scopedBio) {
    if (scopedBio.length > fromHeader.text.length + 12 || isProbablyTruncatedBio(fromHeader.text)) {
      return { text: mergeBioTexts([scopedBio, fromHeader.text]), source: "scoped_object+header" };
    }
    return scoreBioText(scopedBio) > scoreBioText(fromHeader.text)
      ? { text: mergeBioTexts([scopedBio, fromHeader.text]), source: "scoped_object+header" }
      : { text: mergeBioTexts([fromHeader.text, scopedBio]), source: "header+scoped_object" };
  }

  if (scopedBio) return { text: scopedBio, source: "scoped_object" };
  if (fromHeader.text) return fromHeader;
  return { text: "", source: "none" };
}

function extractBio() {
  return extractBioDetailed().text;
}

function extractCategory() {
  const targetUser = currentProfileUsername();
  const { displayName, username } = parseNameAndUser();
  const banned = new Set(
    uniqueNonEmpty([targetUser, username, displayName])
      .map(s => String(s || "").trim().toLowerCase())
      .filter(Boolean)
  );

  const jsonCategory = uniqueNonEmpty([
    captureJsonStringStrict("category_name", targetUser),
    captureJsonStringStrict("business_category_name", targetUser),
    captureJsonStringStrict("account_category", targetUser),
    captureJsonStringStrict("category", targetUser)
  ]).filter(t => !banned.has(String(t || "").trim().toLowerCase()));
  if (jsonCategory.length) return jsonCategory[0];

  const header = document.querySelector("header");
  if (header) {
    const textBlocks = uniqueNonEmpty(
      Array.from(header.querySelectorAll("section span, section div"))
        .map(el => (el.innerText || el.textContent || "").trim())
        .filter(Boolean)
        .filter(t => t.length >= 3 && t.length <= 80)
        .filter(t => !/@[A-Za-z0-9_.]+/.test(t))
        .filter(t => !banned.has(String(t || "").trim().toLowerCase()))
        .filter(t => !/(posts?|publica(?:ç|c)ões|seguidores?|followers?|seguindo|following)/i.test(t))
    );
    for (const t of textBlocks) {
      if (/imob|corret|consult|im[oó]veis|realtor|broker|neg[oó]cios|servi[cç]os|empreend|im[oó]vel/i.test(t)) return t;
    }
    if (textBlocks.length) return textBlocks[0];
  }
  return "";
}

function normalizeCargoText(value) {
  return String(value || "")
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanProfileTextForCargo(value) {
  let txt = String(value || "");
  if (!txt) return "";
  txt = txt
    .replace(/\r/g, "\n")
    .replace(/\u00A0/g, ' ')
    .replace(/^\s*[\d.,kKmM]+\s+(?:posts?|publica(?:c|ç)o(?:e|ẽ)s|seguidores?|followers?|seguindo|following)\s*$/gim, ' ')
    .replace(/^\s*seguido\(a\) por.*$/gim, ' ')
    .replace(/\be mais\s+\d+\b/gi, ' ')
    .replace(/(?:https?:\/\/|www\.|wa\.me\/|wa\.link\/|w\.app\/|bit\.ly\/|linktr\.ee\/|bio\.site\/|taplink\.cc\/|beacons\.ai\/|carrd\.co\/|solo\.to\/|msha\.ke\/|lnk\.bio\/)[^\s\n]+/gi, ' ')
    .replace(/@[A-Za-z0-9._]{2,30}/g, ' @ ')
    .replace(/\s{2,}/g, ' ')
    .replace(/\n{2,}/g, '\n')
    .trim();
  return txt;
}

function categoryIsWeakForCargo(category) {
  const n = normalizeCargoText(category);
  if (!n) return true;
  return [
    'opcoes', 'imovel', 'imoveis', 'produto servico', 'produto servicos', 'servico',
    'criador a de conteudo digital', 'empreendedor a', 'blog pessoal', 'blog',
    'pessoa publica', 'perfil pessoal'
  ].includes(n);
}

function detectCargoFromProfile(displayName, username, bio, category) {
  const raw = {
    Nome: String(displayName || '').trim(),
    Username: String(username || '').trim(),
    BIO: String(bio || '').trim(),
    CategoriaPerfil: String(category || '').trim()
  };

  const cleaned = {
    Nome: cleanProfileTextForCargo(raw.Nome),
    Username: cleanProfileTextForCargo(raw.Username),
    BIO: cleanProfileTextForCargo(raw.BIO),
    CategoriaPerfil: cleanProfileTextForCargo(raw.CategoriaPerfil)
  };

  const noisyBio = /(?:\bposts?\b|\bseguidores?\b|\bfollowers?\b|\bseguindo\b|\bfollowing\b|seguido\(a\) por|e mais \d+)/i.test(raw.BIO || '');
  const joinedClean = [cleaned.Nome, cleaned.Username, cleaned.BIO, cleaned.CategoriaPerfil].filter(Boolean).join('\n');
  const normalizedAll = normalizeCargoText(joinedClean);
  if (!normalizedAll) {
    return {
      cargo: '',
      cargoRaw: '',
      cargoOrigem: '',
      cargoConfianca: '',
      achouEx: 'NAO',
      flagEmpresa: 'NAO',
      flagRuido: noisyBio ? 'SIM' : 'NAO',
      cargoObs: 'sem_texto'
    };
  }

  const hasImobContext = /(\bcreci\b|imobili[aá]ria|im[oó]veis|consult(?:or|ora|oria) imobili[aá]r|corret(?:or|ora)|agente imobili[aá]rio|real estate|broker|mcmv|lan[cç]amento|cr[eé]dito imobili[aá]rio|avalia(?:dor|ção) de im[oó]veis|incorporador|investidor)/i.test(joinedClean);

  const exPatterns = [
    /\bex\s*-?\s*gerente(?:\s+de\s+vendas|\s+comercial)?\b/ig,
    /\bex\s*-?\s*corretor(?:a)?(?:\s+de\s+im[oó]veis)?\b/ig,
    /\bex\s*-?\s*consultor(?:a)?(?:\s+imobili[aá]ri[oa])?\b/ig,
    /\bex\s*-?\s*engenheir[oa](?:\s+civil)?\b/ig,
    /\bex\s*-?\s*diretor(?:a)?\b/ig,
    /\bex\s*-?\s*coordenador(?:a)?\b/ig,
    /\bex\s*-?\s*supervisor(?:a)?\b/ig,
    /\bformer\s+gerente\b/ig,
    /\bformer\s+broker\b/ig,
    /\bformer\s+realtor\b/ig
  ];

  const exHits = [];
  let sanitizedAll = joinedClean;
  for (const rx of exPatterns) {
    let m;
    rx.lastIndex = 0;
    while ((m = rx.exec(joinedClean)) !== null) {
      exHits.push(String(m[0] || '').trim());
    }
    sanitizedAll = sanitizedAll.replace(rx, ' ');
  }

  const obs = [];
  if (exHits.length) obs.push('ignorado_historico_ex');
  if (noisyBio) obs.push('bio_com_ruido_instagram');

  const roleDefs = [
    { cargo: 'Gerente de Vendas Imobiliárias', re: /\bgerente(?:\s+de\s+vendas|\s+comercial)?\b/i, score: 95 },
    { cargo: 'Coordenador Imobiliário', re: /\bcoordenador(?:a)?(?:\s+de\s+vendas|\s+comercial)?\b/i, score: 92 },
    { cargo: 'Supervisor Imobiliário', re: /\bsupervisor(?:a)?(?:\s+de\s+vendas|\s+comercial)?\b/i, score: 90 },
    { cargo: 'Gestor Imobiliário', re: /\bgestor(?:a)? imobili[aá]ri[oa]\b/i, score: 91 },
    { cargo: 'Especialista em Crédito Imobiliário', re: /\bespecialista\s+em\s+cr[eé]dito\s+imobili[aá]rio\b/i, score: 90 },
    { cargo: 'Avaliador de Imóveis', re: /\b(avaliador(?:a)?\s+de\s+im[oó]veis|avaliador(?:a)?\b|cnai\b)/i, score: 88 },
    { cargo: 'Advogado Imobiliário', re: /\b(advogad[oa].{0,24}direito\s+imobili[aá]rio|direito\s+imobili[aá]rio|advogad[oa]\s+imobili[aá]ri[oa])\b/i, score: 87 },
    { cargo: 'Incorporador', re: /\bincorporador(?:a)?\b/i, score: 86 },
    { cargo: 'Investidor Imobiliário', re: /\b(investidor(?:a)?(?:\s+imobili[aá]ri[oa])?|real\s+estate\s+investor)\b/i, score: 84 },
    { cargo: 'Consultor Imobiliário', re: /\b(consultor(?:a)?\s+imobili[aá]ri[oa]|consultoria\s+imobili[aá]ria|consultor(?:a)?\s+de\s+im[oó]veis)\b/i, score: 86 },
    { cargo: 'Agente Imobiliário', re: /\bagente\s+imobili[aá]rio\b/i, score: 84 },
    { cargo: 'Corretor de Imóveis', re: /\b(corretor(?:a)?(?:\s+de\s+im[oó]veis)?|corretora?\s+credenciada)\b/i, score: 85 },
    { cargo: 'Consultor de Investimentos Imobiliários', re: /\b(investimento(?:s)?\s+imobili[aá]rio(?:s)?|consultor(?:a)?\s+de\s+investimentos\s+imobili[aá]rios)\b/i, score: 82 },
    { cargo: 'Imobiliária', re: /\b(imobili[aá]ria|realty|construtora|incorporadora|empreendimentos\s+imobili[aá]rios)\b/i, score: 68 }
  ];

  const sources = [
    { name: 'BIO', text: cleaned.BIO, bonus: 14, weak: false },
    { name: 'Nome', text: cleaned.Nome, bonus: 9, weak: false },
    { name: 'Username', text: cleaned.Username, bonus: 4, weak: false },
    { name: 'CategoriaPerfil', text: cleaned.CategoriaPerfil, bonus: categoryIsWeakForCargo(cleaned.CategoriaPerfil) ? -12 : 2, weak: categoryIsWeakForCargo(cleaned.CategoriaPerfil) }
  ];

  const candidates = [];
  for (const src of sources) {
    const text = String(src.text || '').trim();
    if (!text) continue;
    let sanitized = text;
    for (const rx of exPatterns) {
      sanitized = sanitized.replace(rx, ' ');
    }
    for (const def of roleDefs) {
      const match = sanitized.match(def.re);
      if (!match) continue;
      let score = def.score + src.bonus;
      if (src.name === 'Username' && /(corret|consult|imob|imoveis|realestate|broker)/i.test(text)) score += 2;
      if (src.name === 'BIO' && /\bcreci\b/i.test(text)) score += 4;
      if (src.name === 'Nome' && /\|/.test(text)) score += 1;
      if (src.weak && !/\b(corret|consult|gerente|agente|avaliador|advogad|credito|incorporador|investidor|imobili[aá]ria)\b/i.test(text)) score -= 8;
      candidates.push({
        cargo: def.cargo,
        raw: String(match[0] || '').trim(),
        source: src.name,
        score
      });
    }
  }

  const hasCompanySignal = /\b(imobili[aá]ria|realty|construtora|incorporadora|empreendimentos?)\b/i.test([cleaned.Nome, cleaned.Username, cleaned.BIO].join(' '));
  const hasPersonRole = /\b(corretor(?:a)?|consultor(?:a)?|gerente|coordenador(?:a)?|supervisor(?:a)?|gestor(?:a)?|agente\s+imobili[aá]rio|avaliador(?:a)?|advogad[oa])\b/i.test(sanitizedAll);
  const flagEmpresa = (hasCompanySignal && !hasPersonRole) ? 'SIM' : 'NAO';

  if (!candidates.length) {
    if (!hasImobContext) {
      return {
        cargo: '',
        cargoRaw: '',
        cargoOrigem: '',
        cargoConfianca: '',
        achouEx: exHits.length ? 'SIM' : 'NAO',
        flagEmpresa,
        flagRuido: noisyBio ? 'SIM' : 'NAO',
        cargoObs: ['sem_contexto_imobiliario'].concat(obs).join(' | ')
      };
    }

    return {
      cargo: flagEmpresa === 'SIM' ? 'Imobiliária' : 'Profissional Imobiliário',
      cargoRaw: '',
      cargoOrigem: hasCompanySignal ? 'Nome' : 'BIO',
      cargoConfianca: 'BAIXA',
      achouEx: exHits.length ? 'SIM' : 'NAO',
      flagEmpresa,
      flagRuido: noisyBio ? 'SIM' : 'NAO',
      cargoObs: ['contexto_imobiliario_generico'].concat(obs).join(' | ')
    };
  }

  candidates.sort((a, b) => b.score - a.score);
  let best = candidates[0];

  if (best.cargo === 'Imobiliária' && hasPersonRole) {
    const personBest = candidates.find(c => c.cargo !== 'Imobiliária');
    if (personBest) best = personBest;
  }

  const confianca = best.score >= 96 ? 'ALTA' : (best.score >= 82 ? 'MEDIA' : 'BAIXA');

  return {
    cargo: best.cargo || '',
    cargoRaw: best.raw || '',
    cargoOrigem: best.source || '',
    cargoConfianca: confianca,
    achouEx: exHits.length ? 'SIM' : 'NAO',
    flagEmpresa,
    flagRuido: noisyBio ? 'SIM' : 'NAO',
    cargoObs: obs.join(' | ')
  };
}



function unwrapExternalUrl(raw) {
  let s = String(raw || "").trim();
  if (!s) return "";
  if (s.startsWith("//")) s = "https:" + s;
  if (/^www\./i.test(s)) s = "https://" + s;
  if (/^(wa\.me|api\.whatsapp\.com\/send|chat\.whatsapp\.com\/)/i.test(s)) s = "https://" + s;
  if (/^whatsapp:\/\//i.test(s)) {
    try {
      const u = new URL(s);
      const phone = u.searchParams.get("phone") || "";
      const text = u.searchParams.get("text") || u.searchParams.get("message") || "";
      const qs = new URLSearchParams();
      if (phone) qs.set("phone", phone);
      if (text) qs.set("text", text);
      return qs.toString() ? `https://api.whatsapp.com/send?${qs.toString()}` : "https://api.whatsapp.com/send";
    } catch {
      return s;
    }
  }
  try {
    const u = new URL(s, location.origin);
    const host = u.hostname.replace(/^www\./i, '').toLowerCase();
    if ((host === 'l.instagram.com' || host === 'l.facebook.com') && u.searchParams.get('u')) {
      return unwrapExternalUrl(decodeURIComponent(u.searchParams.get('u') || ''));
    }
    if ((u.pathname === '/url' || u.pathname === '/outgoing') && (u.searchParams.get('q') || u.searchParams.get('url'))) {
      return unwrapExternalUrl(decodeURIComponent(u.searchParams.get('q') || u.searchParams.get('url') || ''));
    }
    return /^https?:\/\//i.test(u.toString()) ? u.toString() : '';
  } catch {
    return /^https?:\/\//i.test(s) ? s : '';
  }
}

function isWhatsappUrl(u) {
  return /(?:wa\.me\/|api\.whatsapp\.com\/|whatsapp\.com\/|chat\.whatsapp\.com\/)/i.test(String(u || ''));
}

function scoreExternalLink(u) {
  const s = String(u || '').toLowerCase();
  if (!s) return -1;
  if (/(?:about\.meta\.com|developers\.facebook\.com|meta\.ai|threads\.com|help\.instagram\.com|privacycenter\.instagram\.com|facebook\.com\/help\/instagram)/i.test(s)) return -1;
  if (/wa\.me\/message\//i.test(s)) return 250;
  if (/wa\.me\/\d+/i.test(s)) return 240;
  if (/api\.whatsapp\.com\/send/i.test(s) && /phone=\d+/i.test(s)) return 230;
  if (/whatsapp\.com\//i.test(s) || /chat\.whatsapp\.com\//i.test(s)) return 220;
  if (/(linktr\.ee|beacons\.ai|msha\.ke|lnk\.bio|bio\.site|carrd\.co|solo\.to|taplink\.cc|many\.bio)/i.test(s)) return 120;
  return 40;
}

function normalizeBrazilPhone(raw) {
  let digits = String(raw || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('55') && digits.length >= 12) digits = digits.slice(2);
  if (!(digits.length === 10 || digits.length === 11)) return '';
  if (!/^[1-9]\d/.test(digits)) return '';
  return digits;
}

function extractPhoneDigitsFromWhatsappUrl(u) {
  const s = String(u || '');
  let m = s.match(/wa\.me\/(\d{10,15})/i);
  if (m) return normalizeBrazilPhone(m[1]);
  m = s.match(/[?&]phone=(\d{10,15})/i);
  if (m) return normalizeBrazilPhone(m[1]);
  return '';
}

function extractUrlsFromText(text) {
  const out = [];
  const rx = /(https?:\/\/[^\s"'<>]+|wa\.me\/[^\s"'<>]+|api\.whatsapp\.com\/send[^\s"'<>]+|www\.[^\s"'<>]+\.[^\s"'<>]+)/ig;
  let m;
  while ((m = rx.exec(String(text || ''))) !== null) {
    const u = unwrapExternalUrl(m[0]);
    if (u) out.push(u);
  }
  return out;
}

function uniqueSortedLinks(list) {
  const out = [];
  const seen = new Set();
  for (const raw of list || []) {
    const u = unwrapExternalUrl(raw);
    if (!u) continue;
    if (/threads\.com/i.test(u)) continue;
    if (/(?:about\.meta\.com|developers\.facebook\.com|meta\.ai|help\.instagram\.com|privacycenter\.instagram\.com|facebook\.com\/help\/instagram)/i.test(u)) continue;
    if (/instagram\.com/i.test(u) && !/l\.instagram\.com/i.test(u)) continue;
    if (/^tel:/i.test(u) || /^mailto:/i.test(u)) continue;
    if (seen.has(u)) continue;
    seen.add(u);
    out.push(u);
  }
  return out.sort((a, b) => scoreExternalLink(b) - scoreExternalLink(a));
}

function extractExternalLinks() {
  const found = [];
  const push = (u) => { if (u) found.push(u); };

  const targetUser = currentProfileUsername();
  uniqueNonEmpty([
    captureJsonStringStrict("external_url", targetUser),
    captureJsonStringStrict("external_url_linkshimmed", targetUser),
    captureJsonStringStrict("bio_links", targetUser)
  ]).forEach(push);

  for (const src of scopedObjectSources(targetUser)) extractUrlsFromText(src).forEach(push);

  const header = document.querySelector("header") || document;
  for (const a of Array.from(header.querySelectorAll('a[href]'))) push(a.getAttribute('href') || "");
  for (const a of Array.from(document.querySelectorAll('a[href]'))) push(a.getAttribute('href') || "");
  extractUrlsFromText(getVisibleProfileText()).forEach(push);

  return uniqueSortedLinks(found).slice(0, 3);
}
function extractPhoneBundle() {
  let phone = "";
  let phoneLine = "";
  let phoneWa = "";

  const externalLinks = extractExternalLinks();
  for (const link of externalLinks) {
    if (isWhatsappUrl(link)) {
      if (!phoneWa) phoneWa = link;
      const digits = extractPhoneDigitsFromWhatsappUrl(link);
      if (digits && !phone) phone = digits;
    }
  }

  const links = Array.from(document.querySelectorAll('a[href]')).map(a => a.getAttribute('href')||"");
  for (const href of links) {
    const unwrapped = unwrapExternalUrl(href);
    if (isWhatsappUrl(unwrapped)) {
      if (!phoneWa) phoneWa = unwrapped;
      const digits = extractPhoneDigitsFromWhatsappUrl(unwrapped);
      if (digits && !phone) phone = digits;
    }
    if (String(href || '').startsWith("tel:")) {
      const raw = href.replace("tel:","").trim();
      const digits = normalizeBrazilPhone(raw);
      if (digits) {
        if (!phoneLine) phoneLine = raw;
        if (!phone) phone = digits;
      }
    }
  }

  const visibleText = getVisibleProfileText();
  const inlineUrls = extractUrlsFromText(visibleText);
  for (const link of inlineUrls) {
    if (isWhatsappUrl(link)) {
      if (!phoneWa) phoneWa = link;
      const digits = extractPhoneDigitsFromWhatsappUrl(link);
      if (digits && !phone) phone = digits;
    }
  }

  const inlineWaMatch = String(visibleText || '').match(/(?:wa\.me\/|api\.whatsapp\.com\/send\?phone=)(\d{10,15})/i);
  if (inlineWaMatch) {
    const digits = normalizeBrazilPhone(inlineWaMatch[1]);
    if (digits) {
      if (!phone) phone = digits;
      if (!phoneWa) phoneWa = `https://wa.me/55${digits}`;
    }
  }

  const targetUser = currentProfileUsername();
  const jsonPhone = uniqueNonEmpty([
    captureJsonStringStrict("public_phone_number", targetUser),
    captureJsonStringStrict("business_phone_number", targetUser),
    captureJsonStringStrict("contact_phone_number", targetUser)
  ]);
  if (!phone && jsonPhone.length) {
    const digits = normalizeBrazilPhone(jsonPhone[0]);
    if (digits) {
      phoneLine = jsonPhone[0];
      phone = digits;
    }
  }

  const linesVisible = visibleText.split(/\n+/).map(s => s.trim()).filter(Boolean);
  const phoneRx = /(?:\+?55\s*)?\(?\d{2}\)?\s*9?\d{4}[.\-\s]?\d{4}/;
  for (let i = 0; i < linesVisible.length; i++) {
    const combined = [linesVisible[i - 1] || '', linesVisible[i] || '', linesVisible[i + 1] || ''].filter(Boolean).join(' ');
    const hasContext = /(whats|whatsapp|telefone|fone|contato|chama|ligue|atendimento|celular|cel\b|wa\.me)/i.test(combined);
    const m = combined.match(phoneRx) || (linesVisible[i] || '').match(phoneRx);
    if (!m) continue;
    const digits = normalizeBrazilPhone(m[0]);
    if (!digits) continue;
    if (!hasContext && i > 0 && !/(contato|whats|telefone|fone|ligue|chama|wa\.me)/i.test(linesVisible[i - 1] || '')) continue;
    if (!phoneLine) phoneLine = m[0].trim();
    if (!phone) phone = digits;
    if (!phoneWa && hasContext) phoneWa = `https://wa.me/55${digits}`;
    break;
  }

  return {
    phone: phone || "",
    phoneWa: phoneWa || "",
    phoneLine: phoneLine || ""
  };
}
function extractCreciBundle(text) {
  const source = String(text || "");
  const regex = /\bCRECI\b[^\dA-Z]*([A-Z]{0,3})?\s*(\d{2,7})(?:\s*[-\/ ]?\s*([A-Z]{1,3}))?/ig;
  const matches = [];
  let m;
  while ((m = regex.exec(source)) !== null) {
    const raw = m[0].trim();
    const number = String(m[2] || "").trim();
    matches.push({ raw, number });
  }
  const best = matches.sort((a, b) => String(b.raw || '').length - String(a.raw || '').length)[0] || { raw:"", number:"" };
  return {
    creciText: best.raw || "",
    creciNumber: best.number || ""
  };
}

function extractScopedEvidenceText() {
  const targetUser = currentProfileUsername();
  const parts = [];
  const bio = captureJsonStringStrict("biography", targetUser);
  if (bio) parts.push(bio);
  for (const src of scopedObjectSources(targetUser).slice(0, 12)) {
    const cleaned = decodeJsonEscapedString(String(src || '').replace(/<[^>]+>/g, ' '));
    if (cleaned) parts.push(cleaned);
  }
  return uniqueNonEmpty(parts).join("\n").slice(0, 12000);
}

function extractCepText(text) {
  const m = String(text || "").match(/\b\d{5}-?\d{3}\b/);
  return m ? m[0] : "";
}

function looksRealEstateProfile(extraText="") {
  const txt = ((getMeta("og:description") || "") + "\n" + getVisibleProfileText() + "\n" + String(extraText || "")).toLowerCase();
  const strong = /\b(creci|corretor(?:a)?(?: de im[oó]veis)?|imobili[aá]ria|im[oó]veis|broker|realtor)\b/i.test(txt);
  const context = /\b(venda|vende|aluga|loca[cç][aã]o|financiamento|mcmv|lan[cç]amento|alto padrão|capta[cç][aã]o|administra)\b/i.test(txt);
  const asset = /\b(casa|apartamento|apto|terreno|lote|im[oó]vel|empreendimento)\b/i.test(txt);
  const negativeCouncil = /\b(crefito|coffito|crm|crp|coren|oab|cro|crf|crea|cau|crbio)\b/i.test(txt);
  const negativeOccupation = /\b(fisioterapeuta|m[eé]dico|dentista|psic[oó]log|enfermeir|advogad|nutricion|farmac)\b/i.test(txt);

  if (negativeCouncil && !/\bcreci\b/i.test(txt)) return false;
  if (negativeOccupation && !strong && !(context && asset)) return false;
  return strong || (context && asset);
}
function getProfileReadySnapshot() {
  const og = getMeta("og:title");
  const desc = getMeta("og:description");
  const title = (document.title || "").trim();
  const header = document.querySelector("header");
  const headerText = (header?.innerText || header?.textContent || "").trim();
  const bodyText = (document.body?.innerText || "").trim();

  const hasOgPair = !!(og && desc);
  const hasTitleUser = /\(@[A-Za-z0-9_.]+\)/.test(og || "") || /\(@[A-Za-z0-9_.]+\)/.test(title || "");
  const hasHeader = !!header;
  const hasRichHeader = headerText.length > 20;
  const hasCountHints = /\b(posts?|publica(?:ç|c)ões|seguidores?|followers?|seguindo|following)\b/i.test(headerText || bodyText);

  return {
    hasOgPair,
    hasTitleUser,
    hasHeader,
    hasRichHeader,
    hasCountHints,
    title: shortDbg(title, 120),
    ogTitle: shortDbg(og, 120),
    ogDesc: shortDbg(desc, 120),
    headerText: shortDbg(headerText, 120)
  };
}

async function waitProfileReady(timeoutMs=9000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const snap = getProfileReadySnapshot();
    if (snap.hasOgPair || snap.hasTitleUser || snap.hasRichHeader || snap.hasCountHints) return true;
    await sleep(400);
  }
  return false;
}

async function saveToSheet(payload) {
  const st = await getState();
  if (!st.pending) throw new Error("no_pending");
  const body = {
    action: "saveigdata",
    row: st.pending.row,
    sourceCreciRaw: st.pending.creciRaw || "",
    status: payload.status || "OK",
    detail: payload.detail || "",
    RHI_IG_INSTAGRAM_URL: payload.igUrl || "",
    RHI_IG_USERNAME: payload.Username || "",
    RHI_IG_NOME_PERFIL: payload.NomePerfil || payload.igName || "",
    RHI_IG_BIO: payload.BIO || "",
    RHI_IG_CARGO: payload.Cargo || payload.CARGO || "",
    RHI_IG_CARGO_RAW: payload.CargoRaw || "",
    RHI_IG_CARGO_ORIGEM: payload.CargoOrigem || "",
    RHI_IG_CARGO_CONFIANCA: payload.CargoConfianca || "",
    RHI_IG_ACHOU_EX: payload.AchouEx || "",
    RHI_IG_FLAG_EMPRESA: payload.FlagEmpresa || "",
    RHI_IG_FLAG_RUIDO: payload.FlagRuido || "",
    RHI_IG_CARGO_OBS: payload.CargoObs || "",
    RHI_IG_CATEGORIA_PERFIL: payload.CategoriaPerfil || "",
    RHI_IG_TELEFONE_WA: payload.TelefoneWA || "",
    RHI_IG_TELEFONE_TXT: payload.TelefoneTXT || payload.phone || "",
    RHI_IG_CRECI_TEXTO: payload.CreciTexto || payload.CRECI || "",
    RHI_IG_CRECI_NUMERO: payload.CreciNumero || payload.CRECI_NUMERO || "",
    RHI_IG_CEP_TEXTO: payload.CepTexto || payload.CEP_TEXTO || "",
    RHI_IG_SEGUIDORES: payload.followers || "",
    RHI_IG_SEGUINDO: payload.following || "",
    RHI_IG_POSTAGENS: payload.posts || "",
    Origem: payload.Origem || "extension_creci_google_v4_5_3",
    spreadsheetId: st.spreadsheetId || "",
    tab: st.tab || "",
    rowStart: st.rowStart || 2,
    rowEnd: st.rowEnd || 0,
    creciColumn: st.creciColumn || ""
  };
  await debugLog("save_igdata", shortDbg(JSON.stringify(body)), { source:"instagram" });
  return await gasCallRetry(() => gasPost(st.endpoint, body));
}

async function saveStatusOnly(status, detail="") {
  const st = await getState();
  if (!st.pending) return;
  try {
    await debugLog("save_status", `${status} | ${detail}`, { source:"instagram" });
    await gasCallRetry(() => gasPost(st.endpoint, {
      action:"savestatus",
      row: st.pending.row,
      status,
      detail,
      sourceCreciRaw: st.pending.creciRaw || "",
      spreadsheetId: st.spreadsheetId || "",
      tab: st.tab || "",
      rowStart: st.rowStart || 2,
      rowEnd: st.rowEnd || 0,
      creciColumn: st.creciColumn || ""
    }));
  } catch {}
}

async function main() {
  if (window.__creci_ig_ran) return;
  window.__creci_ig_ran = true;

  const st = await getState();
  if (!st.running || !st.endpoint) return;
  const delays = getDelaySettings(st);

  const claim = await claimWorker("instagram");
  if (!claim?.ok) {
    await debugLog("ig_not_owner", `${claim?.reason || "worker_busy"} | ownerTab=${claim?.owner?.tabId ?? ""}`, { source:"instagram", level:"warn" });
    return;
  }

  await touchWorker("instagram");
  await debugLog("ig_main_start", `href=${location.href} | ownerTab=${claim?.owner?.tabId ?? ""}`, { source:"instagram" });

  if (st.pauseUntil && Date.now() < st.pauseUntil) {
    const secs = Math.ceil((st.pauseUntil - Date.now())/1000);
    overlay(`Pausado por instabilidade do GAS. Retomando em ${secs}s…`);
    await debugLog("paused", `retoma em ${secs}s`, { source:"instagram", level:"warn" });
    setTimeout(()=>location.reload(), Math.min(30000, (st.pauseUntil-Date.now())+500));
    return;
  }

  try {
    const path = location.pathname || "";
    const isProfile = /^\/[A-Za-z0-9._]+\/$/.test(path);
    const isPostOrReel = /^\/(reel|reels|p|tv)\//.test(path);

    const extractUsernameFromLdJson = () => {
      try {
        const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
        for (const s of scripts) {
          const txt = (s.textContent || "").trim();
          if (!txt) continue;
          const obj = JSON.parse(txt);
          const stack = [obj];
          while (stack.length) {
            const cur = stack.pop();
            if (!cur || typeof cur !== "object") continue;

            const author = cur.author;
            if (author && typeof author === "object") {
              const alt = author.alternateName || author.alternate_name;
              if (typeof alt === "string") {
                const u = alt.replace(/^@/, "").trim();
                if (/^[A-Za-z0-9._]{3,30}$/.test(u)) return u;
              }
              for (const k of ["@id","url"]) {
                if (typeof author[k] === "string") {
                  const mm = author[k].match(/instagram\.com\/(?:@)?([A-Za-z0-9._]{3,30})\/?/i);
                  if (mm) return mm[1];
                }
              }
            }
            for (const k of ["@id","url"]) {
              if (typeof cur[k] === "string") {
                const mm = cur[k].match(/instagram\.com\/(?:@)?([A-Za-z0-9._]{3,30})\/?/i);
                if (mm) return mm[1];
              }
            }
            for (const v of Object.values(cur)) {
              if (v && typeof v === "object") stack.push(v);
            }
          }
        }
      } catch(e) {}
      return "";
    };

    const extractUserFromHeaderOrSpan = () => {
      const header = document.querySelector("header");
      const scope = header || document;
      const anchors = Array.from(scope.querySelectorAll('a[href^="/"]'));
      for (const a of anchors) {
        const href = a.getAttribute("href") || "";
        const m = href.match(/^\/([A-Za-z0-9._]{3,30})\/?$/);
        if (!m) continue;
        const u = m[1];
        if (!u || ["explore","reels","p","reel","tv","stories","accounts","about","privacy","terms","direct"].includes(u)) continue;
        return u;
      }
      const spans = Array.from(document.querySelectorAll('span[dir="auto"]'));
      for (const sp of spans) {
        const t = (sp.textContent || "").trim();
        if (/^[A-Za-z0-9._]{3,30}$/.test(t) && !t.includes(" ")) return t;
      }
      return "";
    };

    if (!isProfile && isPostOrReel) {
      overlay("Instagram abriu POST/REEL. Indo para o perfil do autor…");
      await debugLog("ig_post_or_reel", `pathname=${path}`, { source:"instagram", level:"warn" });
      await sleep(Math.max(450 + Math.random()*350, delays.delayOpenProfileMs));
      const user = extractUsernameFromLdJson() || extractUserFromHeaderOrSpan();
      if (user) {
        await debugLog("ig_redirect_author_profile", `${user} | delay=${delays.delayOpenProfileMs}ms`, { source:"instagram" });
        await sleep(delays.delayOpenProfileMs);
        location.href = `https://www.instagram.com/${user}/`;
        return;
      }
      await debugLog("ig_post_no_username", "sem username no post/reel", { source:"instagram", level:"warn" });
      await saveStatusOnly("SEM_RESULTADO", "ig_post_sem_username");
      await setState({ pending: null });
      await sleep(delays.delayNextRowMs);
      location.href = BASE_GOOGLE;
      return;
    }
  } catch (e) {}

  let profileUrl = instagramProfileUrlFromCurrent();
  if (!profileUrl && /^https:\/\/www\.instagram\.com\/[A-Za-z0-9._]+\/?$/i.test(location.href)) profileUrl = location.href.split('?')[0];
  if (!profileUrl) {
    overlay("Não é página de PERFIL (post/reel).\nMarcando NAO_PERFIL e voltando…");
    await debugLog("ig_not_profile", location.pathname, { source:"instagram", level:"warn" });
    await saveStatusOnly("NAO_PERFIL", "not_profile");
    await setState({ pending: null });
    await sleep(delays.delayNextRowMs);
    location.href = BASE_GOOGLE;
    return;
  }

  overlay(`Perfil IG aberto ✅\nAguardando dados…\n${profileUrl}`);
  await debugLog("ig_profile_detected", profileUrl, { source:"instagram" });

  const startedProfileWait = Date.now();
  const beforeWait = getProfileReadySnapshot();
  await debugLog("ig_wait_profile_ready_start", JSON.stringify(beforeWait), { source:"instagram" });

  const okReady = await waitProfileReady(9000);
  const afterWait = getProfileReadySnapshot();
  await debugLog(
    okReady ? "ig_wait_profile_ready_ok" : "ig_wait_profile_ready_timeout",
    `esperou ${Date.now()-startedProfileWait}ms | ${JSON.stringify(afterWait)}`,
    { source:"instagram", level: okReady ? "info" : "warn" }
  );

  if (!okReady) {
    const canContinue =
      afterWait.hasTitleUser ||
      afterWait.hasHeader ||
      afterWait.hasRichHeader ||
      afterWait.hasCountHints;

    if (!canContinue) {
      overlay("Timeout lendo perfil.\nSem sinais suficientes do Instagram.\nMarcando ERRO e voltando…");
      await debugLog("ig_timeout_meta", `esperou ${Date.now()-startedProfileWait}ms`, { source:"instagram", level:"error" });
      await saveStatusOnly("ERRO", "ig_timeout_meta");
      await setState({ pending: null });
      await sleep(delays.delayNextRowMs);
      location.href = BASE_GOOGLE;
      return;
    }

    overlay("Metadados OG não vieram completos.\nSeguindo com fallback pelo DOM…");
    await debugLog("ig_continue_without_og", JSON.stringify(afterWait), { source:"instagram", level:"warn" });
  }

  await touchWorker("instagram");
  await expandProfileBioIfNeeded();
  const { displayName, username } = parseNameAndUser();
  const counts = getCountsRobust();
  const bioDetailed = extractBioDetailed();
  const bio = bioDetailed.text;
  const category = extractCategory();
  const cargoInfo = detectCargoFromProfile(displayName, username, bio, category);
  const cargo = cargoInfo.cargo || "";
  const links = extractExternalLinks();
  const phones = extractPhoneBundle();
  const scopedEvidence = extractScopedEvidenceText();
  const creci = extractCreciBundle([bio, category, getVisibleProfileText(), scopedEvidence].join("\n"));
  const cepText = extractCepText([bio, getVisibleProfileText(), scopedEvidence].join("\n"));

  const igName = (displayName || username || "").trim();
  const targetDigits = normalizeCreci6(st.pending?.creciRaw || "");
  const profileSignalsText = [igName, username, bio, category, getVisibleProfileText(), scopedEvidence].join("\n");
  const exactTargetOnProfile = !!(targetDigits && new RegExp(`\\b${targetDigits}\\b`).test(profileSignalsText));
  const divergentCreci = !!(creci.creciNumber && targetDigits && creci.creciNumber !== targetDigits);
  const related = (looksRealEstateProfile([bio, category, creci.creciText].join(" ")) || !!creci.creciText || exactTargetOnProfile) && !divergentCreci;
  const status = !related ? "NAO_RELACIONADO" : (phones.phone ? "OK" : "OK_SEM_TEL");
  const hasExtractionEvidence = !![profileUrl, igName, username, bio, category, counts.posts, counts.followers, counts.following, phones.phone, phones.phoneWa, creci.creciText, cargo].find(v => String(v || '').trim());

  await debugLog("ig_bio_source", `${bioDetailed.source} | ${shortDbg(bio, 160)}`, { source:"instagram" });

  await debugLog("ig_parsed_profile", JSON.stringify({
    profileUrl,
    displayName,
    username,
    counts,
    bio: shortDbg(bio, 180),
    category,
    cargoInfo,
    cargo,
    links,
    phones,
    creci,
    cepText,
    scopedEvidence: shortDbg(scopedEvidence, 180)
  }), { source:"instagram" });

  await debugLog("ig_profile_classified", `related=${related} | status=${status} | countSource=${counts.source||""} | wa=${shortDbg(phones.phoneWa || links[0] || "", 120)}`, { source:"instagram" });

  overlay(
    `Extraído ✅\n` +
    `Nome: ${igName}\n` +
    `User: ${username}\n` +
    `Posts: ${counts.posts} | Seguidores: ${counts.followers} | Seguindo: ${counts.following}\n` +
    `Telefone: ${phones.phone || "(não encontrado)"}\n` +
    `CRECI: ${creci.creciText || "(não encontrado)"}\n` +
    `Categoria: ${category || "(não encontrada)"}\n` +
    `Cargo: ${cargo || "(não detectado)"}\n` +
    `Status: ${status}\n` +
    `Salvando na planilha…`
  );

  try {
    await touchWorker("instagram");
    if (!hasExtractionEvidence) {
      await debugLog("ig_empty_payload", "sem evidência mínima de extração", { source:"instagram", level:"error" });
      await saveStatusOnly("ERRO", "ig_payload_vazio");
      await setState({ pending: null });
      await sleep(delays.delayNextRowMs);
      location.href = BASE_GOOGLE;
      return;
    }
    await saveToSheet({
      igUrl: profileUrl,
      igName,
      phone: phones.phone,
      followers: counts.followers,
      following: counts.following,
      posts: counts.posts,
      status,
      detail: divergentCreci ? "ig_creci_divergente" : (related ? "ig_ok_extended_whatsapp" : "ig_not_real_estate"),
      Username: username,
      NomePerfil: igName,
      BIO: bio,
      Cargo: cargo,
      CARGO: cargo,
      CargoRaw: cargoInfo.cargoRaw || "",
      CargoOrigem: cargoInfo.cargoOrigem || "",
      CargoConfianca: cargoInfo.cargoConfianca || "",
      AchouEx: cargoInfo.achouEx || "NAO",
      FlagEmpresa: cargoInfo.flagEmpresa || "NAO",
      FlagRuido: cargoInfo.flagRuido || "NAO",
      CargoObs: cargoInfo.cargoObs || "",
      CategoriaPerfil: category,
      LinkExterno: phones.phoneWa || links[0] || "",
      LinkExterno2: links.find(u => u && u !== (phones.phoneWa || links[0] || "")) || "",
      TelefoneWA: phones.phoneWa || "",
      TelefoneTXT: phones.phone || phones.phoneLine,
      TelefoneTxtLinha: phones.phoneLine,
      CRECI: creci.creciText,
      CreciTexto: creci.creciText,
      CRECI_NUMERO: creci.creciNumber,
      CreciNumero: creci.creciNumber,
      CEP_TEXTO: cepText,
      CepTexto: cepText,
      Origem: "extension_creci_google_v4_5_1"
    });

    overlay("Salvo ✅\nIndo para o próximo…");
    await debugLog("ig_saved_ok", `row=${st.pending?.row||""} | next google`, { source:"instagram" });
    await setState({ pending: null });
    await sleep(delays.delayNextRowMs);
    location.href = BASE_GOOGLE;
  } catch (e) {
    overlay("Falha ao salvar ❌\n" + (e?.message || e));
    await debugLog("ig_save_error", e?.message || String(e), { source:"instagram", level:"error" });
    await saveStatusOnly("ERRO", "save_fail");
    await setState({ pauseUntil: Date.now() + 60000 });
  }
}

async function safeMain() {
  try {
    await main();
  } catch (e) {
    try {
      overlay("Erro inesperado no Instagram.\n" + (e?.message || e));
      await debugLog("ig_fatal_error", e?.stack || e?.message || String(e), { source:"instagram", level:"error" });
      await saveStatusOnly("ERRO", "ig_fatal_error");
      await setState({ pending: null });
      const st = await getState();
      const delays = getDelaySettings(st);
      await sleep(delays.delayNextRowMs);
      location.href = BASE_GOOGLE;
    } catch {}
  }
}

document.addEventListener("DOMContentLoaded", () => setTimeout(safeMain, 300));
window.addEventListener("load", () => setTimeout(safeMain, 650));
