const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const BASE_GOOGLE = "https://www.google.com/search?hl=pt-BR&q=CRECI";

function overlay(msg) {
  let el = document.getElementById("__creci_ig_overlay");
  if (!el) {
    el = document.createElement("div");
    el.id = "__creci_ig_overlay";
    Object.assign(el.style, {
      position: "fixed",
      bottom: "10px",
      right: "10px",
      zIndex: 999999,
      background: "rgba(15,23,42,.92)",
      color: "#eaf0ff",
      padding: "10px 12px",
      borderRadius: "10px",
      font: "12px/1.45 system-ui,Segoe UI,Roboto,Arial",
      maxWidth: "560px",
      whiteSpace: "pre-wrap"
    });
    document.body.appendChild(el);
  }
  el.textContent = msg;
}

async function getState() {
  return await chrome.storage.local.get({ running:false, endpoint:"", spreadsheetId:"", tab:"", rowStart:2, rowEnd:0, creciColumn:"", delaySearchMs:1500, delayOpenProfileMs:1500, delayNextRowMs:2000, pending:null, debug:false, pauseUntil:0 });
}
async function setState(patch) { await chrome.storage.local.set(patch); }

function clampDelay(v, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(60000, Math.round(n)));
}
function getDelaySettings(st) {
  return {
    delaySearchMs: clampDelay(st?.delaySearchMs, 1500),
    delayOpenProfileMs: clampDelay(st?.delayOpenProfileMs, 1500),
    delayNextRowMs: clampDelay(st?.delayNextRowMs, 2000)
  };
}

async function debugLog(event, detail="", extra={}) {
  try {
    const st = await chrome.storage.local.get({ debug:false, pending:null });
    if (!st.debug && !extra.force) return;
    chrome.runtime.sendMessage({
      type: "DEBUG_LOG",
      source: extra.source || "google",
      event,
      detail: typeof detail === "string" ? detail : JSON.stringify(detail),
      row: extra.row ?? st.pending?.row ?? null,
      creci: extra.creci || st.pending?.creciRaw || "",
      pending: st.pending || null,
      url: location.href,
      level: extra.level || "info"
    }, ()=>void chrome.runtime.lastError);
  } catch {}
}
function shortDbg(v, n=240) {
  const s = String(v ?? "");
  return s.length > n ? s.slice(0, n) + "…" : s;
}

async function workerCall(type, extra={}) {
  return await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...extra }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) return resolve({ ok:false, error: err.message || String(err) });
      resolve(resp || { ok:false, error:"no_response" });
    });
  });
}
async function claimWorker(role="google") { return await workerCall("WORKER_CLAIM", { role }); }
async function touchWorker(role="google") { return await workerCall("WORKER_TOUCH", { role }); }
async function releaseWorker(force=false) { return await workerCall("WORKER_RELEASE", { force }); }

function isRunnableGooglePage() {
  try {
    const u = new URL(location.href);
    if (!/google\./i.test(u.hostname)) return false;
    const p = u.pathname || "";
    if (/warmup\.html/i.test(p)) return false;
    if (/sorry\/index/i.test(p)) return true;
    if (p === "/search" || p === "/webhp" || p === "/") return true;
    return false;
  } catch {
    return false;
  }
}

async function gasGet(endpoint, params) {
  await debugLog("gas_get_call", shortDbg(JSON.stringify(params||{})));
  return await new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "GAS_GET", endpoint, params, source:"google" }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) return reject(new Error("runtime_lastError: " + err.message));
      if (!resp) return reject(new Error("no_response"));
      if (resp.ok === false) return reject(new Error(resp.error || "gas_get_failed"));
      if (!resp.http_ok) return reject(new Error(`GAS_HTTP_${resp.status}: ${(resp.text||"").slice(0,220)}`));
      if (resp.json) {
        debugLog("gas_get_ok", `HTTP ${resp.status} em ${resp.elapsedMs||0}ms`).catch(()=>{});
        return resolve(resp.json);
      }
      return reject(new Error("GAS_INVALID_JSON: " + (resp.text||"").slice(0,220)));
    });
  });
}

async function gasPost(endpoint, body) {
  await debugLog("gas_post_call", `${body?.action||"payload"} | ${shortDbg(JSON.stringify(body||{}))}`);
  return await new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "GAS_POST", endpoint, body, source:"google" }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err) return reject(new Error("runtime_lastError: " + err.message));
      if (!resp) return reject(new Error("no_response"));
      if (resp.ok === false) return reject(new Error(resp.error || "gas_post_failed"));
      if (!resp.http_ok) return reject(new Error(`GAS_HTTP_${resp.status}: ${(resp.text||"").slice(0,220)}`));
      if (resp.json) {
        debugLog("gas_post_ok", `HTTP ${resp.status} em ${resp.elapsedMs||0}ms`).catch(()=>{});
        return resolve(resp.json);
      }
      return reject(new Error("GAS_INVALID_JSON: " + (resp.text||"").slice(0,220)));
    });
  });
}

async function gasCallRetry(fn, tries=8) {
  let lastErr = null;
  for (let i=0;i<tries;i++){
    try { return await fn(); }
    catch (e) {
      lastErr = e;
      const msg = String(e && e.message ? e.message : e);
      const transient = /GAS_INVALID_JSON|GAS_HTTP_5|GAS_HTTP_429|Failed to fetch|network|timeout|temporar/i.test(msg);
      if (!transient || i === tries-1) break;

      const delay = Math.min(60000, (1500 * Math.pow(2,i)) + Math.floor(Math.random()*400));
      overlay(`GAS instável, retry ${i+1}/${tries} em ${Math.ceil(delay/1000)}s…
${msg.slice(0,160)}`);
      await debugLog("gas_retry", `${i+1}/${tries} em ${delay}ms | ${shortDbg(msg)}`, { level:"warn" });
      await sleep(delay);
    }
  }
  throw lastErr;
}

function normalizeCreci6(creciRaw) {
  const m = String(creciRaw||"").match(/\d+/g);
  const s = m ? m.join("") : "";
  return s.slice(0, 6);
}

function buildQuery(creciRaw) {
  const n = normalizeCreci6(creciRaw);
  return `CRECI ${n} instagram site:instagram.com`;
}

function buildSearchUrl(creciRaw) {
  return "https://www.google.com/search?hl=pt-BR&num=10&q=" + encodeURIComponent(buildQuery(creciRaw));
}

function normalizeSearchName(name) {
  return String(name || '').replace(/[|•·]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function buildFallbackQuery(creciRaw, searchLink) {
  const name = normalizeSearchName(searchLink);
  if (!name) return '';
  const digits = normalizeCreci6(creciRaw);
  const suffix = digits ? ` "${digits}"` : '';
  return `"${name}" instagram site:instagram.com${suffix}`;
}

function buildFallbackSearchUrl(creciRaw, searchLink) {
  const q = buildFallbackQuery(creciRaw, searchLink);
  return q ? ("https://www.google.com/search?hl=pt-BR&num=10&q=" + encodeURIComponent(q)) : '';
}

function getCurrentQ() {
  try { return new URL(location.href).searchParams.get("q") || ""; } catch { return ""; }
}

function instagramProfileFromUrl(u) {
  try {
    const url = new URL(u);
    const host = url.hostname.replace(/^www\./,'').replace(/^m\./,'');
    if (!host.endsWith("instagram.com")) return "";

    const parts = url.pathname.split("/").filter(Boolean);
    if (!parts.length) return "";

    const first = parts[0].toLowerCase();
    const excluded = new Set(["p","reel","reels","tv","explore","accounts","about","stories","direct","s","popular"]);
    if (excluded.has(first)) return "";
    if (!/^[A-Za-z0-9._]{3,30}$/.test(parts[0])) return "";

    const username = parts[0];
    return `https://www.instagram.com/${username}/`;
  } catch {
    return "";
  }
}


function instagramReelFromUrl(u) {
  try {
    const url = new URL(u);
    const host = url.hostname.replace(/^www\./,'').replace(/^m\./,'');
    if (!host.endsWith("instagram.com")) return "";

    const parts = url.pathname.split("/").filter(Boolean);
    if (!parts.length) return "";

    const first = parts[0].toLowerCase();
    const allowed = new Set(["reel","reels","p","tv"]);
    if (!allowed.has(first)) return "";

    // normaliza: remove utm/igsh etc para diminuir variação
    url.searchParams.delete("igsh");
    url.searchParams.delete("utm_source");
    url.searchParams.delete("utm_medium");
    url.searchParams.delete("utm_campaign");
    return url.toString();
  } catch {
    return "";
  }
}

function resolveGoogleUrl(href) {
  try {
    const u = new URL(href, location.origin);
    if (u.pathname === "/url" && u.searchParams.get("q")) return u.searchParams.get("q");
    if (u.pathname === "/url" && u.searchParams.get("url")) return u.searchParams.get("url");
    return u.toString();
  } catch {
    return "";
  }
}



function uniqueTextParts(parts) {
  const out = [];
  const seen = new Set();
  for (const part of parts || []) {
    const t = String(part || "").trim();
    if (!t || seen.has(t)) continue;
    seen.add(t);
    out.push(t);
  }
  return out;
}

function normalizeCreciSignal(creciRaw="") {
  const raw = String(creciRaw || "").toUpperCase().trim();
  const digits = normalizeCreci6(raw);
  const suffix = (raw.match(/(?:^|\D)([FCJ])\b/i) || [])[1] || "";
  return { digits, suffix: suffix ? suffix.toUpperCase() : "", full: digits ? `${digits}${suffix ? "-" + suffix.toUpperCase() : ""}` : "" };
}

function getAnchorContextText(a) {
  const nodes = [];
  const seen = new Set();
  const push = (el) => {
    if (!el || seen.has(el)) return;
    seen.add(el);
    nodes.push(el);
  };

  push(a);
  push(a.closest('div[data-snc]'));
  push(a.closest('div.yuRUbf'));
  push(a.closest('div.N54PNb'));
  push(a.closest('div.g'));
  push(a.closest('div.MjjYud'));
  push(a.closest('div[data-hveid]'));

  let parent = a.parentElement;
  for (let i = 0; parent && i < 6; i++, parent = parent.parentElement) push(parent);

  const parts = [a.querySelector('h3')?.innerText || '', a.innerText || '', resolveGoogleUrl(a.getAttribute('href') || '') || ''];
  for (const el of nodes) {
    const txt = String(el?.innerText || el?.textContent || '').replace(/\u00A0/g, ' ').replace(/\s{2,}/g, ' ').trim();
    if (txt && txt.length >= 8) parts.push(txt.slice(0, 2800));
  }
  return uniqueTextParts(parts).join('\n').slice(0, 4500);
}

function scoreInstagramCandidate(kind, url, text, creciRaw="") {
  const sig = normalizeCreciSignal(creciRaw);
  const rawText = String(text || '');
  let username = '';
  try { username = new URL(url).pathname.split('/').filter(Boolean)[0]?.toLowerCase() || ''; } catch {}

  const reExact = sig.digits ? new RegExp(`\\bcreci\\b[^\\n]{0,80}\\b${sig.digits}\\b(?:\\s*[-/ ]?\\s*${sig.suffix || '[A-Z]?'}\\b)?`, 'i') : null;
  const reDigitsSuffix = sig.full ? new RegExp(`\\b${sig.digits}\\s*[-/ ]\\s*${sig.suffix}\\b`, 'i') : null;
  const exactCreci = !!(reExact && reExact.test(rawText));
  const exactDigitsSuffix = !!(reDigitsSuffix && reDigitsSuffix.test(rawText));
  const digitsAny = !!(sig.digits && new RegExp(`\\b${sig.digits}\\b`).test(rawText));
  const hasRealEstate = /\b(creci|corretor(?:a)?(?: de im[oó]veis)?|imobili[aá]ria|im[oó]veis|broker|realtor|consultor(?:a)?(?: de im[oó]veis)?)\b/i.test(rawText);
  const hasCommercialContext = /(venda|vende|aluga|loca[cç][aã]o|financiamento|mcmv|lan[cç]amento|alto padrão|administra|capta[cç][aã]o)/i.test(rawText);
  const hasOtherCouncil = /\b(crefito|coffito|crm|crp|coren|oab|crea|cau|cro|crf|crbio)\b/i.test(rawText);
  const userLooksRealEstate = /(imoveis|imóveis|imob|corretor|corretora|broker|realtor|flats)/i.test(username);
  const userLooksNoise = /^(instagram|popular|accounts|explore)$/i.test(username) || /^\d/.test(username);
  const userLooksAnimal = /^(moose|goat|panda|bat|dolphin|unicorn|elk|lion|badger|deer|otter|fox|wolf|bear|gazelle|swan)\./i.test(username);

  let score = kind === 'profile' ? 42 : 12;
  if (exactCreci) score += 180;
  else if (exactDigitsSuffix) score += 160;
  else if (digitsAny) score += 24;

  if (hasRealEstate) score += 55;
  if (hasCommercialContext) score += 16;
  if (userLooksRealEstate) score += 22;

  if (hasOtherCouncil && !exactCreci && !exactDigitsSuffix) score -= 120;
  if (userLooksNoise) score -= 110;
  if (userLooksAnimal && !hasRealEstate && !exactCreci && !exactDigitsSuffix) score -= 85;
  if (!hasRealEstate && !hasCommercialContext && digitsAny && !exactCreci && !exactDigitsSuffix) score -= 24;
  if (!hasRealEstate && !digitsAny) score -= 18;

  return {
    score,
    strong: !!(exactCreci || exactDigitsSuffix),
    hasRealEstate,
    hasCommercialContext,
    hasOtherCouncil,
    digitsAny,
    username
  };
}

function summarizeCandidate(item) {
  if (!item) return '';
  return [
    `score=${item.score || 0}`,
    item.strong ? 'strong' : '',
    item.hasRealEstate ? 're' : '',
    item.hasCommercialContext ? 'ctx' : '',
    item.hasOtherCouncil ? 'other_council' : '',
    item.url || ''
  ].filter(Boolean).join(' | ');
}

function pickBestInstagramLink(creciRaw="") {
  const anchors = Array.from(document.querySelectorAll('a[href]'));
  const organic = anchors.filter(a => a.querySelector('h3'));
  const pool = organic.length ? organic : anchors;

  const profiles = [];
  const reels = [];

  for (const a of pool) {
    const href = a.getAttribute('href') || '';
    if (!href) continue;
    if (!href.startsWith('/url?') && !href.includes('instagram.com')) continue;

    const resolved = resolveGoogleUrl(href);
    if (!resolved) continue;

    const contextText = getAnchorContextText(a);
    const prof = instagramProfileFromUrl(resolved);
    if (prof) {
      profiles.push({ url: prof, text: contextText, ...scoreInstagramCandidate('profile', prof, contextText, creciRaw) });
      continue;
    }

    const reel = instagramReelFromUrl(resolved);
    if (reel) {
      reels.push({ url: reel, text: contextText, ...scoreInstagramCandidate('reel', reel, contextText, creciRaw) });
    }
  }

  if (!profiles.length && !reels.length) {
    const html = document.documentElement.innerHTML || '';
    let m = html.match(/https?:\/\/(?:www\.)?instagram\.com\/([A-Za-z0-9_.]{3,30})\/?/i);
    if (m && m[1]) {
      const url = `https://www.instagram.com/${m[1]}/`;
      const sample = html.slice(Math.max(0, m.index - 900), Math.min(html.length, m.index + 1800));
      profiles.push({ url, text: sample, ...scoreInstagramCandidate('profile', url, sample, creciRaw) });
    }

    m = html.match(/https?:\/\/(?:www\.)?instagram\.com\/(reel|reels|p|tv)\/[A-Za-z0-9_-]+\/?[^\s"'<>]*/i);
    if (m && m[0]) {
      const sample = html.slice(Math.max(0, m.index - 900), Math.min(html.length, m.index + 1800));
      reels.push({ url: m[0], text: sample, ...scoreInstagramCandidate('reel', m[0], sample, creciRaw) });
    }
  }

  const uniq = (arr) => {
    const out = [];
    const seen = new Set();
    for (const item of arr) {
      if (!item?.url || seen.has(item.url)) continue;
      seen.add(item.url);
      out.push(item);
    }
    return out;
  };

  const P = uniq(profiles).sort((a, b) => b.score - a.score);
  const R = uniq(reels).sort((a, b) => b.score - a.score);

  const topProfilesDebug = P.slice(0, 5).map(summarizeCandidate).join(' || ');
  const topReelsDebug = R.slice(0, 3).map(summarizeCandidate).join(' || ');

  if (P.length) {
    const best = P[0];
    const onlyProfile = P.length === 1;
    const acceptable =
      best.strong ||
      (best.digitsAny && best.hasRealEstate && best.score >= 95) ||
      (onlyProfile && best.digitsAny && best.score >= 82) ||
      (best.strong && best.score >= 120);
    if (acceptable) {
      return {
        kind:'profile',
        url: best.url,
        score: best.score,
        sample: shortDbg(best.text, 260),
        debugTop: topProfilesDebug,
        debugReels: topReelsDebug,
        bestProfileScore: best.score,
        bestProfileDigitsAny: !!best.digitsAny,
        bestProfileStrong: !!best.strong
      };
    }
  }

  if (R.length) {
    const best = R[0];
    return {
      kind:'reel',
      url: best.url,
      score: best.score,
      sample: shortDbg(best.text, 260),
      debugTop: topProfilesDebug,
      debugReels: topReelsDebug,
      bestProfileScore: P[0]?.score || 0,
      bestProfileDigitsAny: !!P[0]?.digitsAny,
      bestProfileStrong: !!P[0]?.strong
    };
  }

  return { kind:'', url:'', score:0, sample:'', debugTop: topProfilesDebug, debugReels: topReelsDebug, bestProfileScore: P[0]?.score || 0, bestProfileDigitsAny: !!P[0]?.digitsAny, bestProfileStrong: !!P[0]?.strong };
}
function getSearchMode() {
  try {
    const u = new URL(location.href);
    const q = (u.searchParams.get("q") || "").trim();
    if (/^"CRECI\s+\d+"\s+instagram\s+site:instagram\.com$/i.test(q)) return "exact";
    if (/^\d+\s+corretor\s+imoveis\s+instagram\s+site:instagram\.com$/i.test(q)) return "broker";
    if (/^\d+\s+instagram\s+site:instagram\.com$/i.test(q)) return "number";
    return "broad";
  } catch {
    return "broad";
  }
}

async function waitAndPickInstagramLink(timeoutMs=3200, creciRaw="") {
  const started = Date.now();
  let lastPick = { kind:"", url:"", score:0, sample:"" };
  while (Date.now() - started < timeoutMs) {
    lastPick = pickBestInstagramLink(creciRaw);
    if (lastPick.url) return lastPick;
    await sleep(250);
  }
  return lastPick;
}
async function getRowStateFromGas(row, st) {
  return await gasCallRetry(() => gasGet(st.endpoint, {
    action:"getRowState",
    row,
    spreadsheetId: st.spreadsheetId || "",
    tab: st.tab || "",
    rowStart: st.rowStart || 2,
    rowEnd: st.rowEnd || 0,
    creciColumn: st.creciColumn || ""
  }));
}

async function ensurePending() {
  const st = await getState();

  if (st.pending?.row) {
    try {
      const rowState = await getRowStateFromGas(st.pending.row, st);
      await debugLog("pending_row_state", shortDbg(JSON.stringify(rowState)));

      if (rowState?.ok && rowState.canInteract) {
        const rawLive = String(rowState.creciRaw ?? st.pending.creciRaw ?? "").trim();
        const pendingLive = { row: st.pending.row, creciRaw: rawLive, searchLink: st.pending.searchLink || '', fallbackTried: !!st.pending.fallbackTried };
        if (rawLive !== String(st.pending.creciRaw || "").trim()) {
          await setState({ pending: pendingLive });
        }
        return pendingLive;
      }

      await debugLog("pending_discarded", `row=${st.pending.row} | status=${rowState?.status || ""}`, { level:"warn" });
      await setState({ pending:null });
    } catch (e) {
      await debugLog("pending_validate_error", e?.message || String(e), { level:"warn" });
      await setState({ pending:null });
    }
  }

  overlay("Buscando próximo CRECI pendente…");
  await debugLog("ensure_pending_start", "consultando GAS");
  const data = await gasCallRetry(() => gasGet(st.endpoint, {
    action:"getNextIg",
    spreadsheetId: st.spreadsheetId || "",
    tab: st.tab || "",
    rowStart: st.rowStart || 2,
    rowEnd: st.rowEnd || 0,
    creciColumn: st.creciColumn || ""
  }));
  await debugLog("ensure_pending_end", shortDbg(JSON.stringify(data)));

  if (!data.ok) throw new Error(data.error || "getNextIg falhou");

  if (!data.next) {
    overlay("Concluído ✅ Não há mais linhas pendentes para IG.");
    await debugLog("queue_done", "sem linhas pendentes");
    await setState({ running:false, pending:null });
    return null;
  }

  const raw = String(data.next.creciRaw ?? data.next.creci ?? "").trim();
  const pending = { row: data.next.row, creciRaw: raw, searchLink: String(data.next.searchLink || '').trim(), fallbackTried: false };
  await debugLog("pending_set", `row=${data.next.row} | creci=${raw} | search=${String(data.next.searchLink || '').trim()}`);
  await setState({ pending });
  return pending;
}

async function saveStatus(status, detail="") {
  const st = await getState();
  if (!st.pending) return;
  try {
    await debugLog("save_status", `${status} | ${detail}`);
    await gasCallRetry(() => gasPost(st.endpoint, {
      action:"saveStatus",
      row: st.pending.row,
      status,
      detail,
      sourceCreciRaw: st.pending.creciRaw || "",
      spreadsheetId: st.spreadsheetId || "",
      tab: st.tab || "",
      rowStart: st.rowStart || 2,
      rowEnd: st.rowEnd || 0,
      creciColumn: st.creciColumn || ""
    }));
  } catch {}
}


async function saveIgData(payload) {
  const st = await getState();
  if (!st.pending) throw new Error("no_pending");
  const body = {
    action: "saveigdata",
    row: st.pending.row,
    sourceCreciRaw: st.pending.creciRaw || "",
    igUrl: payload.igUrl || "",
    igName: payload.igName || "",
    phone: payload.phone || "",
    followers: payload.followers || "",
    following: payload.following || "",
    posts: payload.posts || "",
    status: payload.status || "OK",
    detail: payload.detail || "",
    spreadsheetId: st.spreadsheetId || "",
    tab: st.tab || "",
    rowStart: st.rowStart || 2,
    rowEnd: st.rowEnd || 0,
    creciColumn: st.creciColumn || ""
  };
  await debugLog("save_igdata", shortDbg(JSON.stringify(body)));
  return await gasCallRetry(() => gasPost(st.endpoint, body));
}


async function main() {
  if (window.__creci_google_ran) return;
  window.__creci_google_ran = true;

  const st = await getState();
  if (!st.running || !st.endpoint) return;
  if (!isRunnableGooglePage()) {
    await debugLog("google_skip_page", `href=${location.href}`, { level:"warn" });
    return;
  }

  const claim = await claimWorker("google");
  if (!claim?.ok) {
    await debugLog("google_not_owner", `${claim?.reason || "worker_busy"} | ownerTab=${claim?.owner?.tabId ?? ""}`, { level:"warn" });
    return;
  }

  await touchWorker("google");
  await debugLog("google_main_start", `href=${location.href} | ownerTab=${claim?.owner?.tabId ?? ""}`);

  if (st.pauseUntil && Date.now() < st.pauseUntil) {
    const secs = Math.ceil((st.pauseUntil - Date.now()) / 1000);
    overlay(`Pausado por instabilidade do GAS. Retomando em ${secs}s…`);
    await debugLog("paused", `retoma em ${secs}s`, { level:"warn" });
    setTimeout(() => location.reload(), Math.min(30000, (st.pauseUntil - Date.now()) + 500));
    return;
  }

  if (location.hostname.includes("consent.google.") || /sorry\/index/i.test(location.pathname)) {
    overlay(`Google pediu consentimento/verificação.
Conclua manualmente essa tela e volte.
Depois a automação continua.`);
    await debugLog("google_blocked", "consentimento/verificação", { level:"warn" });
    return;
  }

  const delays = getDelaySettings(st);

  let pending;
  try {
    pending = await ensurePending();
  } catch (e) {
    await debugLog("ensure_pending_error", e?.message || String(e), { level:"error" });
    await setState({ pauseUntil: Date.now() + 60000 });
    overlay(`ERRO GAS: ${e?.message || e}
Pausando 60s…`);
    setTimeout(() => location.reload(), 60000);
    return;
  }

  if (!pending) return;

  await touchWorker("google");

  const currentQ = getCurrentQ();
  const primaryQ = buildQuery(pending.creciRaw);
  const fallbackQ = buildFallbackQuery(pending.creciRaw, pending.searchLink || '');
  const onPrimary = currentQ === primaryQ;
  const onFallback = !!fallbackQ && currentQ === fallbackQ;

  await debugLog("google_query_state", `current=${currentQ} | primary=${primaryQ} | fallback=${fallbackQ || '(none)'} | triedFallback=${pending.fallbackTried ? 'SIM' : 'NAO'}`);
  if (!onPrimary && !onFallback) {
    overlay(`Linha ${pending.row} | ${pending.creciRaw}
Abrindo busca no Google:
${primaryQ}`);
    await debugLog("google_redirect_search", `${primaryQ} | delay=${delays.delaySearchMs}ms`);
    await sleep(delays.delaySearchMs);
    location.href = buildSearchUrl(pending.creciRaw);
    return;
  }

  await touchWorker("google");

  const pick = await waitAndPickInstagramLink(onFallback ? 4200 : 3200, pending.creciRaw);
  await debugLog("google_candidates", `profiles=${pick.debugTop || '(none)'} | reels=${pick.debugReels || '(none)'}`);

  const igUrl = pick.url;
  const igKind = pick.kind;

  if (!igUrl) {
    const as = Array.from(document.querySelectorAll("a[href]"));
    const sample = as.slice(0, 10).map(a => a.getAttribute("href")).filter(Boolean).join("\n");
    const canFallback = onPrimary && !pending.fallbackTried && !!fallbackQ;
    if (canFallback) {
      overlay(`Sem perfil na busca por CRECI.
Vou tentar uma segunda busca com o nome:
${pending.searchLink}`);
      await debugLog("google_no_profile_retry_name", `anchors=${as.length} | nome=${pending.searchLink || ''} | sample=${shortDbg(sample, 300)}`, { level:"warn" });
      await setState({ pending: { ...pending, fallbackTried: true } });
      await sleep(delays.delaySearchMs);
      location.href = buildFallbackSearchUrl(pending.creciRaw, pending.searchLink || '');
      return;
    }

    overlay(`Sem resultado de PERFIL no Instagram.
links(a)=${as.length}
AMOSTRA:
${sample}
Marcando SEM_RESULTADO.`);
    await debugLog("google_no_profile", `anchors=${as.length} | fallback=${onFallback ? 'SIM' : 'NAO'} | sample=${shortDbg(sample, 500)}`, { level:"warn" });
    await saveStatus("SEM_RESULTADO", onFallback ? "google_no_profile_name_fallback" : "google_no_profile_single");
    await setState({ pending: null });
    await sleep(delays.delayNextRowMs);
    location.href = BASE_GOOGLE;
    return;
  }

  if (igKind === "reel") {
    const canFallback = onPrimary && !pending.fallbackTried && !!fallbackQ;
    if (canFallback) {
      overlay(`A busca por CRECI trouxe só reels/posts.
Vou tentar uma segunda busca com o nome:
${pending.searchLink}`);
      await debugLog("google_reel_retry_name", `${igUrl} | nome=${pending.searchLink || ''}`, { level:"warn" });
      await setState({ pending: { ...pending, fallbackTried: true } });
      await sleep(delays.delaySearchMs);
      location.href = buildFallbackSearchUrl(pending.creciRaw, pending.searchLink || '');
      return;
    }
    overlay(`Somente REELS/POST apareceu na busca.
Não vou salvar reels para evitar falso positivo.
Marcando SEM_RESULTADO.`);
    await debugLog("google_reel_only", `${igUrl} | fallback=${onFallback ? 'SIM' : 'NAO'} | profiles=${pick.debugTop || '(none)'}`, { level:"warn" });
    await saveStatus("SEM_RESULTADO", onFallback ? "google_reels_irrelevantes_fallback" : "google_reels_irrelevantes");
    await setState({ pending: null });
    await sleep(delays.delayNextRowMs);
    location.href = BASE_GOOGLE;
    return;
  }

  await debugLog("google_found_instagram", `${igKind} | score=${pick.score || 0} | ${igUrl} | ${pick.sample || ""} | top=${pick.debugTop || '(none)'}`);
  overlay(`Instagram encontrado:
${igUrl}
Abrindo em ${delays.delayOpenProfileMs}ms…`);
  await sleep(delays.delayOpenProfileMs);
  location.href = igUrl;
}

document.addEventListener("DOMContentLoaded", () => setTimeout(main, 250));
window.addEventListener("load", () => setTimeout(main, 550));