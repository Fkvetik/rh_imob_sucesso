/**
 * RH IMOB — Web App para extensão CRECI -> Instagram (Google)
 *
 * Fluxo preservado:
 *  GET  ?action=ping
 *  GET  ?action=getNextIg&spreadsheetId=...&tab=...&rowStart=...&rowEnd=...&creciColumn=...
 *  GET  ?action=getRowState&row=...&spreadsheetId=...&tab=...&rowStart=...&rowEnd=...&creciColumn=...
 *
 *  POST { action:"savestatus", row, status, detail, spreadsheetId?, tab?, rowStart?, rowEnd?, creciColumn? }
 *  POST { action:"saveigdata", row, ...camposInstagram..., spreadsheetId?, tab?, rowStart?, rowEnd?, creciColumn? }
 */

const SPREADSHEET_ID = '';
const DEFAULT_SHEET_NAME = 'SEM TEL ORG';
const HEADER_ROW = 1;
const START_ROW = 2;
const TZ = 'America/Sao_Paulo';

const LEGACY_HEADERS = ['CRECI', 'Busca', 'Instagram URL', 'Nome', 'Telefone', 'Seguidores', 'Seguindo', 'Postagens', 'STATUS'];
const RHI_IG_HEADERS = [
  'RHI_IG_STATUS',
  'RHI_IG_DETAIL',
  'RHI_IG_INSTAGRAM_URL',
  'RHI_IG_USERNAME',
  'RHI_IG_NOME_PERFIL',
  'RHI_IG_BIO',
  'RHI_IG_CARGO',
  'RHI_IG_CARGO_RAW',
  'RHI_IG_CARGO_ORIGEM',
  'RHI_IG_CARGO_CONFIANCA',
  'RHI_IG_ACHOU_EX',
  'RHI_IG_FLAG_EMPRESA',
  'RHI_IG_FLAG_RUIDO',
  'RHI_IG_CARGO_OBS',
  'RHI_IG_CATEGORIA_PERFIL',
  'RHI_IG_TELEFONE_WA',
  'RHI_IG_TELEFONE_TXT',
  'RHI_IG_CRECI_TEXTO',
  'RHI_IG_CRECI_NUMERO',
  'RHI_IG_CEP_TEXTO',
  'RHI_IG_SEGUIDORES',
  'RHI_IG_SEGUINDO',
  'RHI_IG_POSTAGENS',
  'RHI_IG_ATUALIZADO_EM'
];

function nowIsoLocal_() {
  return Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function doGet(e) {
  try {
    const p = (e && e.parameter) ? e.parameter : {};
    const action = String(p.action || 'ping').trim().toLowerCase();

    if (action === 'ping') {
      return output_({ ok: true, msg: 'online', ts: nowIsoLocal_() });
    }

    if (action === 'getnextig') {
      return output_(getNextIg_(p));
    }

    if (action === 'getrowstate') {
      return output_(getRowState_(p));
    }

    return output_({ ok: false, error: 'action inválida' });
  } catch (err) {
    return output_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function doPost(e) {
  try {
    const raw = (e && e.postData && e.postData.contents) ? e.postData.contents : '';
    const data = raw ? JSON.parse(raw) : {};
    const action = String(data.action || '').trim().toLowerCase();

    if (action === 'ping' || data.ping === true) {
      return output_({ ok: true, msg: 'pong', ts: nowIsoLocal_() });
    }

    if (action === 'savestatus' || action === 'savestatusonly' || action === 'savestatus_' || action === 'savestatus') {
      return output_(saveStatus_(data));
    }

    if (action === 'saveigdata') {
      return output_(saveIgData_(data));
    }

    return output_({ ok: false, error: 'action inválida no POST' });
  } catch (err) {
    return output_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function getNextIg_(params) {
  const sh = getSheet_(params.spreadsheetId || params.SpreadsheetId, params.tab || params.Tab);
  const ctx = ensureSheetContext_(sh, params);

  if (ctx.rowEnd < ctx.rowStart) return { ok: true, next: null, meta: packMeta_(ctx) };

  const totalRows = ctx.rowEnd - ctx.rowStart + 1;
  const creciValues = sh.getRange(ctx.rowStart, ctx.creciColumn, totalRows, 1).getDisplayValues();
  const statusValues = ctx.statusColumn ? sh.getRange(ctx.rowStart, ctx.statusColumn, totalRows, 1).getDisplayValues() : null;
  const legacyStatusValues = ctx.legacyStatusColumn ? sh.getRange(ctx.rowStart, ctx.legacyStatusColumn, totalRows, 1).getDisplayValues() : null;
  const buscaValues = ctx.buscaColumn ? sh.getRange(ctx.rowStart, ctx.buscaColumn, totalRows, 1).getDisplayValues() : null;
  const nomeValues = ctx.nomeColumn ? sh.getRange(ctx.rowStart, ctx.nomeColumn, totalRows, 1).getDisplayValues() : null;

  for (var i = 0; i < totalRows; i++) {
    const row = ctx.rowStart + i;
    const creciRaw = String(creciValues[i][0] || '').trim();
    const status = firstNonEmpty_([
      statusValues ? statusValues[i][0] : '',
      legacyStatusValues ? legacyStatusValues[i][0] : ''
    ]);

    if (!creciRaw) continue;
    if (status) continue;

    const searchLink = firstNonEmpty_([
      buscaValues ? buscaValues[i][0] : '',
      nomeValues ? nomeValues[i][0] : ''
    ]);

    return {
      ok: true,
      next: {
        row: row,
        creciRaw: creciRaw,
        creci: creciRaw,
        searchLink: searchLink
      },
      meta: packMeta_(ctx)
    };
  }

  return { ok: true, next: null, meta: packMeta_(ctx) };
}

function getRowState_(params) {
  const row = Number(params.row || params.Row || 0);
  if (row < START_ROW) return { ok: false, error: 'row inválida' };

  const sh = getSheet_(params.spreadsheetId || params.SpreadsheetId, params.tab || params.Tab);
  const ctx = ensureSheetContext_(sh, params);

  const safeRow = Math.min(Math.max(row, ctx.rowStart), ctx.rowEnd || row);
  const creciRaw = String(sh.getRange(safeRow, ctx.creciColumn).getDisplayValue() || '').trim();
  const status = firstNonEmpty_([
    ctx.statusColumn ? sh.getRange(safeRow, ctx.statusColumn).getDisplayValue() : '',
    ctx.legacyStatusColumn ? sh.getRange(safeRow, ctx.legacyStatusColumn).getDisplayValue() : ''
  ]);

  return {
    ok: true,
    row: safeRow,
    creciRaw: creciRaw,
    status: status,
    canInteract: !!creciRaw && !status,
    meta: packMeta_(ctx)
  };
}

function saveStatus_(data) {
  const sh = getSheet_(data.spreadsheetId || data.SpreadsheetId, data.tab || data.Tab);
  const ctx = ensureSheetContext_(sh, data);

  const rowInput = Number(data.row || data.Row || 0);
  const targetRow = resolveTargetRow_(sh, ctx, rowInput, firstNonEmpty_([
    data.sourceCreciRaw, data.SourceCreciRaw, data.creciRaw, data.CRECI, data.CreciTexto
  ]));

  if (!(targetRow >= ctx.rowStart && targetRow <= ctx.rowEnd)) return { ok: false, error: 'row inválida ou divergência de linha' };

  const status = String(data.status || data.Status || '').trim();
  const detail = String(data.detail || data.Detail || '').trim();
  const nowIso = nowIsoLocal_();
  const map = ctx.headerMap;

  writeByHeader_(sh, targetRow, map, 'RHI_IG_STATUS', status, true);
  writeByHeader_(sh, targetRow, map, 'RHI_IG_DETAIL', detail, true);
  writeByHeader_(sh, targetRow, map, 'RHI_IG_ATUALIZADO_EM', nowIso, true);

  return {
    ok: true,
    row: targetRow,
    status: status,
    detail: detail,
    meta: packMeta_(ctx)
  };
}

function saveIgData_(data) {
  const sh = getSheet_(data.spreadsheetId || data.SpreadsheetId, data.tab || data.Tab);
  const ctx = ensureSheetContext_(sh, data);

  const rowInput = Number(data.row || data.Row || 0);
  const targetRow = resolveTargetRow_(sh, ctx, rowInput, firstNonEmpty_([
    data.sourceCreciRaw, data.SourceCreciRaw, data.creciRaw, data.CRECI, data.CreciTexto
  ]));

  if (!(targetRow >= ctx.rowStart && targetRow <= ctx.rowEnd)) return { ok: false, error: 'row inválida ou divergência de linha' };

  const map = ctx.headerMap;
  const nowIso = nowIsoLocal_();

  const igUrl = firstNonEmpty_([data.RHI_IG_INSTAGRAM_URL, data.igUrl, data.InstagramUrl, data['Instagram URL'], data.PerfilURL]);
  const username = firstNonEmpty_([data.RHI_IG_USERNAME, data.Username, data.username]);
  const igName = firstNonEmpty_([data.RHI_IG_NOME_PERFIL, data.igName, data.NomePerfil, data.Nome, username]);
  const bio = firstNonEmpty_([data.RHI_IG_BIO, data.BIO, data.Bio, data.biography]);
  const cargo = firstNonEmpty_([data.RHI_IG_CARGO, data.Cargo, data.CARGO, data.cargo]);
  const cargoRaw = firstNonEmpty_([data.RHI_IG_CARGO_RAW, data.CargoRaw, data.CARGO_RAW, data.cargoRaw]);
  const cargoOrigem = firstNonEmpty_([data.RHI_IG_CARGO_ORIGEM, data.CargoOrigem, data.CARGO_ORIGEM, data.cargoOrigem]);
  const cargoConfianca = firstNonEmpty_([data.RHI_IG_CARGO_CONFIANCA, data.CargoConfianca, data.CARGO_CONFIANCA, data.cargoConfianca]);
  const achouEx = firstNonEmpty_([data.RHI_IG_ACHOU_EX, data.AchouEx, data.achouEx]);
  const flagEmpresa = firstNonEmpty_([data.RHI_IG_FLAG_EMPRESA, data.FlagEmpresa, data.flagEmpresa]);
  const flagRuido = firstNonEmpty_([data.RHI_IG_FLAG_RUIDO, data.FlagRuido, data.flagRuido]);
  const cargoObs = firstNonEmpty_([data.RHI_IG_CARGO_OBS, data.CargoObs, data.cargoObs]);
  const categoria = firstNonEmpty_([data.RHI_IG_CATEGORIA_PERFIL, data.CategoriaPerfil, data.category, data.Categoria]);
  const telefoneWa = firstNonEmpty_([data.RHI_IG_TELEFONE_WA, data.TelefoneWA, data.phoneWa, data.LinkExterno]);
  const telefoneTxt = firstNonEmpty_([normalizePhoneOnly_([data.RHI_IG_TELEFONE_TXT, data.phone, data.Telefone, data.TelefoneTXT, data.TelefoneTxtLinha]), data.RHI_IG_TELEFONE_TXT, data.TelefoneTXT, data.TelefoneTxtLinha]);
  const creciTexto = firstNonEmpty_([data.RHI_IG_CRECI_TEXTO, data.CRECI, data.CreciTexto, data.creciRaw, data.sourceCreciRaw]);
  const creciNumero = firstNonEmpty_([onlyDigits_(data.RHI_IG_CRECI_NUMERO), onlyDigits_(data.CRECI_NUMERO), onlyDigits_(data.CreciNumero), extractCreciDigits_(creciTexto)]);
  const cepTexto = firstNonEmpty_([normalizeCep_(data.RHI_IG_CEP_TEXTO), normalizeCep_(data.CEP_TEXTO), normalizeCep_(data.CepTexto)]);
  const seguidores = firstNonEmpty_([data.RHI_IG_SEGUIDORES, data.followers, data.Seguidores]);
  const seguindo = firstNonEmpty_([data.RHI_IG_SEGUINDO, data.following, data.Seguindo]);
  const postagens = firstNonEmpty_([data.RHI_IG_POSTAGENS, data.posts, data.Postagens]);
  const status = String(data.status || data.Status || (telefoneTxt ? 'OK' : 'OK_SEM_TEL')).trim();
  const detail = String(data.detail || data.Detail || '').trim();

  const hasCollectionEvidence = !!firstNonEmpty_([igUrl, username, igName, bio, categoria, telefoneWa, telefoneTxt, creciTexto, creciNumero, seguidores, seguindo, postagens, cargo]);
  if (!hasCollectionEvidence && /^OK/.test(status)) {
    return { ok: false, error: 'payload_vazio', row: targetRow, meta: packMeta_(ctx) };
  }

  const rhiPayload = {
    'RHI_IG_STATUS': status,
    'RHI_IG_DETAIL': detail,
    'RHI_IG_INSTAGRAM_URL': igUrl,
    'RHI_IG_USERNAME': username,
    'RHI_IG_NOME_PERFIL': igName,
    'RHI_IG_BIO': bio,
    'RHI_IG_CARGO': cargo,
    'RHI_IG_CARGO_RAW': cargoRaw,
    'RHI_IG_CARGO_ORIGEM': cargoOrigem,
    'RHI_IG_CARGO_CONFIANCA': cargoConfianca,
    'RHI_IG_ACHOU_EX': achouEx,
    'RHI_IG_FLAG_EMPRESA': flagEmpresa,
    'RHI_IG_FLAG_RUIDO': flagRuido,
    'RHI_IG_CARGO_OBS': cargoObs,
    'RHI_IG_CATEGORIA_PERFIL': categoria,
    'RHI_IG_TELEFONE_WA': telefoneWa,
    'RHI_IG_TELEFONE_TXT': telefoneTxt,
    'RHI_IG_CRECI_TEXTO': creciTexto,
    'RHI_IG_CRECI_NUMERO': creciNumero,
    'RHI_IG_CEP_TEXTO': cepTexto,
    'RHI_IG_SEGUIDORES': seguidores,
    'RHI_IG_SEGUINDO': seguindo,
    'RHI_IG_POSTAGENS': postagens,
    'RHI_IG_ATUALIZADO_EM': nowIso
  };

  Object.keys(rhiPayload).forEach(function(header) {
    const force = header === 'RHI_IG_STATUS' || header === 'RHI_IG_DETAIL' || header === 'RHI_IG_ATUALIZADO_EM';
    writeByHeader_(sh, targetRow, map, header, rhiPayload[header], force);
  });

  // Regra conservadora: não escrever em colunas antigas já existentes e não sobrescrever conteúdo anterior.
  // A partir desta versão, a coleta grava apenas nas colunas RHI_IG_* anexadas ao final do cabeçalho.

  return {
    ok: true,
    row: targetRow,
    igUrl: igUrl,
    igName: igName,
    phone: telefoneTxt,
    status: status,
    cargo: cargo,
    meta: packMeta_(ctx)
  };
}

function getSheet_(spreadsheetId, tabName) {
  const ss = openSpreadsheet_(spreadsheetId);
  const name = String(tabName || DEFAULT_SHEET_NAME).trim() || DEFAULT_SHEET_NAME;
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  return sh;
}

function openSpreadsheet_(spreadsheetId) {
  const dynamicId = String(spreadsheetId || '').trim();
  if (dynamicId) return SpreadsheetApp.openById(dynamicId);
  if (String(SPREADSHEET_ID || '').trim()) return SpreadsheetApp.openById(String(SPREADSHEET_ID).trim());

  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) throw new Error('Defina SPREADSHEET_ID ou use este script vinculado à planilha.');
  return active;
}

function ensureSheetContext_(sh, params) {
  const lastRow = Math.max(sh.getLastRow(), START_ROW - 1);
  const lastCol = Math.max(sh.getLastColumn(), 1);

  if (lastRow < HEADER_ROW && lastCol < 1) {
    sh.getRange(HEADER_ROW, 1).setValue('CRECI');
  }

  const headerValues = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  if (headerValues.every(function(v) { return !String(v || '').trim(); })) {
    sh.getRange(HEADER_ROW, 1).setValue('CRECI');
  }

  const refreshedHeaders = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  const headerMap = buildHeaderMap_(refreshedHeaders);

  const creciColumn = resolveCreciColumn_(refreshedHeaders, params);
  const rowStart = Math.max(START_ROW, Number(params.rowStart || params.RowStart || START_ROW) || START_ROW);
  const rowEndRequested = Number(params.rowEnd || params.RowEnd || 0) || 0;
  const rowEnd = rowEndRequested > 0 ? Math.min(Math.max(rowEndRequested, rowStart), Math.max(sh.getLastRow(), rowStart)) : Math.max(sh.getLastRow(), rowStart);

  const buscaColumn = headerMap['BUSCA'] || headerMap['BUSCAQUERY'] || 0;
  const nomeColumn = headerMap['NOME'] || headerMap['NOMEPERFIL'] || 0;

  ensureOperationHeaders_(sh, refreshedHeaders);
  const headerValuesFinal = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  const finalHeaderMap = buildHeaderMap_(headerValuesFinal);
  const statusColumn = finalHeaderMap['RHIIGSTATUS'] || 0;
  const legacyStatusColumn = finalHeaderMap['STATUS'] || headerMap['STATUS'] || 0;

  return {
    headerRow: HEADER_ROW,
    rowStart: rowStart,
    rowEnd: rowEnd,
    creciColumn: creciColumn,
    statusColumn: statusColumn,
    legacyStatusColumn: legacyStatusColumn,
    buscaColumn: buscaColumn,
    nomeColumn: nomeColumn,
    headerMap: finalHeaderMap,
    lastHeaderColumn: getLastNonEmptyHeaderColumn_(headerValuesFinal),
    legacyMode: isLegacyLayout_(headerValuesFinal)
  };
}

function ensureOperationHeaders_(sh, headerValues) {
  const headers = headerValues && headerValues.length ? headerValues.slice() : sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  const usedMap = buildHeaderMap_(headers);
  const append = [];

  for (var i = 0; i < RHI_IG_HEADERS.length; i++) {
    const normalized = normalizeHeaderKey_(RHI_IG_HEADERS[i]);
    if (!usedMap[normalized]) append.push(RHI_IG_HEADERS[i]);
  }

  if (append.length) {
    const startCol = getLastNonEmptyHeaderColumn_(headers) + 1;
    sh.getRange(HEADER_ROW, startCol, 1, append.length).setValues([append]);
  }

  return append;
}

function resolveCreciColumn_(headerValues, params) {
  const manual = parseColumnInput_(params.creciColumn || params.CreciColumn || params.creci_col || params.creciCol);
  if (manual > 0) return manual;

  const headers = headerValues || [];
  for (var i = 0; i < headers.length; i++) {
    const raw = String(headers[i] || '').trim();
    if (!raw) continue;
    if (isCreciHeader_(raw)) return i + 1;
  }

  if (headers.length && String(headers[0] || '').trim() === '') {
    return 1;
  }

  return 1;
}

function isCreciHeader_(value) {
  const raw = String(value || '').trim();
  if (!raw) return false;
  const normalized = normalizeHeaderKey_(raw);
  if (normalized === 'CRECI') return true;
  return /\bCRECI\b/i.test(raw.replace(/\s+/g, ' ').trim());
}

function isLegacyLayout_(headers) {
  if (!headers || headers.length < LEGACY_HEADERS.length) return false;
  for (var i = 0; i < LEGACY_HEADERS.length; i++) {
    const current = String(headers[i] || '').trim();
    if (current && current !== LEGACY_HEADERS[i]) return false;
  }
  return true;
}

function buildHeaderMap_(headers) {
  const map = {};
  for (var i = 0; i < headers.length; i++) {
    const raw = String(headers[i] || '').trim();
    if (!raw) continue;
    const normalized = normalizeHeaderKey_(raw);
    if (normalized && map[normalized] == null) map[normalized] = i + 1;
  }
  return map;
}

function getLastNonEmptyHeaderColumn_(headers) {
  for (var i = (headers || []).length - 1; i >= 0; i--) {
    if (String(headers[i] || '').trim()) return i + 1;
  }
  return 1;
}

function resolveTargetRow_(sh, ctx, rowInput, sourceCreciRaw) {
  if (!(rowInput >= ctx.rowStart && rowInput <= ctx.rowEnd)) {
    return 0;
  }

  if (!ctx.creciColumn) {
    return rowInput;
  }

  const rowCreci = String(sh.getRange(rowInput, ctx.creciColumn).getDisplayValue() || '').trim();
  if (!sourceCreciRaw) {
    return rowInput;
  }

  const normalizedRow = normalizeCreciLookup_(rowCreci);
  const normalizedSource = normalizeCreciLookup_(sourceCreciRaw);

  if (!normalizedSource) {
    return rowInput;
  }

  if (!normalizedRow || normalizedRow === normalizedSource) {
    return rowInput;
  }

  return 0;
}

function parseColumnInput_(value) {
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return 0;
  if (/^\d+$/.test(raw)) return Number(raw) || 0;
  if (!/^[A-Z]+$/.test(raw)) return 0;

  var out = 0;
  for (var i = 0; i < raw.length; i++) {
    out = out * 26 + (raw.charCodeAt(i) - 64);
  }
  return out;
}

function normalizeHeaderKey_(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[\s:._-]+/g, '')
    .toUpperCase()
    .trim();
}

function normalizeCreciLookup_(value) {
  const raw = String(value || '').toUpperCase();
  const digits = onlyDigits_(raw);
  if (!digits) return '';
  const suffixMatch = raw.match(/\b([FCJ])\b/);
  const suffix = suffixMatch ? suffixMatch[1] : '';
  return digits + (suffix ? '-' + suffix : '');
}

function extractCreciDigits_(value) {
  const digits = onlyDigits_(value);
  return digits ? digits : '';
}

function onlyDigits_(value) {
  const match = String(value || '').match(/\d+/g);
  return match ? match.join('') : '';
}

function normalizeCep_(value) {
  const m = String(value || '').match(/\b\d{5}-?\d{3}\b/);
  return m ? m[0] : '';
}

function normalizePhoneOnly_(values) {
  const joined = Array.isArray(values) ? values.map(function(v) { return String(v == null ? '' : v); }).join(' | ') : String(values == null ? '' : values);
  const digits = joined.match(/\d+/g);
  if (!digits) return '';
  var s = digits.join('');
  if (s.indexOf('55') === 0 && s.length >= 12) s = s.slice(2);
  if (s.length < 10) return '';
  if (s.length > 11) s = s.slice(-11);
  if (s.length === 10) return '(' + s.slice(0, 2) + ') ' + s.slice(2, 6) + '-' + s.slice(6);
  return '(' + s.slice(0, 2) + ') ' + s.slice(2, 7) + '-' + s.slice(7);
}

function firstNonEmpty_(values) {
  for (var i = 0; i < (values || []).length; i++) {
    const s = String(values[i] == null ? '' : values[i]).trim();
    if (s) return s;
  }
  return '';
}

function writeCellIfColumn_(sh, row, col, value) {
  if (!col || col < 1) return;
  writeCell_(sh, row, col, value, false);
}

function setByHeader_(sh, row, map, header, value) {
  const col = map[normalizeHeaderKey_(header)];
  if (!col) return;
  writeCell_(sh, row, col, value, false);
}

function setByHeaderSafe_(sh, row, map, header, value) {
  const col = map[normalizeHeaderKey_(header)];
  if (!col) return;
  writeCell_(sh, row, col, value, false);
}

function writeByHeader_(sh, row, map, header, value, force) {
  const col = map[normalizeHeaderKey_(header)];
  if (!col) return;
  writeCell_(sh, row, col, value, !!force);
}

function writeCell_(sh, row, col, value, force) {
  if (!col || col < 1) return;
  const nextValue = value == null ? '' : value;
  const cell = sh.getRange(row, col);
  const currentValue = cell.getDisplayValue();
  if (!String(currentValue || '').trim()) {
    cell.setValue(nextValue);
    return;
  }
  if (String(currentValue) === String(nextValue)) return;
  if (force) {
    cell.setValue(nextValue);
  }
}

function writeLegacyStatusIfPossible_(sh, ctx, row, status) {
  return;
}

function writeLegacyIgIfPossible_(sh, ctx, row, data) {
  return;
}

function packMeta_(ctx) {
  return {
    headerRow: ctx.headerRow,
    rowStart: ctx.rowStart,
    rowEnd: ctx.rowEnd,
    creciColumn: ctx.creciColumn,
    statusColumn: ctx.statusColumn,
    legacyStatusColumn: ctx.legacyStatusColumn,
    buscaColumn: ctx.buscaColumn,
    nomeColumn: ctx.nomeColumn || 0,
    lastHeaderColumn: ctx.lastHeaderColumn,
    legacyMode: ctx.legacyMode
  };
}

function output_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
