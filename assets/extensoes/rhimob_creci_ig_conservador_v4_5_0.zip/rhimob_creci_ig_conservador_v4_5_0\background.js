// MV3 Service Worker - chamadas para GAS via GET/POST + logs ricos
const DEBUG_LOG_KEY = "__rh_creci_debug_logs_v1";
const DEBUG_LOG_MAX = 500;
const LOG_TIMEZONE = "America/Sao_Paulo";

const WORKER_OWNER_KEY = "__rh_creci_worker_owner_v1";
const WORKER_STALE_MS = 2 * 60 * 1000;

async function getWorkerOwner() {
  const out = await getLocal({ [WORKER_OWNER_KEY]: null });
  return out[WORKER_OWNER_KEY] || null;
}
async function setWorkerOwner(owner) {
  await setLocal({ [WORKER_OWNER_KEY]: owner || null });
}
async function ensureTabAlive(tabId) {
  if (tabId == null) return false;
  try {
    await chrome.tabs.get(tabId);
    return true;
  } catch {
    return false;
  }
}
async function tryClaimWorker(sender, role="unknown") {
  const tabId = sender?.tab?.id;
  const now = Date.now();
  if (tabId == null) return { ok:false, reason:"no_sender_tab", owner:null };

  let owner = await getWorkerOwner();
  const alive = owner?.tabId != null ? await ensureTabAlive(owner.tabId) : false;
  const stale = !!owner && ((now - Number(owner.heartbeatAt || 0)) > WORKER_STALE_MS);

  if (!owner || !alive || stale) {
    owner = {
      tabId,
      role: String(role || "unknown"),
      claimedAt: now,
      heartbeatAt: now
    };
    await setWorkerOwner(owner);
    return { ok:true, owner, claimed:true, replaced: !alive || stale };
  }

  if (owner.tabId === tabId) {
    owner.heartbeatAt = now;
    owner.role = String(role || owner.role || "unknown");
    await setWorkerOwner(owner);
    return { ok:true, owner, claimed:false };
  }

  return { ok:false, reason:"owned_by_other_tab", owner };
}
async function touchWorker(sender, role="unknown") {
  const tabId = sender?.tab?.id;
  if (tabId == null) return { ok:false, reason:"no_sender_tab" };

  const owner = await getWorkerOwner();
  if (!owner) return { ok:false, reason:"no_owner" };
  if (owner.tabId !== tabId) return { ok:false, reason:"not_owner", owner };

  owner.heartbeatAt = Date.now();
  owner.role = String(role || owner.role || "unknown");
  await setWorkerOwner(owner);
  return { ok:true, owner };
}
async function releaseWorker(sender, force=false) {
  const tabId = sender?.tab?.id;
  const owner = await getWorkerOwner();
  if (!owner) return { ok:true, released:false };
  if (force || (tabId != null && owner.tabId === tabId)) {
    await setWorkerOwner(null);
    return { ok:true, released:true };
  }
  return { ok:false, reason:"not_owner", owner };
}

function getTzOffsetLabel(date = new Date(), timeZone = LOG_TIMEZONE) {
  try {
    const part = new Intl.DateTimeFormat("en-US", {
      timeZone,
      timeZoneName: "shortOffset"
    }).formatToParts(date).find(p => p.type === "timeZoneName");
    const raw = String(part?.value || "GMT-3").replace(/^UTC/i, "GMT");
    const m = raw.match(/^GMT([+-])(\d{1,2})(?::?(\d{2}))?$/i);
    if (!m) return "-03:00";
    return `${m[1]}${String(m[2]).padStart(2, "0")}:${String(m[3] || "00").padStart(2, "0")}`;
  } catch {
    return "-03:00";
  }
}

function formatTimestamp(date = new Date(), timeZone = LOG_TIMEZONE) {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).formatToParts(date);

    const map = Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
    const ms = String(date.getMilliseconds()).padStart(3, "0");
    const offset = getTzOffsetLabel(date, timeZone);
    return `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}:${map.second}.${ms}${offset}`;
  } catch {
    return date.toISOString();
  }
}

async function getLocal(defaults) {
  return await chrome.storage.local.get(defaults);
}
async function setLocal(patch) {
  return await chrome.storage.local.set(patch);
}
async function pushDebugLog(entry) {
  try {
    const now = new Date();
    const tsLocal = formatTimestamp(now, LOG_TIMEZONE);
    const tsUtc = now.toISOString();
    const out = await getLocal({ [DEBUG_LOG_KEY]: [] });
    const arr = Array.isArray(out[DEBUG_LOG_KEY]) ? out[DEBUG_LOG_KEY] : [];
    arr.push({
      ts: tsLocal,
      tsLocal,
      tsUtc,
      ...entry
    });
    const trimmed = arr.slice(-DEBUG_LOG_MAX);
    await setLocal({ [DEBUG_LOG_KEY]: trimmed });
  } catch {}
}
function shortText(v, n=260) {
  const s = String(v ?? "");
  return s.length > n ? s.slice(0, n) + "…" : s;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (!msg) return;

      const type = String(msg.type || "").trim();
      const senderUrl = sender?.url || "";
      const senderTabId = sender?.tab?.id ?? null;

      if (type === "DEBUG_LOG") {
        await pushDebugLog({
          level: msg.level || "info",
          source: msg.source || "unknown",
          event: msg.event || "",
          detail: msg.detail || "",
          row: msg.row ?? null,
          creci: msg.creci || "",
          pending: msg.pending || null,
          url: msg.url || senderUrl || "",
          tabId: senderTabId
        });
        sendResponse({ ok: true });
        return;
      }

      if (type === "DEBUG_GET_LOGS") {
        const out = await getLocal({ [DEBUG_LOG_KEY]: [] });
        sendResponse({ ok: true, logs: Array.isArray(out[DEBUG_LOG_KEY]) ? out[DEBUG_LOG_KEY] : [] });
        return;
      }

      if (type === "DEBUG_CLEAR_LOGS") {
        await setLocal({ [DEBUG_LOG_KEY]: [] });
        sendResponse({ ok: true });
        return;
      }

      if (type === "WORKER_CLAIM") {
        const resp = await tryClaimWorker(sender, msg.role || "unknown");
        if (!resp.ok) {
          await pushDebugLog({
            level: "warn",
            source: "background",
            event: "worker_claim_denied",
            detail: `${resp.reason || "denied"} | ownerTab=${resp.owner?.tabId ?? ""} | role=${msg.role || ""}`,
            url: senderUrl || "",
            tabId: senderTabId
          });
        }
        sendResponse(resp);
        return;
      }

      if (type === "WORKER_TOUCH") {
        sendResponse(await touchWorker(sender, msg.role || "unknown"));
        return;
      }

      if (type === "WORKER_RELEASE") {
        sendResponse(await releaseWorker(sender, !!msg.force));
        return;
      }

      if (type === "WORKER_STATUS") {
        sendResponse({ ok:true, owner: await getWorkerOwner() });
        return;
      }

      const endpoint = String(msg.endpoint || "").trim();
      if (!endpoint.startsWith("https://script.google.com/macros/s/")) {
        throw new Error("endpoint_invalido");
      }

      if (type === "GAS_GET") {
        const params = msg.params || {};
        const url = new URL(endpoint);
        for (const [k,v] of Object.entries(params)) url.searchParams.set(k, String(v ?? ""));

        const started = Date.now();
        await pushDebugLog({
          level: "info",
          source: msg.source || "background",
          event: "gas_get_start",
          detail: `GET ${url.toString()}`,
          row: msg.row ?? null,
          creci: msg.creci || "",
          url: senderUrl || url.toString(),
          tabId: senderTabId
        });

        const res = await fetch(url.toString(), {
          method: "GET",
          credentials: "omit",
          redirect: "follow",
          cache: "no-store"
        });

        const text = await res.text();
        let json = null;
        try { json = JSON.parse(text); } catch {}

        const elapsedMs = Date.now() - started;
        await pushDebugLog({
          level: res.ok ? "info" : "error",
          source: msg.source || "background",
          event: "gas_get_end",
          detail: `HTTP ${res.status} em ${elapsedMs}ms | ${(json && json.error) ? json.error : shortText(text)}`,
          row: msg.row ?? null,
          creci: msg.creci || "",
          url: res.url || url.toString(),
          tabId: senderTabId
        });

        sendResponse({ ok: true, http_ok: res.ok, status: res.status, url: res.url, text, json, elapsedMs });
        return;
      }

      if (type === "GAS_POST") {
        const body = msg.body || {};
        const started = Date.now();

        await pushDebugLog({
          level: "info",
          source: msg.source || "background",
          event: "gas_post_start",
          detail: `POST ${endpoint} | ${(body && body.action) ? body.action : "payload"}`,
          row: msg.row ?? null,
          creci: msg.creci || "",
          url: senderUrl || endpoint,
          tabId: senderTabId
        });

        const res = await fetch(endpoint, {
          method: "POST",
          credentials: "omit",
          redirect: "follow",
          cache: "no-store",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });

        const text = await res.text();
        let json = null;
        try { json = JSON.parse(text); } catch {}

        const elapsedMs = Date.now() - started;
        await pushDebugLog({
          level: res.ok ? "info" : "error",
          source: msg.source || "background",
          event: "gas_post_end",
          detail: `HTTP ${res.status} em ${elapsedMs}ms | ${(json && json.error) ? json.error : shortText(text)}`,
          row: msg.row ?? null,
          creci: msg.creci || "",
          url: res.url || endpoint,
          tabId: senderTabId
        });

        sendResponse({ ok: true, http_ok: res.ok, status: res.status, url: res.url, text, json, elapsedMs });
        return;
      }

      sendResponse({ ok:false, error:"unknown_message_type" });
    } catch (e) {
      try {
        await pushDebugLog({
          level: "error",
          source: "background",
          event: "runtime_error",
          detail: e && e.message ? e.message : String(e),
          url: sender?.url || "",
          tabId: sender?.tab?.id ?? null
        });
      } catch {}
      sendResponse({ ok:false, error: (e && e.message) ? e.message : String(e) });
    }
  })();
  return true;
});


try {
  chrome.tabs.onRemoved.addListener(async (tabId) => {
    const owner = await getWorkerOwner();
    if (owner?.tabId === tabId) await setWorkerOwner(null);
  });
} catch {}
