const q = s => document.querySelector(s);
const LOG_TIMEZONE = "America/Sao_Paulo";

function getTzOffsetLabel(date = new Date(), timeZone = LOG_TIMEZONE) {
  try {
    const part = new Intl.DateTimeFormat("en-US", {
      timeZone,
      timeZoneName: "shortOffset"
    }).formatToParts(date).find(p => p.type === "timeZoneName");
    const raw = String(part?.value || "GMT-3").replace(/^UTC/i, "GMT");
    const m = raw.match(/^GMT([+-])(\d{1,2})(?::?(\d{2}))?$/i);
    if (!m) return "-03:00";
    return `${m[1]}${String(m[2]).padStart(2, "0")}:${String(m[3] || "00").padStart(2, "0")}`;
  } catch {
    return "-03:00";
  }
}

function formatTsToSaoPaulo(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return String(ts);

  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: LOG_TIMEZONE,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).formatToParts(d);
    const map = Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
    const ms = String(d.getMilliseconds()).padStart(3, "0");
    const offset = getTzOffsetLabel(d, LOG_TIMEZONE);
    return `${map.year}-${map.month}-${map.day}T${map.hour}:${map.minute}:${map.second}.${ms}${offset}`;
  } catch {
    return String(ts);
  }
}

function pickTs(x) {
  return x.tsLocal || formatTsToSaoPaulo(x.tsUtc || x.ts || "");
}

function fmtLog(x) {
  const parts = [
    `[${pickTs(x)}]`,
    x.source ? `[${x.source}]` : "",
    x.event || "",
    x.detail || ""
  ].filter(Boolean);
  const extra = [];
  if (x.row) extra.push(`row=${x.row}`);
  if (x.creci) extra.push(`creci=${x.creci}`);
  if (x.url) extra.push(`url=${x.url}`);
  if (extra.length) parts.push("\n  " + extra.join(" | "));
  return parts.join(" ");
}

async function debugGetLogs() {
  return await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type:"DEBUG_GET_LOGS" }, (resp) => {
      const err = chrome.runtime.lastError;
      if (err || !resp || resp.ok === false) return resolve([]);
      resolve(Array.isArray(resp.logs) ? resp.logs : []);
    });
  });
}

async function debugClearLogs() {
  return await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type:"DEBUG_CLEAR_LOGS" }, () => resolve());
  });
}

function normalizePositiveInt(v, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.round(n));
}

function getConfigFromForm() {
  const rowStart = normalizePositiveInt(q("#rowStart").value || 2, 2) || 2;
  const rowEnd = normalizePositiveInt(q("#rowEnd").value || 0, 0);
  return {
    endpoint: q("#endpoint").value.trim(),
    spreadsheetId: q("#spreadsheetId").value.trim(),
    tab: q("#tab").value.trim(),
    rowStart: Math.max(2, rowStart),
    rowEnd: rowEnd > 0 ? rowEnd : 0,
    creciColumn: q("#creciColumn").value.trim(),
    delaySearchMs: Math.max(0, Number(q("#delaySearchMs").value || 1500) || 1500),
    delayOpenProfileMs: Math.max(0, Number(q("#delayOpenProfileMs").value || 1500) || 1500),
    delayNextRowMs: Math.max(0, Number(q("#delayNextRowMs").value || 2000) || 2000),
    debug: !!q("#debug").checked
  };
}

async function persistFormConfig() {
  const cfg = getConfigFromForm();
  const current = await chrome.storage.local.get({ running:false, pauseUntil:0, pending:null });
  await chrome.storage.local.set({
    ...cfg,
    running: current.running,
    pauseUntil: current.pauseUntil,
    pending: current.pending
  });
}

async function load() {
  const st = await chrome.storage.local.get({
    endpoint: "",
    spreadsheetId: "",
    tab: "",
    rowStart: 2,
    rowEnd: 0,
    creciColumn: "",
    delaySearchMs: 1500,
    delayOpenProfileMs: 1500,
    delayNextRowMs: 2000,
    running: false,
    debug: false,
    pending: null,
    pauseUntil: 0
  });

  q("#endpoint").value = st.endpoint || "";
  q("#spreadsheetId").value = st.spreadsheetId || "";
  q("#tab").value = st.tab || "";
  q("#rowStart").value = String(st.rowStart ?? 2);
  q("#rowEnd").value = String(st.rowEnd ?? 0);
  q("#creciColumn").value = st.creciColumn || "";
  q("#delaySearchMs").value = String(st.delaySearchMs ?? 1500);
  q("#delayOpenProfileMs").value = String(st.delayOpenProfileMs ?? 1500);
  q("#delayNextRowMs").value = String(st.delayNextRowMs ?? 2000);
  q("#debug").checked = !!st.debug;

  const status = [];
  status.push(`Rodando: ${st.running ? "SIM" : "NÃO"}`);
  status.push(`Debug: ${st.debug ? "ON" : "OFF"}`);
  if (st.pending?.row) status.push(`Linha pendente: ${st.pending.row}`);
  if (st.pending?.creciRaw) status.push(`CRECI: ${st.pending.creciRaw}`);
  if (st.spreadsheetId) status.push(`Planilha: ${st.spreadsheetId}`);
  if (st.tab) status.push(`Aba: ${st.tab}`);
  status.push(`Faixa: ${st.rowStart ?? 2} até ${(st.rowEnd && st.rowEnd > 0) ? st.rowEnd : "última"}`);
  status.push(`Coluna CRECI: ${st.creciColumn || "auto"}`);
  status.push(`Busca: ${st.delaySearchMs ?? 1500}ms`);
  status.push(`Abrir IG: ${st.delayOpenProfileMs ?? 1500}ms`);
  status.push(`Próxima linha: ${st.delayNextRowMs ?? 2000}ms`);
  if (st.pauseUntil && Date.now() < st.pauseUntil) {
    const secs = Math.ceil((st.pauseUntil - Date.now()) / 1000);
    status.push(`Pausado por ${secs}s`);
  }
  q("#status").textContent = status.join(" | ");

  const logs = await debugGetLogs();
  q("#logs").textContent = logs.length ? logs.slice(-80).map(fmtLog).join("\n\n") : "Sem logs ainda.";
}
load();

q("#startBtn").addEventListener("click", async () => {
  const { endpoint, spreadsheetId, tab, rowStart, rowEnd, creciColumn, delaySearchMs, delayOpenProfileMs, delayNextRowMs, debug } = getConfigFromForm();

  if (!endpoint || !/^https:\/\/script\.google\.com\/macros\/s\//.test(endpoint)) {
    alert("Cole a URL do Web App do Apps Script (…/exec).");
    return;
  }

  await chrome.storage.local.set({
    endpoint,
    spreadsheetId,
    tab,
    rowStart,
    rowEnd,
    creciColumn,
    delaySearchMs,
    delayOpenProfileMs,
    delayNextRowMs,
    running: true,
    pauseUntil: 0,
    debug,
    pending: null
  });

  chrome.tabs.create({ url: "https://www.google.com/search?hl=pt-BR&q=CRECI" });
  window.close();
});

q("#stopBtn").addEventListener("click", async () => {
  await chrome.storage.local.set({ running: false, pending: null });
  alert("Parado.");
  window.close();
});

q("#refreshBtn").addEventListener("click", load);

q("#copyBtn").addEventListener("click", async () => {
  const logs = await debugGetLogs();
  const txt = logs.length ? logs.map(fmtLog).join("\n\n") : "Sem logs.";
  try {
    await navigator.clipboard.writeText(txt);
    alert("Logs copiados.");
  } catch {
    alert("Não consegui copiar os logs.");
  }
});

q("#clearBtn").addEventListener("click", async () => {
  await debugClearLogs();
  await load();
});

["#endpoint","#spreadsheetId","#tab","#rowStart","#rowEnd","#creciColumn","#delaySearchMs","#delayOpenProfileMs","#delayNextRowMs","#debug"].forEach(sel => {
  const el = q(sel);
  if (!el) return;
  const evt = el.type === "checkbox" ? "change" : "input";
  el.addEventListener(evt, () => { persistFormConfig().catch(() => {}); });
});
