/**
 * RH IMOB — Web App para extensão CRECI -> Instagram (Google)
 *
 * Regra operacional desta versão:
 * - Lê o CRECI na linha já existente.
 * - NÃO altera colunas raiz/autênticas.
 * - NÃO apaga conteúdo já escrito.
 * - Grava somente nas colunas RHI_IG_*.
 * - Se não existirem colunas RHI_IG_*, cria/injeta logo após a coluna "Telefone".
 */

const SPREADSHEET_ID = '';
const DEFAULT_SHEET_NAME = 'SEM TEL ORG';
const HEADER_ROW = 1;
const START_ROW = 2;
const TZ = 'America/Sao_Paulo';

const ROOT_HEADER_CRECI_CANDIDATES = ['CRECI', 'CRECI:', 'CRECI :'];
const ROOT_HEADER_NOME = 'Nome';
const ROOT_HEADER_BUSCA = 'Busca';
const ROOT_HEADER_TELEFONE = 'Telefone';

const RHI_IG_HEADERS = [
  'RHI_IG_STATUS',
  'RHI_IG_DETAIL',
  'RHI_IG_INSTAGRAM_URL',
  'RHI_IG_USERNAME',
  'RHI_IG_NOME_PERFIL',
  'RHI_IG_BIO',
  'RHI_IG_CARGO',
  'RHI_IG_CARGO_RAW',
  'RHI_IG_CARGO_ORIGEM',
  'RHI_IG_CARGO_CONFIANCA',
  'RHI_IG_ACHOU_EX',
  'RHI_IG_FLAG_EMPRESA',
  'RHI_IG_FLAG_RUIDO',
  'RHI_IG_CARGO_OBS',
  'RHI_IG_CATEGORIA_PERFIL',
  'RHI_IG_TELEFONE_WA',
  'RHI_IG_TELEFONE_TXT',
  'RHI_IG_CRECI_TEXTO',
  'RHI_IG_CRECI_NUMERO',
  'RHI_IG_CEP_TEXTO',
  'RHI_IG_SEGUIDORES',
  'RHI_IG_SEGUINDO',
  'RHI_IG_POSTAGENS',
  'RHI_IG_ATUALIZADO_EM'
];

function nowIsoLocal_() {
  return Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function doGet(e) {
  try {
    const p = (e && e.parameter) ? e.parameter : {};
    const action = String(p.action || 'ping').trim().toLowerCase();

    if (action === 'ping') return output_({ ok: true, msg: 'online', ts: nowIsoLocal_() });
    if (action === 'getnextig') return output_(getNextIg_(p));
    if (action === 'getrowstate') return output_(getRowState_(p));

    return output_({ ok: false, error: 'action inválida' });
  } catch (err) {
    return output_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function doPost(e) {
  try {
    const raw = (e && e.postData && e.postData.contents) ? e.postData.contents : '';
    const data = raw ? JSON.parse(raw) : {};
    const action = String(data.action || '').trim().toLowerCase();

    if (action === 'ping' || data.ping === true) {
      return output_({ ok: true, msg: 'pong', ts: nowIsoLocal_() });
    }
    if (action === 'savestatus' || action === 'savestatusonly' || action === 'savestatus_') {
      return output_(saveStatus_(data));
    }
    if (action === 'saveigdata') {
      return output_(saveIgData_(data));
    }
    return output_({ ok: false, error: 'action inválida no POST' });
  } catch (err) {
    return output_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function getNextIg_(params) {
  const sh = getSheet_(params.spreadsheetId || params.SpreadsheetId, params.tab || params.Tab);
  const ctx = ensureSheetContext_(sh, params);

  if (ctx.rowEnd < ctx.rowStart) return { ok: true, next: null, meta: packMeta_(ctx) };

  const totalRows = ctx.rowEnd - ctx.rowStart + 1;
  const creciValues = sh.getRange(ctx.rowStart, ctx.creciColumn, totalRows, 1).getDisplayValues();
  const statusValues = ctx.statusColumn ? sh.getRange(ctx.rowStart, ctx.statusColumn, totalRows, 1).getDisplayValues() : null;
  const buscaValues = ctx.buscaColumn ? sh.getRange(ctx.rowStart, ctx.buscaColumn, totalRows, 1).getDisplayValues() : null;
  const nomeValues = ctx.nomeColumn ? sh.getRange(ctx.rowStart, ctx.nomeColumn, totalRows, 1).getDisplayValues() : null;

  for (var i = 0; i < totalRows; i++) {
    const row = ctx.rowStart + i;
    const creciRaw = String(creciValues[i][0] || '').trim();
    const status = statusValues ? String(statusValues[i][0] || '').trim() : '';
    if (!creciRaw) continue;
    if (status) continue;

    const searchLink = firstNonEmpty_([
      buscaValues ? buscaValues[i][0] : '',
      nomeValues ? nomeValues[i][0] : ''
    ]);

    return {
      ok: true,
      next: { row: row, creciRaw: creciRaw, creci: creciRaw, searchLink: searchLink },
      meta: packMeta_(ctx)
    };
  }

  return { ok: true, next: null, meta: packMeta_(ctx) };
}

function getRowState_(params) {
  const row = Number(params.row || params.Row || 0);
  if (row < START_ROW) return { ok: false, error: 'row inválida' };

  const sh = getSheet_(params.spreadsheetId || params.SpreadsheetId, params.tab || params.Tab);
  const ctx = ensureSheetContext_(sh, params);
  const safeRow = Math.min(Math.max(row, ctx.rowStart), ctx.rowEnd || row);

  const creciRaw = String(sh.getRange(safeRow, ctx.creciColumn).getDisplayValue() || '').trim();
  const status = ctx.statusColumn ? String(sh.getRange(safeRow, ctx.statusColumn).getDisplayValue() || '').trim() : '';

  return {
    ok: true,
    row: safeRow,
    creciRaw: creciRaw,
    status: status,
    canInteract: !!creciRaw && !status,
    meta: packMeta_(ctx)
  };
}

function saveStatus_(data) {
  const sh = getSheet_(data.spreadsheetId || data.SpreadsheetId, data.tab || data.Tab);
  const ctx = ensureSheetContext_(sh, data);

  const targetRow = resolveTargetRow_(sh, ctx, Number(data.row || data.Row || 0), firstNonEmpty_([
    data.sourceCreciRaw, data.SourceCreciRaw, data.creciRaw
  ]));
  if (!(targetRow >= ctx.rowStart && targetRow <= ctx.rowEnd)) {
    return { ok: false, error: 'row inválida ou divergência de linha', meta: packMeta_(ctx) };
  }

  const status = String(data.status || data.Status || '').trim();
  const detail = String(data.detail || data.Detail || '').trim();
  const nowIso = nowIsoLocal_();

  writeByHeader_(sh, targetRow, ctx.headerMap, 'RHI_IG_STATUS', status, true);
  writeByHeader_(sh, targetRow, ctx.headerMap, 'RHI_IG_DETAIL', detail, true);
  writeByHeader_(sh, targetRow, ctx.headerMap, 'RHI_IG_ATUALIZADO_EM', nowIso, true);

  return { ok: true, row: targetRow, status: status, detail: detail, meta: packMeta_(ctx) };
}

function saveIgData_(data) {
  const sh = getSheet_(data.spreadsheetId || data.SpreadsheetId, data.tab || data.Tab);
  const ctx = ensureSheetContext_(sh, data);

  const targetRow = resolveTargetRow_(sh, ctx, Number(data.row || data.Row || 0), firstNonEmpty_([
    data.sourceCreciRaw, data.SourceCreciRaw, data.creciRaw
  ]));
  if (!(targetRow >= ctx.rowStart && targetRow <= ctx.rowEnd)) {
    return { ok: false, error: 'row inválida ou divergência de linha', meta: packMeta_(ctx) };
  }

  const nowIso = nowIsoLocal_();
  const igUrl = firstNonEmpty_([data.RHI_IG_INSTAGRAM_URL, data.igUrl, data.InstagramUrl, data.PerfilURL]);
  const username = firstNonEmpty_([data.RHI_IG_USERNAME, data.Username, data.username]);
  const nomePerfil = firstNonEmpty_([data.RHI_IG_NOME_PERFIL, data.igName, data.NomePerfil, data.Nome]);
  const bio = firstNonEmpty_([data.RHI_IG_BIO, data.BIO, data.bio]);
  const cargo = firstNonEmpty_([data.RHI_IG_CARGO, data.Cargo, data.cargo]);
  const cargoRaw = firstNonEmpty_([data.RHI_IG_CARGO_RAW, data.CargoRaw, data.cargoRaw]);
  const cargoOrigem = firstNonEmpty_([data.RHI_IG_CARGO_ORIGEM, data.CargoOrigem, data.cargoOrigem]);
  const cargoConfianca = firstNonEmpty_([data.RHI_IG_CARGO_CONFIANCA, data.CargoConfianca, data.cargoConfianca]);
  const achouEx = firstNonEmpty_([data.RHI_IG_ACHOU_EX, data.AchouEx, data.achouEx]);
  const flagEmpresa = firstNonEmpty_([data.RHI_IG_FLAG_EMPRESA, data.FlagEmpresa, data.flagEmpresa]);
  const flagRuido = firstNonEmpty_([data.RHI_IG_FLAG_RUIDO, data.FlagRuido, data.flagRuido]);
  const cargoObs = firstNonEmpty_([data.RHI_IG_CARGO_OBS, data.CargoObs, data.cargoObs]);
  const categoria = firstNonEmpty_([data.RHI_IG_CATEGORIA_PERFIL, data.CategoriaPerfil, data.category]);
  const telefoneWa = firstNonEmpty_([data.RHI_IG_TELEFONE_WA, data.TelefoneWA, data.phoneWa]);
  const telefoneTxt = normalizePhoneOnly_([data.RHI_IG_TELEFONE_TXT, data.TelefoneTXT, data.TelefoneTxtLinha, data.phone]);
  const creciTexto = firstNonEmpty_([data.RHI_IG_CRECI_TEXTO, data.CreciTexto]);
  const creciNumero = firstNonEmpty_([data.RHI_IG_CRECI_NUMERO, data.CreciNumero, extractCreciDigits_(creciTexto)]);
  const cepTexto = firstNonEmpty_([data.RHI_IG_CEP_TEXTO, data.CepTexto, normalizeCep_(bio)]);
  const seguidores = firstNonEmpty_([data.RHI_IG_SEGUIDORES, data.followers, data.Seguidores]);
  const seguindo = firstNonEmpty_([data.RHI_IG_SEGUINDO, data.following, data.Seguindo]);
  const postagens = firstNonEmpty_([data.RHI_IG_POSTAGENS, data.posts, data.Postagens]);
  const status = String(data.RHI_IG_STATUS || data.status || data.Status || (igUrl ? 'OK' : 'SEM_RESULTADO')).trim();
  const detail = String(data.RHI_IG_DETAIL || data.detail || data.Detail || '').trim();

  const hasEvidence = !!firstNonEmpty_([igUrl, username, nomePerfil, bio, categoria, telefoneWa, telefoneTxt, seguidores, seguindo, postagens]);
  if (!hasEvidence && /^OK/i.test(status)) {
    return { ok: false, error: 'payload_sem_evidencia', row: targetRow, meta: packMeta_(ctx) };
  }

  const rhiPayload = {
    'RHI_IG_STATUS': status,
    'RHI_IG_DETAIL': detail,
    'RHI_IG_INSTAGRAM_URL': igUrl,
    'RHI_IG_USERNAME': username,
    'RHI_IG_NOME_PERFIL': nomePerfil,
    'RHI_IG_BIO': bio,
    'RHI_IG_CARGO': cargo,
    'RHI_IG_CARGO_RAW': cargoRaw,
    'RHI_IG_CARGO_ORIGEM': cargoOrigem,
    'RHI_IG_CARGO_CONFIANCA': cargoConfianca,
    'RHI_IG_ACHOU_EX': achouEx,
    'RHI_IG_FLAG_EMPRESA': flagEmpresa,
    'RHI_IG_FLAG_RUIDO': flagRuido,
    'RHI_IG_CARGO_OBS': cargoObs,
    'RHI_IG_CATEGORIA_PERFIL': categoria,
    'RHI_IG_TELEFONE_WA': telefoneWa,
    'RHI_IG_TELEFONE_TXT': telefoneTxt,
    'RHI_IG_CRECI_TEXTO': creciTexto,
    'RHI_IG_CRECI_NUMERO': creciNumero,
    'RHI_IG_CEP_TEXTO': cepTexto,
    'RHI_IG_SEGUIDORES': seguidores,
    'RHI_IG_SEGUINDO': seguindo,
    'RHI_IG_POSTAGENS': postagens,
    'RHI_IG_ATUALIZADO_EM': nowIso
  };

  Object.keys(rhiPayload).forEach(function(header) {
    const force = header === 'RHI_IG_STATUS' || header === 'RHI_IG_DETAIL' || header === 'RHI_IG_ATUALIZADO_EM';
    writeByHeader_(sh, targetRow, ctx.headerMap, header, rhiPayload[header], force);
  });

  return {
    ok: true,
    row: targetRow,
    igUrl: igUrl,
    igName: nomePerfil,
    phone: telefoneTxt,
    status: status,
    cargo: cargo,
    meta: packMeta_(ctx)
  };
}

function getSheet_(spreadsheetId, tabName) {
  const ss = openSpreadsheet_(spreadsheetId);
  const name = String(tabName || DEFAULT_SHEET_NAME).trim() || DEFAULT_SHEET_NAME;
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  return sh;
}

function openSpreadsheet_(spreadsheetId) {
  const dynamicId = String(spreadsheetId || '').trim();
  if (dynamicId) return SpreadsheetApp.openById(dynamicId);
  if (String(SPREADSHEET_ID || '').trim()) return SpreadsheetApp.openById(String(SPREADSHEET_ID).trim());
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) throw new Error('Defina SPREADSHEET_ID ou use este script vinculado à planilha.');
  return active;
}

function ensureSheetContext_(sh, params) {
  ensureHeaderRowExists_(sh);

  let headers = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  let headerMap = buildHeaderMap_(headers);

  const creciColumn = resolveCreciColumn_(headers, params);
  const nomeColumn = headerMap[normalizeHeaderKey_(ROOT_HEADER_NOME)] || 0;
  const buscaColumn = headerMap[normalizeHeaderKey_(ROOT_HEADER_BUSCA)] || 0;
  const telefoneColumn = resolveTelefoneColumn_(headers);

  ensureRhiHeadersAfterTelefone_(sh, headers, telefoneColumn);

  headers = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  headerMap = buildHeaderMap_(headers);

  const rowStart = Math.max(START_ROW, Number(params.rowStart || params.RowStart || START_ROW) || START_ROW);
  const rowEndRequested = Number(params.rowEnd || params.RowEnd || 0) || 0;
  const lastRow = Math.max(sh.getLastRow(), rowStart);
  const rowEnd = rowEndRequested > 0 ? Math.min(Math.max(rowEndRequested, rowStart), lastRow) : lastRow;

  return {
    headerRow: HEADER_ROW,
    rowStart: rowStart,
    rowEnd: rowEnd,
    creciColumn: creciColumn,
    nomeColumn: nomeColumn,
    buscaColumn: buscaColumn,
    telefoneColumn: telefoneColumn,
    statusColumn: headerMap[normalizeHeaderKey_('RHI_IG_STATUS')] || 0,
    headerMap: headerMap,
    lastHeaderColumn: getLastNonEmptyHeaderColumn_(headers),
    rootProtectedUntilColumn: telefoneColumn
  };
}

function ensureHeaderRowExists_(sh) {
  if (sh.getLastRow() < HEADER_ROW || sh.getLastColumn() < 1) {
    sh.getRange(HEADER_ROW, 1).setValue('CRECI');
    return;
  }
  const headers = sh.getRange(HEADER_ROW, 1, 1, Math.max(sh.getLastColumn(), 1)).getDisplayValues()[0];
  if (headers.every(function(v) { return !String(v || '').trim(); })) {
    sh.getRange(HEADER_ROW, 1).setValue('CRECI');
  }
}

function ensureRhiHeadersAfterTelefone_(sh, headers, telefoneColumn) {
  const map = buildHeaderMap_(headers);
  const hasAnyRhi = RHI_IG_HEADERS.some(function(h) { return !!map[normalizeHeaderKey_(h)]; });
  if (hasAnyRhi) return;

  const insertAfter = Math.max(telefoneColumn, 1);
  sh.insertColumnsAfter(insertAfter, RHI_IG_HEADERS.length);
  sh.getRange(HEADER_ROW, insertAfter + 1, 1, RHI_IG_HEADERS.length).setValues([RHI_IG_HEADERS]);
}

function resolveCreciColumn_(headers, params) {
  const manual = parseColumnInput_(params.creciColumn || params.CreciColumn || params.creci_col || params.creciCol);
  if (manual > 0) return manual;

  for (var i = 0; i < headers.length; i++) {
    const raw = String(headers[i] || '').trim();
    if (!raw) continue;
    if (isCreciHeader_(raw)) return i + 1;
  }
  return 1;
}

function resolveTelefoneColumn_(headers) {
  for (var i = 0; i < headers.length; i++) {
    if (normalizeHeaderKey_(headers[i]) === normalizeHeaderKey_(ROOT_HEADER_TELEFONE)) return i + 1;
  }
  return 6;
}

function isCreciHeader_(value) {
  const normalized = normalizeHeaderKey_(value);
  if (normalized === 'CRECI') return true;
  const raw = String(value || '').trim();
  return /^CRECI\s*:?.*$/i.test(raw) && /CRECI/i.test(raw);
}

function buildHeaderMap_(headers) {
  const map = {};
  for (var i = 0; i < headers.length; i++) {
    const raw = String(headers[i] || '').trim();
    if (!raw) continue;
    const key = normalizeHeaderKey_(raw);
    if (key && map[key] == null) map[key] = i + 1;
  }
  return map;
}

function getLastNonEmptyHeaderColumn_(headers) {
  for (var i = (headers || []).length - 1; i >= 0; i--) {
    if (String(headers[i] || '').trim()) return i + 1;
  }
  return 1;
}

function resolveTargetRow_(sh, ctx, rowInput, sourceCreciRaw) {
  if (!(rowInput >= ctx.rowStart && rowInput <= ctx.rowEnd)) return 0;
  if (!ctx.creciColumn) return rowInput;

  const rowCreci = String(sh.getRange(rowInput, ctx.creciColumn).getDisplayValue() || '').trim();
  if (!sourceCreciRaw) return rowInput;

  const normalizedRow = normalizeCreciLookup_(rowCreci);
  const normalizedSource = normalizeCreciLookup_(sourceCreciRaw);
  if (!normalizedSource) return rowInput;
  if (!normalizedRow || normalizedRow === normalizedSource) return rowInput;
  return 0;
}

function parseColumnInput_(value) {
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return 0;
  if (/^\d+$/.test(raw)) return Number(raw) || 0;
  if (!/^[A-Z]+$/.test(raw)) return 0;
  var out = 0;
  for (var i = 0; i < raw.length; i++) out = out * 26 + (raw.charCodeAt(i) - 64);
  return out;
}

function normalizeHeaderKey_(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[\s:._-]+/g, '')
    .toUpperCase()
    .trim();
}

function normalizeCreciLookup_(value) {
  const raw = String(value || '').toUpperCase();
  const digits = onlyDigits_(raw);
  if (!digits) return '';
  const suffixMatch = raw.match(/\b([FCJ])\b/);
  const suffix = suffixMatch ? suffixMatch[1] : '';
  return digits + (suffix ? '-' + suffix : '');
}

function extractCreciDigits_(value) {
  return onlyDigits_(value);
}

function onlyDigits_(value) {
  const match = String(value || '').match(/\d+/g);
  return match ? match.join('') : '';
}

function normalizeCep_(value) {
  const m = String(value || '').match(/\b\d{5}-?\d{3}\b/);
  return m ? m[0] : '';
}

function normalizePhoneOnly_(values) {
  const joined = Array.isArray(values) ? values.map(function(v) { return String(v == null ? '' : v); }).join(' | ') : String(values == null ? '' : values);
  const digits = joined.match(/\d+/g);
  if (!digits) return '';
  var s = digits.join('');
  if (s.indexOf('55') === 0 && s.length >= 12) s = s.slice(2);
  if (s.length < 10) return '';
  if (s.length > 11) s = s.slice(-11);
  if (s.length === 10) return '(' + s.slice(0, 2) + ') ' + s.slice(2, 6) + '-' + s.slice(6);
  return '(' + s.slice(0, 2) + ') ' + s.slice(2, 7) + '-' + s.slice(7);
}

function firstNonEmpty_(values) {
  for (var i = 0; i < (values || []).length; i++) {
    const s = String(values[i] == null ? '' : values[i]).trim();
    if (s) return s;
  }
  return '';
}

function writeByHeader_(sh, row, map, header, value, force) {
  const col = map[normalizeHeaderKey_(header)];
  if (!col) return;
  writeCell_(sh, row, col, value, !!force);
}

function writeCell_(sh, row, col, value, force) {
  if (!col || col < 1) return;
  const cell = sh.getRange(row, col);
  const currentValue = cell.getDisplayValue();
  const nextValue = value == null ? '' : value;

  if (!String(currentValue || '').trim()) {
    cell.setValue(nextValue);
    return;
  }
  if (String(currentValue) === String(nextValue)) return;
  if (force) cell.setValue(nextValue);
}

function packMeta_(ctx) {
  return {
    headerRow: ctx.headerRow,
    rowStart: ctx.rowStart,
    rowEnd: ctx.rowEnd,
    creciColumn: ctx.creciColumn,
    nomeColumn: ctx.nomeColumn,
    buscaColumn: ctx.buscaColumn,
    telefoneColumn: ctx.telefoneColumn,
    statusColumn: ctx.statusColumn,
    lastHeaderColumn: ctx.lastHeaderColumn,
    rootProtectedUntilColumn: ctx.rootProtectedUntilColumn
  };
}

function output_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
